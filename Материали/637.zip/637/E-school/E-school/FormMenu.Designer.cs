﻿namespace E_school
{
    partial class FormMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonAddClass = new System.Windows.Forms.Button();
            this.buttonAddProfile = new System.Windows.Forms.Button();
            this.buttonAddStudent = new System.Windows.Forms.Button();
            this.buttonClose = new System.Windows.Forms.Button();
            this.buttonAddTeacher = new System.Windows.Forms.Button();
            this.buttonAddStudents = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // buttonAddClass
            // 
            this.buttonAddClass.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonAddClass.Image = global::E_school.Properties.Resources.users_add_icon;
            this.buttonAddClass.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.buttonAddClass.Location = new System.Drawing.Point(62, 40);
            this.buttonAddClass.Name = "buttonAddClass";
            this.buttonAddClass.Size = new System.Drawing.Size(122, 49);
            this.buttonAddClass.TabIndex = 0;
            this.buttonAddClass.Text = "Добавяне на клас";
            this.buttonAddClass.UseVisualStyleBackColor = true;
            this.buttonAddClass.Click += new System.EventHandler(this.buttonAddClass_Click);
            // 
            // buttonAddProfile
            // 
            this.buttonAddProfile.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonAddProfile.Image = global::E_school.Properties.Resources.Actions_bookmark_add_icon;
            this.buttonAddProfile.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.buttonAddProfile.Location = new System.Drawing.Point(62, 114);
            this.buttonAddProfile.Name = "buttonAddProfile";
            this.buttonAddProfile.Size = new System.Drawing.Size(122, 49);
            this.buttonAddProfile.TabIndex = 1;
            this.buttonAddProfile.Text = "Добавяне на профил";
            this.buttonAddProfile.UseVisualStyleBackColor = true;
            this.buttonAddProfile.Click += new System.EventHandler(this.buttonAddProfile_Click);
            // 
            // buttonAddStudent
            // 
            this.buttonAddStudent.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonAddStudent.Image = global::E_school.Properties.Resources.user_add_icon;
            this.buttonAddStudent.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.buttonAddStudent.Location = new System.Drawing.Point(62, 188);
            this.buttonAddStudent.Name = "buttonAddStudent";
            this.buttonAddStudent.Size = new System.Drawing.Size(122, 49);
            this.buttonAddStudent.TabIndex = 2;
            this.buttonAddStudent.Text = "Добавяне на ученик";
            this.buttonAddStudent.UseVisualStyleBackColor = true;
            this.buttonAddStudent.Click += new System.EventHandler(this.buttonAddStudent_Click);
            // 
            // buttonClose
            // 
            this.buttonClose.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonClose.Image = global::E_school.Properties.Resources.Button_Close_icon;
            this.buttonClose.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonClose.Location = new System.Drawing.Point(62, 410);
            this.buttonClose.Name = "buttonClose";
            this.buttonClose.Size = new System.Drawing.Size(122, 49);
            this.buttonClose.TabIndex = 5;
            this.buttonClose.Text = "Затвори";
            this.buttonClose.UseVisualStyleBackColor = true;
            this.buttonClose.Click += new System.EventHandler(this.buttonClose_Click);
            // 
            // buttonAddTeacher
            // 
            this.buttonAddTeacher.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonAddTeacher.Image = global::E_school.Properties.Resources.Actions_bookmark_add_icon1;
            this.buttonAddTeacher.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.buttonAddTeacher.Location = new System.Drawing.Point(62, 336);
            this.buttonAddTeacher.Name = "buttonAddTeacher";
            this.buttonAddTeacher.Size = new System.Drawing.Size(122, 49);
            this.buttonAddTeacher.TabIndex = 4;
            this.buttonAddTeacher.Text = "Добавяне на акаунт";
            this.buttonAddTeacher.UseVisualStyleBackColor = true;
            this.buttonAddTeacher.Click += new System.EventHandler(this.button1_Click);
            // 
            // buttonAddStudents
            // 
            this.buttonAddStudents.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonAddStudents.Image = global::E_school.Properties.Resources.users_add_icon;
            this.buttonAddStudents.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.buttonAddStudents.Location = new System.Drawing.Point(62, 262);
            this.buttonAddStudents.Name = "buttonAddStudents";
            this.buttonAddStudents.Size = new System.Drawing.Size(122, 49);
            this.buttonAddStudents.TabIndex = 3;
            this.buttonAddStudents.Text = "Импорт на ученици от Excel";
            this.buttonAddStudents.UseVisualStyleBackColor = true;
            this.buttonAddStudents.Click += new System.EventHandler(this.buttonAddStudents_Click);
            // 
            // FormMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::E_school.Properties.Resources.school1;
            this.ClientSize = new System.Drawing.Size(249, 487);
            this.Controls.Add(this.buttonAddStudents);
            this.Controls.Add(this.buttonClose);
            this.Controls.Add(this.buttonAddTeacher);
            this.Controls.Add(this.buttonAddStudent);
            this.Controls.Add(this.buttonAddProfile);
            this.Controls.Add(this.buttonAddClass);
            this.KeyPreview = true;
            this.Name = "FormMenu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Меню";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button buttonAddClass;
        private System.Windows.Forms.Button buttonAddProfile;
        private System.Windows.Forms.Button buttonAddStudent;
        private System.Windows.Forms.Button buttonClose;
        private System.Windows.Forms.Button buttonAddTeacher;
        private System.Windows.Forms.Button buttonAddStudents;
    }
}