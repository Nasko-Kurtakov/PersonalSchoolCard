﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace E_school
{
    public partial class FormCreateAccaunts : Form
    {
        public FormCreateAccaunts()
        {
            InitializeComponent();
        }

        private void buttonBack1_Click(object sender, EventArgs e)
        {
            this.Close();
           
        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            ESchoolEntities context = new ESchoolEntities();
            if (!string.IsNullOrEmpty(textBoxUser.Text) && !string.IsNullOrEmpty(textBoxPassword.Text) && !string.IsNullOrEmpty(textBoxName.Text) && !string.IsNullOrEmpty(textBoxFamily.Text))
            {
                //създаваме обект
                Teachers newTeacher = new Teachers();
                newTeacher.UserName = textBoxUser.Text;
                newTeacher.Password = textBoxPassword.Text;
                newTeacher.FirstName = textBoxName.Text;
                newTeacher.LastName = textBoxFamily.Text;
                //добавяне на акаунта в базата и записване на промените
                context.Teachers .AddObject(newTeacher);
                context.SaveChanges();
                MessageBox.Show("Акаунтът е добавена!");
                buttonAdd.Enabled = false;

            }
            else
            {
                MessageBox.Show("Грешка! Не сте въвели данни.");
            }
        }
        //метод, който по ID на учителя, връща обект от тип Teachers
        static Teachers GetTeacherByID(ESchoolEntities context, int accauntID)
        {
            Teachers teacher = context.Teachers.FirstOrDefault(
                p => p.TeacherID == accauntID);
            return teacher;
        }

       
        private void buttonEdit_Click(object sender, EventArgs e)
        {
            ESchoolEntities context = new ESchoolEntities();
            //намира номера на текущия ред
            int i = dataGridViewTeachers.CurrentRow.Index;
            //извличаме accauntID 
            int accauntID = Int32.Parse(dataGridViewTeachers.Rows[i].Cells[0].Value.ToString());
            //намира учителя с този  accauntID
            Teachers teacher = GetTeacherByID(context, accauntID);
            //променя данните
            teacher.FirstName = dataGridViewTeachers.Rows[i].Cells[1].Value.ToString();
            teacher.LastName = dataGridViewTeachers.Rows[i].Cells[2].Value.ToString();
            teacher.UserName = dataGridViewTeachers.Rows[i].Cells[3].Value.ToString();
            teacher.Password = dataGridViewTeachers.Rows[i].Cells[4].Value.ToString();
            //записва ги в базата
            context.SaveChanges();
            MessageBox.Show("Данните са редактирани!");
        }

        private void buttonShow_Click(object sender, EventArgs e)
        {
            ESchoolEntities context = new ESchoolEntities();
            //зареждане на таблицата с класните
            var teachers = context.Teachers;
            dataGridViewTeachers.AutoGenerateColumns = false;
            dataGridViewTeachers.DataSource = teachers;
            buttonEdit.Enabled = true;
        }
        //изтриване на акаунти- няма да се използва, защото е свързано с каскадно изтриване от базата
        private void buttonDelete_Click(object sender, EventArgs e)
        {
            ESchoolEntities context = new ESchoolEntities();
            //намира номера на текущия ред
            int i = dataGridViewTeachers.CurrentRow.Index;
            //извличаме accauntID 
            int accauntID = Int32.Parse(dataGridViewTeachers.Rows[i].Cells[0].Value.ToString());
            //намира учителя с този  accauntID
            Teachers teacher = GetTeacherByID(context, accauntID);
            //изтрива този учител
            context.DeleteObject(teacher);
            context.SaveChanges();
            //изтрива избрания ред от dataGridViewAccaunt
            dataGridViewTeachers.Rows.RemoveAt(i); 
        }

        private void buttonBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void FormCreateAccaunts_Load(object sender, EventArgs e)
        {
            buttonEdit.Enabled = false;
        }

      
    }
}
