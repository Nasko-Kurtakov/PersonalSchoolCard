﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace E_school
{
    public partial class FormClasses : Form
    {
        public FormClasses()
        {
            InitializeComponent();
        }

       
        private void buttonBack1_Click(object sender, EventArgs e)
        {
            this.Close();

        }

        private void FormClasses_Load(object sender, EventArgs e)
        {
            //зареждане на комбобокса с профилите
            ESchoolEntities context = new ESchoolEntities();
            var profile = context.Profiles;
            if (profile != null)
            {
                comboBoxProfile.DataSource = profile;
                comboBoxProfile.ValueMember = "ProfileID";
                comboBoxProfile.DisplayMember = "ProfileName";
            }
            //зареждане на таблицата с класните
            var teacher = context.Teachers;
            dataGridViewTeacher.AutoGenerateColumns = false;
            dataGridViewTeacher.DataSource = teacher;

           
        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            ESchoolEntities context = new ESchoolEntities();
            if (!string.IsNullOrEmpty(textBoxClass.Text) && !string.IsNullOrEmpty(textBoxPromYear.Text))
            {
                
                //създаваме обект
                Classes newClass = new Classes();
                //на съответните полета на обекта присвояваме стойностите от текстовите кутии
                int lastYear = int.Parse(textBoxPromYear.Text)-1;
                newClass.ClassName = string.Concat(textBoxClass.Text," ",textBoxParalelka.Text);
                newClass.SchoolYear = string.Format("{0}/{1}", lastYear.ToString(), textBoxPromYear.Text);
                newClass.ProfileID = int.Parse(comboBoxProfile.SelectedValue.ToString());

                // обработка на селектираният ред от dataGridViewTeacher
                int teacherID;//локална променлива
                int i = dataGridViewTeacher.CurrentRow.Index;
                teacherID = (int)dataGridViewTeacher.Rows[i].Cells[0].Value;                                         //от текущо селектирания ред - row.Cells[0].Value
                newClass.TeacherID = teacherID;

                //добавяне на класа в базата и записване на промените
                context.Classes.AddObject(newClass);
                context.SaveChanges();
                MessageBox.Show("Класът е добавена!");
            }
            else
            {
                MessageBox.Show("Грешка! Не сте въвели данни.");
            }
            
        }

       
        private void buttonBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void dataGridViewTeacher_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }                 

        
    }
}
