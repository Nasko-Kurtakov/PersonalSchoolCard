﻿namespace E_school
{
    partial class FormStudent2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormStudent2));
            this.label1 = new System.Windows.Forms.Label();
            this.tabPageDZI_SIP = new System.Windows.Forms.TabPage();
            this.buttonEditZPP = new System.Windows.Forms.Button();
            this.buttonEditDZI = new System.Windows.Forms.Button();
            this.textBoxSrUspZP = new System.Windows.Forms.TextBox();
            this.textBox3ZPP = new System.Windows.Forms.TextBox();
            this.textBox2ZPP = new System.Windows.Forms.TextBox();
            this.textBox1ZPP = new System.Windows.Forms.TextBox();
            this.comboBox3SIP = new System.Windows.Forms.ComboBox();
            this.comboBox2SIP = new System.Windows.Forms.ComboBox();
            this.comboBox2DZI = new System.Windows.Forms.ComboBox();
            this.comboBox1DZI = new System.Windows.Forms.ComboBox();
            this.comboBox1SIP = new System.Windows.Forms.ComboBox();
            this.buttonSaveDZI = new System.Windows.Forms.Button();
            this.buttonSaveZPP = new System.Windows.Forms.Button();
            this.buttonSaveSIP = new System.Windows.Forms.Button();
            this.comboBox4DZI = new System.Windows.Forms.ComboBox();
            this.comboBox3DZI = new System.Windows.Forms.ComboBox();
            this.textBox443 = new System.Windows.Forms.TextBox();
            this.textBox454 = new System.Windows.Forms.TextBox();
            this.textBox526 = new System.Windows.Forms.TextBox();
            this.textBox527 = new System.Windows.Forms.TextBox();
            this.textBox3DZI = new System.Windows.Forms.TextBox();
            this.textBox1DZI = new System.Windows.Forms.TextBox();
            this.textBox2DZI = new System.Windows.Forms.TextBox();
            this.textBoxDZISrUsp = new System.Windows.Forms.TextBox();
            this.textBoxZPPZIP = new System.Windows.Forms.TextBox();
            this.textBox4DZI = new System.Windows.Forms.TextBox();
            this.textBox3DZIw = new System.Windows.Forms.TextBox();
            this.textBox1DZIw = new System.Windows.Forms.TextBox();
            this.textBoxDZISrUspW = new System.Windows.Forms.TextBox();
            this.textBoxZPPZIPW = new System.Windows.Forms.TextBox();
            this.textBox2DZIw = new System.Windows.Forms.TextBox();
            this.textBox4DZIw = new System.Windows.Forms.TextBox();
            this.textBox542 = new System.Windows.Forms.TextBox();
            this.textBox547 = new System.Windows.Forms.TextBox();
            this.textBox73 = new System.Windows.Forms.TextBox();
            this.textBox70 = new System.Windows.Forms.TextBox();
            this.textBox543 = new System.Windows.Forms.TextBox();
            this.textBoxYear = new System.Windows.Forms.TextBox();
            this.textBox545 = new System.Windows.Forms.TextBox();
            this.textBox157 = new System.Windows.Forms.TextBox();
            this.textBox420 = new System.Windows.Forms.TextBox();
            this.textBox121 = new System.Windows.Forms.TextBox();
            this.textBox421 = new System.Windows.Forms.TextBox();
            this.textBox118 = new System.Windows.Forms.TextBox();
            this.textBox422 = new System.Windows.Forms.TextBox();
            this.textBoxOkZPP3 = new System.Windows.Forms.TextBox();
            this.textBoxOkon3 = new System.Windows.Forms.TextBox();
            this.textBox12ZPP3 = new System.Windows.Forms.TextBox();
            this.textBox12SIP3 = new System.Windows.Forms.TextBox();
            this.textBox11ZPP3 = new System.Windows.Forms.TextBox();
            this.textBox11SIP3 = new System.Windows.Forms.TextBox();
            this.textBox10ZPP3 = new System.Windows.Forms.TextBox();
            this.textBox10SIP3 = new System.Windows.Forms.TextBox();
            this.textBox9ZPP3 = new System.Windows.Forms.TextBox();
            this.textBox9SIP3 = new System.Windows.Forms.TextBox();
            this.textBoxOkZPP1 = new System.Windows.Forms.TextBox();
            this.textBoxOkon1 = new System.Windows.Forms.TextBox();
            this.textBox12ZPP1 = new System.Windows.Forms.TextBox();
            this.textBox12SIP1 = new System.Windows.Forms.TextBox();
            this.textBox11ZPP1 = new System.Windows.Forms.TextBox();
            this.textBox11SIP1 = new System.Windows.Forms.TextBox();
            this.textBox10ZPP1 = new System.Windows.Forms.TextBox();
            this.textBox10SIP1 = new System.Windows.Forms.TextBox();
            this.textBox9ZPP1 = new System.Windows.Forms.TextBox();
            this.textBox9SIP1 = new System.Windows.Forms.TextBox();
            this.textBoxOkZPP2 = new System.Windows.Forms.TextBox();
            this.textBoxOkon2 = new System.Windows.Forms.TextBox();
            this.textBox12ZPP2 = new System.Windows.Forms.TextBox();
            this.textBox12SIP2 = new System.Windows.Forms.TextBox();
            this.textBox11ZPP2 = new System.Windows.Forms.TextBox();
            this.textBox11SIP2 = new System.Windows.Forms.TextBox();
            this.textBox10ZPP2 = new System.Windows.Forms.TextBox();
            this.textBox10SIP2 = new System.Windows.Forms.TextBox();
            this.textBox9ZPP2 = new System.Windows.Forms.TextBox();
            this.textBox9SIP2 = new System.Windows.Forms.TextBox();
            this.textBoxOkZPPw3 = new System.Windows.Forms.TextBox();
            this.textBoxOkW3 = new System.Windows.Forms.TextBox();
            this.textBox12ZPPw3 = new System.Windows.Forms.TextBox();
            this.textBox12SIPw3 = new System.Windows.Forms.TextBox();
            this.textBox11ZPPw3 = new System.Windows.Forms.TextBox();
            this.textBox11SIPw3 = new System.Windows.Forms.TextBox();
            this.textBox10ZPPw3 = new System.Windows.Forms.TextBox();
            this.textBox10SIPw3 = new System.Windows.Forms.TextBox();
            this.textBox9ZPPw3 = new System.Windows.Forms.TextBox();
            this.textBox9SIPw3 = new System.Windows.Forms.TextBox();
            this.textBoxOkZPPw1 = new System.Windows.Forms.TextBox();
            this.textBoxOkW1 = new System.Windows.Forms.TextBox();
            this.textBox12ZPPw1 = new System.Windows.Forms.TextBox();
            this.textBox12SIPw1 = new System.Windows.Forms.TextBox();
            this.textBox11ZPPw1 = new System.Windows.Forms.TextBox();
            this.textBox11SIPw1 = new System.Windows.Forms.TextBox();
            this.textBox10ZPPw1 = new System.Windows.Forms.TextBox();
            this.textBox10SIPw1 = new System.Windows.Forms.TextBox();
            this.textBox9ZPPw1 = new System.Windows.Forms.TextBox();
            this.textBox9SIPw1 = new System.Windows.Forms.TextBox();
            this.textBoxOkZPPw2 = new System.Windows.Forms.TextBox();
            this.textBoxOkW2 = new System.Windows.Forms.TextBox();
            this.textBox12ZPPw2 = new System.Windows.Forms.TextBox();
            this.textBox12SIPw2 = new System.Windows.Forms.TextBox();
            this.textBox11ZPPw2 = new System.Windows.Forms.TextBox();
            this.textBox11SIPw2 = new System.Windows.Forms.TextBox();
            this.textBox10ZPPw2 = new System.Windows.Forms.TextBox();
            this.textBox10SIPw2 = new System.Windows.Forms.TextBox();
            this.textBox9ZPPw2 = new System.Windows.Forms.TextBox();
            this.textBox9SIPw2 = new System.Windows.Forms.TextBox();
            this.textBox41 = new System.Windows.Forms.TextBox();
            this.textBox411 = new System.Windows.Forms.TextBox();
            this.textBox40 = new System.Windows.Forms.TextBox();
            this.textBox456 = new System.Windows.Forms.TextBox();
            this.textBox39 = new System.Windows.Forms.TextBox();
            this.textBox445 = new System.Windows.Forms.TextBox();
            this.textBox26 = new System.Windows.Forms.TextBox();
            this.textBox434 = new System.Windows.Forms.TextBox();
            this.textBox22 = new System.Windows.Forms.TextBox();
            this.textBox412 = new System.Windows.Forms.TextBox();
            this.textBox21 = new System.Windows.Forms.TextBox();
            this.textBox466 = new System.Windows.Forms.TextBox();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.textBox455 = new System.Windows.Forms.TextBox();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.textBox444 = new System.Windows.Forms.TextBox();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.textBox433 = new System.Windows.Forms.TextBox();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.textBox546 = new System.Windows.Forms.TextBox();
            this.textBox412kl = new System.Windows.Forms.TextBox();
            this.textBox413 = new System.Windows.Forms.TextBox();
            this.textBox411kl = new System.Windows.Forms.TextBox();
            this.textBox12kl = new System.Windows.Forms.TextBox();
            this.textBox410kl = new System.Windows.Forms.TextBox();
            this.textBox11kl = new System.Windows.Forms.TextBox();
            this.textBox49kl = new System.Windows.Forms.TextBox();
            this.textBox10kl = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox9kl = new System.Windows.Forms.TextBox();
            this.textBox416 = new System.Windows.Forms.TextBox();
            this.buttonSaveSuccess = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPageUspeh = new System.Windows.Forms.TabPage();
            this.buttonEditFinaly = new System.Windows.Forms.Button();
            this.buttonEdit12klas = new System.Windows.Forms.Button();
            this.buttonEdit11klas = new System.Windows.Forms.Button();
            this.buttonEdit10klas = new System.Windows.Forms.Button();
            this.buttonEdit9klas = new System.Windows.Forms.Button();
            this.buttonFinally = new System.Windows.Forms.Button();
            this.comboBox1Lang = new System.Windows.Forms.ComboBox();
            this.buttonSave12kl = new System.Windows.Forms.Button();
            this.buttonSave11kl = new System.Windows.Forms.Button();
            this.buttonSave10kl = new System.Windows.Forms.Button();
            this.buttonSave9kl = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.textBoxStuName = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox600 = new System.Windows.Forms.TextBox();
            this.textBox358 = new System.Windows.Forms.TextBox();
            this.textBox407 = new System.Windows.Forms.TextBox();
            this.textBox409 = new System.Windows.Forms.TextBox();
            this.textBox278 = new System.Windows.Forms.TextBox();
            this.textBox357 = new System.Windows.Forms.TextBox();
            this.textBox408 = new System.Windows.Forms.TextBox();
            this.textBox277 = new System.Windows.Forms.TextBox();
            this.textBox198 = new System.Windows.Forms.TextBox();
            this.textBox525 = new System.Windows.Forms.TextBox();
            this.textBox356 = new System.Windows.Forms.TextBox();
            this.textBox197 = new System.Windows.Forms.TextBox();
            this.textBox801 = new System.Windows.Forms.TextBox();
            this.textBox196 = new System.Windows.Forms.TextBox();
            this.textBox900 = new System.Windows.Forms.TextBox();
            this.textBox800 = new System.Windows.Forms.TextBox();
            this.textBoxFil = new System.Windows.Forms.TextBox();
            this.textBoxIzIzk = new System.Windows.Forms.TextBox();
            this.textBoxPsi = new System.Windows.Forms.TextBox();
            this.textBoxHim = new System.Windows.Forms.TextBox();
            this.textBoxIsto = new System.Windows.Forms.TextBox();
            this.textBoxFVSp = new System.Windows.Forms.TextBox();
            this.textBoxBiol = new System.Windows.Forms.TextBox();
            this.textBoxEtika = new System.Windows.Forms.TextBox();
            this.textBoxInfor = new System.Windows.Forms.TextBox();
            this.textBoxFiz = new System.Windows.Forms.TextBox();
            this.textBox670 = new System.Windows.Forms.TextBox();
            this.textBoxMuz = new System.Windows.Forms.TextBox();
            this.textBoxInfT = new System.Windows.Forms.TextBox();
            this.textBox674 = new System.Windows.Forms.TextBox();
            this.textBoxGeo = new System.Windows.Forms.TextBox();
            this.textBox676 = new System.Windows.Forms.TextBox();
            this.textBox440 = new System.Windows.Forms.TextBox();
            this.textBoxSvL = new System.Windows.Forms.TextBox();
            this.textBox650 = new System.Windows.Forms.TextBox();
            this.textBox677 = new System.Windows.Forms.TextBox();
            this.textBoxMath = new System.Windows.Forms.TextBox();
            this.textBox672 = new System.Windows.Forms.TextBox();
            this.textBox640 = new System.Windows.Forms.TextBox();
            this.textBox673 = new System.Windows.Forms.TextBox();
            this.textBox255 = new System.Windows.Forms.TextBox();
            this.textBox675 = new System.Windows.Forms.TextBox();
            this.textBox430 = new System.Windows.Forms.TextBox();
            this.textBox12Year = new System.Windows.Forms.TextBox();
            this.textBox63 = new System.Windows.Forms.TextBox();
            this.textBox11Year = new System.Windows.Forms.TextBox();
            this.textBox671 = new System.Windows.Forms.TextBox();
            this.textBoxBel = new System.Windows.Forms.TextBox();
            this.textBox10Year = new System.Windows.Forms.TextBox();
            this.textBox250 = new System.Windows.Forms.TextBox();
            this.textBox11ZIP11 = new System.Windows.Forms.TextBox();
            this.textBoxdipZIP11 = new System.Windows.Forms.TextBox();
            this.textBox9Year = new System.Windows.Forms.TextBox();
            this.textBox12ZIP11 = new System.Windows.Forms.TextBox();
            this.textBox11ZIP15 = new System.Windows.Forms.TextBox();
            this.textBoxdipZIP15 = new System.Windows.Forms.TextBox();
            this.textBox10ZIP11 = new System.Windows.Forms.TextBox();
            this.textBox12ZIP15 = new System.Windows.Forms.TextBox();
            this.textBox320 = new System.Windows.Forms.TextBox();
            this.textBox10ZIP15 = new System.Windows.Forms.TextBox();
            this.textBox11ZIP17 = new System.Windows.Forms.TextBox();
            this.textBoxdipZIP17 = new System.Windows.Forms.TextBox();
            this.textBox9ZIP11 = new System.Windows.Forms.TextBox();
            this.textBox12ZIP17 = new System.Windows.Forms.TextBox();
            this.textBox9ZIP15 = new System.Windows.Forms.TextBox();
            this.textBox11ZIP7 = new System.Windows.Forms.TextBox();
            this.textBoxdipZIP7 = new System.Windows.Forms.TextBox();
            this.textBox10ZIP17 = new System.Windows.Forms.TextBox();
            this.textBox12ZIP7 = new System.Windows.Forms.TextBox();
            this.textBox270 = new System.Windows.Forms.TextBox();
            this.textBox11ZIP9 = new System.Windows.Forms.TextBox();
            this.textBoxdipZIP9 = new System.Windows.Forms.TextBox();
            this.textBox10ZIP7 = new System.Windows.Forms.TextBox();
            this.textBox12ZIP9 = new System.Windows.Forms.TextBox();
            this.textBox9ZIP17 = new System.Windows.Forms.TextBox();
            this.textBox10ZIP9 = new System.Windows.Forms.TextBox();
            this.textBox9ZIP7 = new System.Windows.Forms.TextBox();
            this.textBox11ZIP13 = new System.Windows.Forms.TextBox();
            this.textBoxdipZIP13 = new System.Windows.Forms.TextBox();
            this.textBox9ZIP9 = new System.Windows.Forms.TextBox();
            this.textBox12ZIP13 = new System.Windows.Forms.TextBox();
            this.textBox11ZP11 = new System.Windows.Forms.TextBox();
            this.textBoxdipZP11 = new System.Windows.Forms.TextBox();
            this.textBox10ZIP13 = new System.Windows.Forms.TextBox();
            this.textBox12ZP11 = new System.Windows.Forms.TextBox();
            this.textBox230 = new System.Windows.Forms.TextBox();
            this.textBox11ZP15 = new System.Windows.Forms.TextBox();
            this.textBoxdipZP15 = new System.Windows.Forms.TextBox();
            this.textBox10ZP11 = new System.Windows.Forms.TextBox();
            this.textBox12ZP15 = new System.Windows.Forms.TextBox();
            this.textBox9ZIP13 = new System.Windows.Forms.TextBox();
            this.textBox11ZIP5 = new System.Windows.Forms.TextBox();
            this.textBoxdipZIP5 = new System.Windows.Forms.TextBox();
            this.textBox10ZP15 = new System.Windows.Forms.TextBox();
            this.textBox12ZIP5 = new System.Windows.Forms.TextBox();
            this.textBox9ZP11 = new System.Windows.Forms.TextBox();
            this.textBox11ZIP18 = new System.Windows.Forms.TextBox();
            this.textBoxSumOcZIP = new System.Windows.Forms.TextBox();
            this.textBox1300 = new System.Windows.Forms.TextBox();
            this.textBoxdipZIP18 = new System.Windows.Forms.TextBox();
            this.textBox10ZIP5 = new System.Windows.Forms.TextBox();
            this.textBox12ZIP18 = new System.Windows.Forms.TextBox();
            this.textBox9ZP15 = new System.Windows.Forms.TextBox();
            this.textBox11ZP7 = new System.Windows.Forms.TextBox();
            this.textBoxdipZP7 = new System.Windows.Forms.TextBox();
            this.textBox10ZIP18 = new System.Windows.Forms.TextBox();
            this.textBox12ZP7 = new System.Windows.Forms.TextBox();
            this.textBox9ZIP5 = new System.Windows.Forms.TextBox();
            this.textBox11ZIP10 = new System.Windows.Forms.TextBox();
            this.textBoxdipZIP10 = new System.Windows.Forms.TextBox();
            this.textBox10ZP7 = new System.Windows.Forms.TextBox();
            this.textBox12ZIP10 = new System.Windows.Forms.TextBox();
            this.textBox9ZIP18 = new System.Windows.Forms.TextBox();
            this.textBox11ZP17 = new System.Windows.Forms.TextBox();
            this.textBoxdipZP17 = new System.Windows.Forms.TextBox();
            this.textBox10ZIP10 = new System.Windows.Forms.TextBox();
            this.textBox12ZP17 = new System.Windows.Forms.TextBox();
            this.textBox9ZP7 = new System.Windows.Forms.TextBox();
            this.textBox10ZP17 = new System.Windows.Forms.TextBox();
            this.textBox11ZIP14 = new System.Windows.Forms.TextBox();
            this.textBoxdipZIP14 = new System.Windows.Forms.TextBox();
            this.textBox9ZIP10 = new System.Windows.Forms.TextBox();
            this.textBox12ZIP14 = new System.Windows.Forms.TextBox();
            this.textBox9ZP17 = new System.Windows.Forms.TextBox();
            this.textBox11ZP9 = new System.Windows.Forms.TextBox();
            this.textBoxdipZP9 = new System.Windows.Forms.TextBox();
            this.textBox10ZIP14 = new System.Windows.Forms.TextBox();
            this.textBox12ZP9 = new System.Windows.Forms.TextBox();
            this.textBox500 = new System.Windows.Forms.TextBox();
            this.textBox11ZP18 = new System.Windows.Forms.TextBox();
            this.textBoxSrZP = new System.Windows.Forms.TextBox();
            this.textBoxdipZP18 = new System.Windows.Forms.TextBox();
            this.textBox10ZP9 = new System.Windows.Forms.TextBox();
            this.textBox12ZP18 = new System.Windows.Forms.TextBox();
            this.textBox9ZIP14 = new System.Windows.Forms.TextBox();
            this.textBox11ZIP6 = new System.Windows.Forms.TextBox();
            this.textBoxdipZIP6 = new System.Windows.Forms.TextBox();
            this.textBox10ZP18 = new System.Windows.Forms.TextBox();
            this.textBox12ZIP6 = new System.Windows.Forms.TextBox();
            this.textBox9ZP9 = new System.Windows.Forms.TextBox();
            this.textBox11ZP13 = new System.Windows.Forms.TextBox();
            this.textBoxdipZP13 = new System.Windows.Forms.TextBox();
            this.textBox10ZIP6 = new System.Windows.Forms.TextBox();
            this.textBox12ZP13 = new System.Windows.Forms.TextBox();
            this.textBox9ZP18 = new System.Windows.Forms.TextBox();
            this.textBox11ZP10 = new System.Windows.Forms.TextBox();
            this.textBoxdipZP10 = new System.Windows.Forms.TextBox();
            this.textBox10ZP13 = new System.Windows.Forms.TextBox();
            this.textBox12ZP10 = new System.Windows.Forms.TextBox();
            this.textBox9ZIP6 = new System.Windows.Forms.TextBox();
            this.textBox11ZIP16 = new System.Windows.Forms.TextBox();
            this.textBoxdipZIP16 = new System.Windows.Forms.TextBox();
            this.textBox10ZP10 = new System.Windows.Forms.TextBox();
            this.textBox12ZIP16 = new System.Windows.Forms.TextBox();
            this.textBox9ZP13 = new System.Windows.Forms.TextBox();
            this.textBox11ZP5 = new System.Windows.Forms.TextBox();
            this.textBoxdipZP5 = new System.Windows.Forms.TextBox();
            this.textBox10ZIP16 = new System.Windows.Forms.TextBox();
            this.textBox12ZP5 = new System.Windows.Forms.TextBox();
            this.textBox9ZP10 = new System.Windows.Forms.TextBox();
            this.textBox11ZP14 = new System.Windows.Forms.TextBox();
            this.textBoxdipZP14 = new System.Windows.Forms.TextBox();
            this.textBox10ZP5 = new System.Windows.Forms.TextBox();
            this.textBox12ZP14 = new System.Windows.Forms.TextBox();
            this.textBox9ZIP16 = new System.Windows.Forms.TextBox();
            this.textBox11ZIP8 = new System.Windows.Forms.TextBox();
            this.textBoxdipZIP8 = new System.Windows.Forms.TextBox();
            this.textBox10ZP14 = new System.Windows.Forms.TextBox();
            this.textBox12ZIP8 = new System.Windows.Forms.TextBox();
            this.textBox9ZP5 = new System.Windows.Forms.TextBox();
            this.textBox10ZIP8 = new System.Windows.Forms.TextBox();
            this.textBox9ZP14 = new System.Windows.Forms.TextBox();
            this.textBox11ZP6 = new System.Windows.Forms.TextBox();
            this.textBoxdipZP6 = new System.Windows.Forms.TextBox();
            this.textBox12ZP6 = new System.Windows.Forms.TextBox();
            this.textBox9ZIP8 = new System.Windows.Forms.TextBox();
            this.textBox11ZIP12 = new System.Windows.Forms.TextBox();
            this.textBoxdipZIP12 = new System.Windows.Forms.TextBox();
            this.textBox10ZP6 = new System.Windows.Forms.TextBox();
            this.textBox12ZIP12 = new System.Windows.Forms.TextBox();
            this.textBox11ZIPFil1 = new System.Windows.Forms.TextBox();
            this.textBoxdipFilZIP1 = new System.Windows.Forms.TextBox();
            this.textBox10ZIP12 = new System.Windows.Forms.TextBox();
            this.textBox246 = new System.Windows.Forms.TextBox();
            this.textBox9ZP6 = new System.Windows.Forms.TextBox();
            this.textBox11ZP16 = new System.Windows.Forms.TextBox();
            this.textBoxdipZP16 = new System.Windows.Forms.TextBox();
            this.textBox166 = new System.Windows.Forms.TextBox();
            this.textBox12ZP16 = new System.Windows.Forms.TextBox();
            this.textBox9ZIP12 = new System.Windows.Forms.TextBox();
            this.textBox11ZIP4 = new System.Windows.Forms.TextBox();
            this.textBoxdipZIP4 = new System.Windows.Forms.TextBox();
            this.textBox10ZP16 = new System.Windows.Forms.TextBox();
            this.textBox12ZIP4 = new System.Windows.Forms.TextBox();
            this.textBox55 = new System.Windows.Forms.TextBox();
            this.textBox11ZIPHim1 = new System.Windows.Forms.TextBox();
            this.textBoxdipHimZIP1 = new System.Windows.Forms.TextBox();
            this.textBox10ZIP4 = new System.Windows.Forms.TextBox();
            this.textBox12ZIPHim1 = new System.Windows.Forms.TextBox();
            this.textBox9ZP16 = new System.Windows.Forms.TextBox();
            this.textBox11ZP8 = new System.Windows.Forms.TextBox();
            this.textBoxdipZP8 = new System.Windows.Forms.TextBox();
            this.textBox10ZIPHim1 = new System.Windows.Forms.TextBox();
            this.textBox12ZP8 = new System.Windows.Forms.TextBox();
            this.textBox9ZIP4 = new System.Windows.Forms.TextBox();
            this.textBox321 = new System.Windows.Forms.TextBox();
            this.textBoxdipIzobrZIP1 = new System.Windows.Forms.TextBox();
            this.textBox10ZP8 = new System.Windows.Forms.TextBox();
            this.textBox241 = new System.Windows.Forms.TextBox();
            this.textBox9ZIPHim1 = new System.Windows.Forms.TextBox();
            this.textBox11ZIPIst1 = new System.Windows.Forms.TextBox();
            this.textBoxdipIstZIP1 = new System.Windows.Forms.TextBox();
            this.textBox161 = new System.Windows.Forms.TextBox();
            this.textBox12ZIPIst1 = new System.Windows.Forms.TextBox();
            this.textBox9ZP8 = new System.Windows.Forms.TextBox();
            this.textBox11ZP12 = new System.Windows.Forms.TextBox();
            this.textBoxdipZP12 = new System.Windows.Forms.TextBox();
            this.textBox10ZIPIst1 = new System.Windows.Forms.TextBox();
            this.textBox12ZP12 = new System.Windows.Forms.TextBox();
            this.textBox85 = new System.Windows.Forms.TextBox();
            this.textBox318 = new System.Windows.Forms.TextBox();
            this.textBoxdipPsZIP1 = new System.Windows.Forms.TextBox();
            this.textBox10ZP12 = new System.Windows.Forms.TextBox();
            this.textBox238 = new System.Windows.Forms.TextBox();
            this.textBox9ZIPIst1 = new System.Windows.Forms.TextBox();
            this.textBox10ZIPPs1 = new System.Windows.Forms.TextBox();
            this.textBox9ZP12 = new System.Windows.Forms.TextBox();
            this.textBox11ZP4 = new System.Windows.Forms.TextBox();
            this.textBoxdipZP4 = new System.Windows.Forms.TextBox();
            this.textBox12ZP4 = new System.Windows.Forms.TextBox();
            this.textBox9ZIPPs1 = new System.Windows.Forms.TextBox();
            this.textBox11ZIPBio1 = new System.Windows.Forms.TextBox();
            this.textBoxdipBioZIP1 = new System.Windows.Forms.TextBox();
            this.textBox10ZP4 = new System.Windows.Forms.TextBox();
            this.textBox12ZIPBio1 = new System.Windows.Forms.TextBox();
            this.textBox11Fil1 = new System.Windows.Forms.TextBox();
            this.textBoxdipFil1 = new System.Windows.Forms.TextBox();
            this.textBox10ZIPBio1 = new System.Windows.Forms.TextBox();
            this.textBox234 = new System.Windows.Forms.TextBox();
            this.textBox9ZP4 = new System.Windows.Forms.TextBox();
            this.textBox11Him1 = new System.Windows.Forms.TextBox();
            this.textBoxdipHim1 = new System.Windows.Forms.TextBox();
            this.textBox154 = new System.Windows.Forms.TextBox();
            this.textBox12Him1 = new System.Windows.Forms.TextBox();
            this.textBox9BioZIP1 = new System.Windows.Forms.TextBox();
            this.textBox11ZIPInf1 = new System.Windows.Forms.TextBox();
            this.textBoxdipInfZIP1 = new System.Windows.Forms.TextBox();
            this.textBox10Him1 = new System.Windows.Forms.TextBox();
            this.textBox12ZIPInf1 = new System.Windows.Forms.TextBox();
            this.textBox52 = new System.Windows.Forms.TextBox();
            this.textBoxBrOcZIP = new System.Windows.Forms.TextBox();
            this.textBox11ZIPFV1 = new System.Windows.Forms.TextBox();
            this.textBox1100 = new System.Windows.Forms.TextBox();
            this.textBoxdipFVZIP1 = new System.Windows.Forms.TextBox();
            this.textBox10ZIPInf1 = new System.Windows.Forms.TextBox();
            this.textBox231 = new System.Windows.Forms.TextBox();
            this.textBox9Him1 = new System.Windows.Forms.TextBox();
            this.textBox11Ist1 = new System.Windows.Forms.TextBox();
            this.textBoxdipIst1 = new System.Windows.Forms.TextBox();
            this.textBox10ZIPFV1 = new System.Windows.Forms.TextBox();
            this.textBox12Ist1 = new System.Windows.Forms.TextBox();
            this.textBox9ZIPInf1 = new System.Windows.Forms.TextBox();
            this.textBox309 = new System.Windows.Forms.TextBox();
            this.textBoxdipEtZIP1 = new System.Windows.Forms.TextBox();
            this.textBox10Ist1 = new System.Windows.Forms.TextBox();
            this.textBox229 = new System.Windows.Forms.TextBox();
            this.textBox9ZIPFv1 = new System.Windows.Forms.TextBox();
            this.textBox308 = new System.Windows.Forms.TextBox();
            this.textBoxdipIzobr1 = new System.Windows.Forms.TextBox();
            this.textBox10ZIPEt1 = new System.Windows.Forms.TextBox();
            this.textBox228 = new System.Windows.Forms.TextBox();
            this.textBox9Ist1 = new System.Windows.Forms.TextBox();
            this.textBox148 = new System.Windows.Forms.TextBox();
            this.textBox11ZIPFz1 = new System.Windows.Forms.TextBox();
            this.textBoxdipFzZIP1 = new System.Windows.Forms.TextBox();
            this.textBox9ZIPEt1 = new System.Windows.Forms.TextBox();
            this.textBox12ZIPFz1 = new System.Windows.Forms.TextBox();
            this.textBox9Izobr1 = new System.Windows.Forms.TextBox();
            this.textBox11Ps1 = new System.Windows.Forms.TextBox();
            this.textBoxdipPs1 = new System.Windows.Forms.TextBox();
            this.textBox10ZIPFz1 = new System.Windows.Forms.TextBox();
            this.textBox226 = new System.Windows.Forms.TextBox();
            this.textBox450 = new System.Windows.Forms.TextBox();
            this.textBoxSrZPW = new System.Windows.Forms.TextBox();
            this.textBox11FV1 = new System.Windows.Forms.TextBox();
            this.textBoxdipFV1 = new System.Windows.Forms.TextBox();
            this.textBox10Ps1 = new System.Windows.Forms.TextBox();
            this.textBox12FV1 = new System.Windows.Forms.TextBox();
            this.textBox9ZIPFz1 = new System.Windows.Forms.TextBox();
            this.textBox11ZIPIT1 = new System.Windows.Forms.TextBox();
            this.textBoxdipITZIP1 = new System.Windows.Forms.TextBox();
            this.textBox10FV1 = new System.Windows.Forms.TextBox();
            this.textBox12ZIPIT1 = new System.Windows.Forms.TextBox();
            this.textBox9Ps1 = new System.Windows.Forms.TextBox();
            this.textBox11Bio1 = new System.Windows.Forms.TextBox();
            this.textBoxdipBio1 = new System.Windows.Forms.TextBox();
            this.textBox10ZIPIT1 = new System.Windows.Forms.TextBox();
            this.textBox12Bio1 = new System.Windows.Forms.TextBox();
            this.textBox9FV1 = new System.Windows.Forms.TextBox();
            this.textBox302 = new System.Windows.Forms.TextBox();
            this.textBoxdipEt1 = new System.Windows.Forms.TextBox();
            this.textBox10Bio1 = new System.Windows.Forms.TextBox();
            this.textBox222 = new System.Windows.Forms.TextBox();
            this.textBox9ZIPIT1 = new System.Windows.Forms.TextBox();
            this.textBox301 = new System.Windows.Forms.TextBox();
            this.textBoxdipMzZIP1 = new System.Windows.Forms.TextBox();
            this.textBox10Et1 = new System.Windows.Forms.TextBox();
            this.textBox221 = new System.Windows.Forms.TextBox();
            this.textBox9Bio1 = new System.Windows.Forms.TextBox();
            this.textBox11Inf1 = new System.Windows.Forms.TextBox();
            this.textBoxdipInf1 = new System.Windows.Forms.TextBox();
            this.textBox141 = new System.Windows.Forms.TextBox();
            this.textBox12Inf1 = new System.Windows.Forms.TextBox();
            this.textBox9Et1 = new System.Windows.Forms.TextBox();
            this.textBox11Fz1 = new System.Windows.Forms.TextBox();
            this.textBoxdipFz1 = new System.Windows.Forms.TextBox();
            this.textBox10Inf1 = new System.Windows.Forms.TextBox();
            this.textBox12Fz1 = new System.Windows.Forms.TextBox();
            this.textBox75 = new System.Windows.Forms.TextBox();
            this.textBox11ZIPG1 = new System.Windows.Forms.TextBox();
            this.textBoxdipGZIP1 = new System.Windows.Forms.TextBox();
            this.textBox10Fz1 = new System.Windows.Forms.TextBox();
            this.textBox12ZIPG1 = new System.Windows.Forms.TextBox();
            this.textBox9Inf1 = new System.Windows.Forms.TextBox();
            this.textBox297 = new System.Windows.Forms.TextBox();
            this.textBoxdipMz1 = new System.Windows.Forms.TextBox();
            this.textBox10ZIPG1 = new System.Windows.Forms.TextBox();
            this.textBox217 = new System.Windows.Forms.TextBox();
            this.textBox9Fz1 = new System.Windows.Forms.TextBox();
            this.textBox11IT1 = new System.Windows.Forms.TextBox();
            this.textBoxdipIT1 = new System.Windows.Forms.TextBox();
            this.textBox137 = new System.Windows.Forms.TextBox();
            this.textBox12IT1 = new System.Windows.Forms.TextBox();
            this.textBox9ZIPG1 = new System.Windows.Forms.TextBox();
            this.textBox295 = new System.Windows.Forms.TextBox();
            this.textBoxdipSvZIP1 = new System.Windows.Forms.TextBox();
            this.textBox10IT1 = new System.Windows.Forms.TextBox();
            this.textBox12ZIPSv1 = new System.Windows.Forms.TextBox();
            this.textBox9Mz1 = new System.Windows.Forms.TextBox();
            this.textBox11G1 = new System.Windows.Forms.TextBox();
            this.textBoxdipG1 = new System.Windows.Forms.TextBox();
            this.textBox135 = new System.Windows.Forms.TextBox();
            this.textBox12G1 = new System.Windows.Forms.TextBox();
            this.textBox9IT1 = new System.Windows.Forms.TextBox();
            this.textBox293 = new System.Windows.Forms.TextBox();
            this.textBoxdipSv1 = new System.Windows.Forms.TextBox();
            this.textBox10G1 = new System.Windows.Forms.TextBox();
            this.textBox12Sv1 = new System.Windows.Forms.TextBox();
            this.textBox72 = new System.Windows.Forms.TextBox();
            this.textBox11ZIPMat1 = new System.Windows.Forms.TextBox();
            this.textBoxdipMatZIP1 = new System.Windows.Forms.TextBox();
            this.textBox133 = new System.Windows.Forms.TextBox();
            this.textBox12ZIPMat1 = new System.Windows.Forms.TextBox();
            this.textBox9G1 = new System.Windows.Forms.TextBox();
            this.textBox11Mat1 = new System.Windows.Forms.TextBox();
            this.textBoxdipMat1 = new System.Windows.Forms.TextBox();
            this.textBox10ZIPMat1 = new System.Windows.Forms.TextBox();
            this.textBox12Mat1 = new System.Windows.Forms.TextBox();
            this.textBox71 = new System.Windows.Forms.TextBox();
            this.textBox11ZIP3 = new System.Windows.Forms.TextBox();
            this.textBoxdipZIP3 = new System.Windows.Forms.TextBox();
            this.textBox10Mat1 = new System.Windows.Forms.TextBox();
            this.textBox12ZIP3 = new System.Windows.Forms.TextBox();
            this.textBox9ZIPMat1 = new System.Windows.Forms.TextBox();
            this.textBox11ZP3 = new System.Windows.Forms.TextBox();
            this.textBoxdipZP3 = new System.Windows.Forms.TextBox();
            this.textBox10ZIP3 = new System.Windows.Forms.TextBox();
            this.textBox12ZP3 = new System.Windows.Forms.TextBox();
            this.textBox9Mat1 = new System.Windows.Forms.TextBox();
            this.textBox11ZIP2 = new System.Windows.Forms.TextBox();
            this.textBoxdipZIP2 = new System.Windows.Forms.TextBox();
            this.textBox10ZP3 = new System.Windows.Forms.TextBox();
            this.textBox12ZIP2 = new System.Windows.Forms.TextBox();
            this.textBox9ZIP3 = new System.Windows.Forms.TextBox();
            this.textBox11ZP2 = new System.Windows.Forms.TextBox();
            this.textBoxdipZP2 = new System.Windows.Forms.TextBox();
            this.textBox10ZIP2 = new System.Windows.Forms.TextBox();
            this.textBox12ZP2 = new System.Windows.Forms.TextBox();
            this.textBox9ZP3 = new System.Windows.Forms.TextBox();
            this.textBox11ZIP1 = new System.Windows.Forms.TextBox();
            this.textBoxdipZIP1 = new System.Windows.Forms.TextBox();
            this.textBox10ZP2 = new System.Windows.Forms.TextBox();
            this.textBox12ZIP1 = new System.Windows.Forms.TextBox();
            this.textBox9ZIP2 = new System.Windows.Forms.TextBox();
            this.textBox11ZP1 = new System.Windows.Forms.TextBox();
            this.textBoxdipZP1 = new System.Windows.Forms.TextBox();
            this.textBox10ZIP1 = new System.Windows.Forms.TextBox();
            this.textBox12ZP1 = new System.Windows.Forms.TextBox();
            this.textBox9ZP2 = new System.Windows.Forms.TextBox();
            this.textBox11ZIP2Lang1 = new System.Windows.Forms.TextBox();
            this.textBoxdip2LangZIP1 = new System.Windows.Forms.TextBox();
            this.textBox10ZP1 = new System.Windows.Forms.TextBox();
            this.textBox12ZIP2Lang1 = new System.Windows.Forms.TextBox();
            this.textBox9ZIP1 = new System.Windows.Forms.TextBox();
            this.textBox112Lang1 = new System.Windows.Forms.TextBox();
            this.textBoxdip2Lang1 = new System.Windows.Forms.TextBox();
            this.textBox10ZIP2Lang1 = new System.Windows.Forms.TextBox();
            this.textBox122Lang1 = new System.Windows.Forms.TextBox();
            this.textBox9ZP1 = new System.Windows.Forms.TextBox();
            this.textBox11ZIP1Lang1 = new System.Windows.Forms.TextBox();
            this.textBoxdip1LangZIP1 = new System.Windows.Forms.TextBox();
            this.textBox102Lang1 = new System.Windows.Forms.TextBox();
            this.textBox121LangZIP1 = new System.Windows.Forms.TextBox();
            this.textBox92LangZIP1 = new System.Windows.Forms.TextBox();
            this.textBox111Lang1 = new System.Windows.Forms.TextBox();
            this.textBoxdip1Lang1 = new System.Windows.Forms.TextBox();
            this.textBox10ZIP1Lang1 = new System.Windows.Forms.TextBox();
            this.textBox121Lang1 = new System.Windows.Forms.TextBox();
            this.textBox92Lang1 = new System.Windows.Forms.TextBox();
            this.textBox11BelZIP1 = new System.Windows.Forms.TextBox();
            this.textBoxdipBELZIP1 = new System.Windows.Forms.TextBox();
            this.textBox101Lang1 = new System.Windows.Forms.TextBox();
            this.textBox12BelZIP1 = new System.Windows.Forms.TextBox();
            this.textBox9ZIP1Lang1 = new System.Windows.Forms.TextBox();
            this.textBox11Bel1 = new System.Windows.Forms.TextBox();
            this.textBoxdipBEL1 = new System.Windows.Forms.TextBox();
            this.textBox10BelZIP1 = new System.Windows.Forms.TextBox();
            this.textBox12Bel1 = new System.Windows.Forms.TextBox();
            this.textBox91Lang1 = new System.Windows.Forms.TextBox();
            this.textBox10Bel1 = new System.Windows.Forms.TextBox();
            this.textBox9BelZIP1 = new System.Windows.Forms.TextBox();
            this.textBox9Bel1 = new System.Windows.Forms.TextBox();
            this.comboBox2Lang = new System.Windows.Forms.ComboBox();
            this.buttonClose = new System.Windows.Forms.Button();
            this.textBoxName = new System.Windows.Forms.TextBox();
            this.textBoxNumber = new System.Windows.Forms.TextBox();
            this.buttonShow = new System.Windows.Forms.Button();
            this.textBoxSrUspeh = new System.Windows.Forms.TextBox();
            this.toolTipL = new System.Windows.Forms.ToolTip(this.components);
            this.textBoxSrUspehW = new System.Windows.Forms.TextBox();
            this.buttonEdit = new System.Windows.Forms.Button();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPageDZI_SIP.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPageUspeh.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Arial Black", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(406, 22);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(186, 22);
            this.label1.TabIndex = 800;
            this.label1.Text = "Успех от дипломата:";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // tabPageDZI_SIP
            // 
            this.tabPageDZI_SIP.Controls.Add(this.buttonEditZPP);
            this.tabPageDZI_SIP.Controls.Add(this.buttonEditDZI);
            this.tabPageDZI_SIP.Controls.Add(this.textBoxSrUspZP);
            this.tabPageDZI_SIP.Controls.Add(this.textBox3ZPP);
            this.tabPageDZI_SIP.Controls.Add(this.textBox2ZPP);
            this.tabPageDZI_SIP.Controls.Add(this.textBox1ZPP);
            this.tabPageDZI_SIP.Controls.Add(this.comboBox3SIP);
            this.tabPageDZI_SIP.Controls.Add(this.comboBox2SIP);
            this.tabPageDZI_SIP.Controls.Add(this.comboBox2DZI);
            this.tabPageDZI_SIP.Controls.Add(this.comboBox1DZI);
            this.tabPageDZI_SIP.Controls.Add(this.comboBox1SIP);
            this.tabPageDZI_SIP.Controls.Add(this.buttonSaveDZI);
            this.tabPageDZI_SIP.Controls.Add(this.buttonSaveZPP);
            this.tabPageDZI_SIP.Controls.Add(this.buttonSaveSIP);
            this.tabPageDZI_SIP.Controls.Add(this.comboBox4DZI);
            this.tabPageDZI_SIP.Controls.Add(this.comboBox3DZI);
            this.tabPageDZI_SIP.Controls.Add(this.textBox443);
            this.tabPageDZI_SIP.Controls.Add(this.textBox454);
            this.tabPageDZI_SIP.Controls.Add(this.textBox526);
            this.tabPageDZI_SIP.Controls.Add(this.textBox527);
            this.tabPageDZI_SIP.Controls.Add(this.textBox3DZI);
            this.tabPageDZI_SIP.Controls.Add(this.textBox1DZI);
            this.tabPageDZI_SIP.Controls.Add(this.textBox2DZI);
            this.tabPageDZI_SIP.Controls.Add(this.textBoxDZISrUsp);
            this.tabPageDZI_SIP.Controls.Add(this.textBoxZPPZIP);
            this.tabPageDZI_SIP.Controls.Add(this.textBox4DZI);
            this.tabPageDZI_SIP.Controls.Add(this.textBox3DZIw);
            this.tabPageDZI_SIP.Controls.Add(this.textBox1DZIw);
            this.tabPageDZI_SIP.Controls.Add(this.textBoxDZISrUspW);
            this.tabPageDZI_SIP.Controls.Add(this.textBoxZPPZIPW);
            this.tabPageDZI_SIP.Controls.Add(this.textBox2DZIw);
            this.tabPageDZI_SIP.Controls.Add(this.textBox4DZIw);
            this.tabPageDZI_SIP.Controls.Add(this.textBox542);
            this.tabPageDZI_SIP.Controls.Add(this.textBox547);
            this.tabPageDZI_SIP.Controls.Add(this.textBox73);
            this.tabPageDZI_SIP.Controls.Add(this.textBox70);
            this.tabPageDZI_SIP.Controls.Add(this.textBox543);
            this.tabPageDZI_SIP.Controls.Add(this.textBoxYear);
            this.tabPageDZI_SIP.Controls.Add(this.textBox545);
            this.tabPageDZI_SIP.Controls.Add(this.textBox157);
            this.tabPageDZI_SIP.Controls.Add(this.textBox420);
            this.tabPageDZI_SIP.Controls.Add(this.textBox121);
            this.tabPageDZI_SIP.Controls.Add(this.textBox421);
            this.tabPageDZI_SIP.Controls.Add(this.textBox118);
            this.tabPageDZI_SIP.Controls.Add(this.textBox422);
            this.tabPageDZI_SIP.Controls.Add(this.textBoxOkZPP3);
            this.tabPageDZI_SIP.Controls.Add(this.textBoxOkon3);
            this.tabPageDZI_SIP.Controls.Add(this.textBox12ZPP3);
            this.tabPageDZI_SIP.Controls.Add(this.textBox12SIP3);
            this.tabPageDZI_SIP.Controls.Add(this.textBox11ZPP3);
            this.tabPageDZI_SIP.Controls.Add(this.textBox11SIP3);
            this.tabPageDZI_SIP.Controls.Add(this.textBox10ZPP3);
            this.tabPageDZI_SIP.Controls.Add(this.textBox10SIP3);
            this.tabPageDZI_SIP.Controls.Add(this.textBox9ZPP3);
            this.tabPageDZI_SIP.Controls.Add(this.textBox9SIP3);
            this.tabPageDZI_SIP.Controls.Add(this.textBoxOkZPP1);
            this.tabPageDZI_SIP.Controls.Add(this.textBoxOkon1);
            this.tabPageDZI_SIP.Controls.Add(this.textBox12ZPP1);
            this.tabPageDZI_SIP.Controls.Add(this.textBox12SIP1);
            this.tabPageDZI_SIP.Controls.Add(this.textBox11ZPP1);
            this.tabPageDZI_SIP.Controls.Add(this.textBox11SIP1);
            this.tabPageDZI_SIP.Controls.Add(this.textBox10ZPP1);
            this.tabPageDZI_SIP.Controls.Add(this.textBox10SIP1);
            this.tabPageDZI_SIP.Controls.Add(this.textBox9ZPP1);
            this.tabPageDZI_SIP.Controls.Add(this.textBox9SIP1);
            this.tabPageDZI_SIP.Controls.Add(this.textBoxOkZPP2);
            this.tabPageDZI_SIP.Controls.Add(this.textBoxOkon2);
            this.tabPageDZI_SIP.Controls.Add(this.textBox12ZPP2);
            this.tabPageDZI_SIP.Controls.Add(this.textBox12SIP2);
            this.tabPageDZI_SIP.Controls.Add(this.textBox11ZPP2);
            this.tabPageDZI_SIP.Controls.Add(this.textBox11SIP2);
            this.tabPageDZI_SIP.Controls.Add(this.textBox10ZPP2);
            this.tabPageDZI_SIP.Controls.Add(this.textBox10SIP2);
            this.tabPageDZI_SIP.Controls.Add(this.textBox9ZPP2);
            this.tabPageDZI_SIP.Controls.Add(this.textBox9SIP2);
            this.tabPageDZI_SIP.Controls.Add(this.textBoxOkZPPw3);
            this.tabPageDZI_SIP.Controls.Add(this.textBoxOkW3);
            this.tabPageDZI_SIP.Controls.Add(this.textBox12ZPPw3);
            this.tabPageDZI_SIP.Controls.Add(this.textBox12SIPw3);
            this.tabPageDZI_SIP.Controls.Add(this.textBox11ZPPw3);
            this.tabPageDZI_SIP.Controls.Add(this.textBox11SIPw3);
            this.tabPageDZI_SIP.Controls.Add(this.textBox10ZPPw3);
            this.tabPageDZI_SIP.Controls.Add(this.textBox10SIPw3);
            this.tabPageDZI_SIP.Controls.Add(this.textBox9ZPPw3);
            this.tabPageDZI_SIP.Controls.Add(this.textBox9SIPw3);
            this.tabPageDZI_SIP.Controls.Add(this.textBoxOkZPPw1);
            this.tabPageDZI_SIP.Controls.Add(this.textBoxOkW1);
            this.tabPageDZI_SIP.Controls.Add(this.textBox12ZPPw1);
            this.tabPageDZI_SIP.Controls.Add(this.textBox12SIPw1);
            this.tabPageDZI_SIP.Controls.Add(this.textBox11ZPPw1);
            this.tabPageDZI_SIP.Controls.Add(this.textBox11SIPw1);
            this.tabPageDZI_SIP.Controls.Add(this.textBox10ZPPw1);
            this.tabPageDZI_SIP.Controls.Add(this.textBox10SIPw1);
            this.tabPageDZI_SIP.Controls.Add(this.textBox9ZPPw1);
            this.tabPageDZI_SIP.Controls.Add(this.textBox9SIPw1);
            this.tabPageDZI_SIP.Controls.Add(this.textBoxOkZPPw2);
            this.tabPageDZI_SIP.Controls.Add(this.textBoxOkW2);
            this.tabPageDZI_SIP.Controls.Add(this.textBox12ZPPw2);
            this.tabPageDZI_SIP.Controls.Add(this.textBox12SIPw2);
            this.tabPageDZI_SIP.Controls.Add(this.textBox11ZPPw2);
            this.tabPageDZI_SIP.Controls.Add(this.textBox11SIPw2);
            this.tabPageDZI_SIP.Controls.Add(this.textBox10ZPPw2);
            this.tabPageDZI_SIP.Controls.Add(this.textBox10SIPw2);
            this.tabPageDZI_SIP.Controls.Add(this.textBox9ZPPw2);
            this.tabPageDZI_SIP.Controls.Add(this.textBox9SIPw2);
            this.tabPageDZI_SIP.Controls.Add(this.textBox41);
            this.tabPageDZI_SIP.Controls.Add(this.textBox411);
            this.tabPageDZI_SIP.Controls.Add(this.textBox40);
            this.tabPageDZI_SIP.Controls.Add(this.textBox456);
            this.tabPageDZI_SIP.Controls.Add(this.textBox39);
            this.tabPageDZI_SIP.Controls.Add(this.textBox445);
            this.tabPageDZI_SIP.Controls.Add(this.textBox26);
            this.tabPageDZI_SIP.Controls.Add(this.textBox434);
            this.tabPageDZI_SIP.Controls.Add(this.textBox22);
            this.tabPageDZI_SIP.Controls.Add(this.textBox412);
            this.tabPageDZI_SIP.Controls.Add(this.textBox21);
            this.tabPageDZI_SIP.Controls.Add(this.textBox466);
            this.tabPageDZI_SIP.Controls.Add(this.textBox19);
            this.tabPageDZI_SIP.Controls.Add(this.textBox455);
            this.tabPageDZI_SIP.Controls.Add(this.textBox18);
            this.tabPageDZI_SIP.Controls.Add(this.textBox444);
            this.tabPageDZI_SIP.Controls.Add(this.textBox17);
            this.tabPageDZI_SIP.Controls.Add(this.textBox433);
            this.tabPageDZI_SIP.Controls.Add(this.textBox16);
            this.tabPageDZI_SIP.Controls.Add(this.textBox14);
            this.tabPageDZI_SIP.Controls.Add(this.textBox546);
            this.tabPageDZI_SIP.Controls.Add(this.textBox412kl);
            this.tabPageDZI_SIP.Controls.Add(this.textBox413);
            this.tabPageDZI_SIP.Controls.Add(this.textBox411kl);
            this.tabPageDZI_SIP.Controls.Add(this.textBox12kl);
            this.tabPageDZI_SIP.Controls.Add(this.textBox410kl);
            this.tabPageDZI_SIP.Controls.Add(this.textBox11kl);
            this.tabPageDZI_SIP.Controls.Add(this.textBox49kl);
            this.tabPageDZI_SIP.Controls.Add(this.textBox10kl);
            this.tabPageDZI_SIP.Controls.Add(this.textBox3);
            this.tabPageDZI_SIP.Controls.Add(this.textBox9kl);
            this.tabPageDZI_SIP.Controls.Add(this.textBox416);
            this.tabPageDZI_SIP.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tabPageDZI_SIP.Location = new System.Drawing.Point(4, 22);
            this.tabPageDZI_SIP.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tabPageDZI_SIP.Name = "tabPageDZI_SIP";
            this.tabPageDZI_SIP.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tabPageDZI_SIP.Size = new System.Drawing.Size(1242, 724);
            this.tabPageDZI_SIP.TabIndex = 1;
            this.tabPageDZI_SIP.Text = "Успех от свободноизбираема подготовка и  от задължителните държ. зрелостни изпити" +
    "";
            this.tabPageDZI_SIP.UseVisualStyleBackColor = true;
            this.tabPageDZI_SIP.Paint += new System.Windows.Forms.PaintEventHandler(this.tabPageDZI_SIP_Paint);
            // 
            // buttonEditZPP
            // 
            this.buttonEditZPP.Image = global::E_school.Properties.Resources.Pencil_icon;
            this.buttonEditZPP.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.buttonEditZPP.Location = new System.Drawing.Point(884, 228);
            this.buttonEditZPP.Name = "buttonEditZPP";
            this.buttonEditZPP.Size = new System.Drawing.Size(115, 29);
            this.buttonEditZPP.TabIndex = 1128;
            this.buttonEditZPP.Text = "Промяна ЗПП";
            this.buttonEditZPP.UseVisualStyleBackColor = true;
            this.buttonEditZPP.Click += new System.EventHandler(this.buttonEditZPP_Click);
            // 
            // buttonEditDZI
            // 
            this.buttonEditDZI.Image = global::E_school.Properties.Resources.Pencil_icon;
            this.buttonEditDZI.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.buttonEditDZI.Location = new System.Drawing.Point(561, 39);
            this.buttonEditDZI.Name = "buttonEditDZI";
            this.buttonEditDZI.Size = new System.Drawing.Size(115, 29);
            this.buttonEditDZI.TabIndex = 1128;
            this.buttonEditDZI.Text = "Промяна ДЗИ";
            this.buttonEditDZI.UseVisualStyleBackColor = true;
            this.buttonEditDZI.Click += new System.EventHandler(this.buttonEditDZI_Click);
            // 
            // textBoxSrUspZP
            // 
            this.textBoxSrUspZP.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxSrUspZP.Location = new System.Drawing.Point(1009, 552);
            this.textBoxSrUspZP.Name = "textBoxSrUspZP";
            this.textBoxSrUspZP.Size = new System.Drawing.Size(91, 13);
            this.textBoxSrUspZP.TabIndex = 1127;
            this.textBoxSrUspZP.Visible = false;
            // 
            // textBox3ZPP
            // 
            this.textBox3ZPP.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox3ZPP.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox3ZPP.Location = new System.Drawing.Point(31, 362);
            this.textBox3ZPP.Name = "textBox3ZPP";
            this.textBox3ZPP.Size = new System.Drawing.Size(216, 21);
            this.textBox3ZPP.TabIndex = 1125;
            // 
            // textBox2ZPP
            // 
            this.textBox2ZPP.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox2ZPP.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox2ZPP.Location = new System.Drawing.Point(31, 341);
            this.textBox2ZPP.Name = "textBox2ZPP";
            this.textBox2ZPP.Size = new System.Drawing.Size(216, 21);
            this.textBox2ZPP.TabIndex = 1125;
            // 
            // textBox1ZPP
            // 
            this.textBox1ZPP.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox1ZPP.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox1ZPP.Location = new System.Drawing.Point(31, 320);
            this.textBox1ZPP.Name = "textBox1ZPP";
            this.textBox1ZPP.Size = new System.Drawing.Size(216, 21);
            this.textBox1ZPP.TabIndex = 1125;
            // 
            // comboBox3SIP
            // 
            this.comboBox3SIP.FormattingEnabled = true;
            this.comboBox3SIP.Location = new System.Drawing.Point(31, 593);
            this.comboBox3SIP.Name = "comboBox3SIP";
            this.comboBox3SIP.Size = new System.Drawing.Size(215, 21);
            this.comboBox3SIP.Sorted = true;
            this.comboBox3SIP.TabIndex = 1124;
            this.comboBox3SIP.Text = "Трети СИП";
            // 
            // comboBox2SIP
            // 
            this.comboBox2SIP.FormattingEnabled = true;
            this.comboBox2SIP.Location = new System.Drawing.Point(31, 572);
            this.comboBox2SIP.Name = "comboBox2SIP";
            this.comboBox2SIP.Size = new System.Drawing.Size(215, 21);
            this.comboBox2SIP.Sorted = true;
            this.comboBox2SIP.TabIndex = 1124;
            this.comboBox2SIP.Text = "Втори СИП";
            // 
            // comboBox2DZI
            // 
            this.comboBox2DZI.FormattingEnabled = true;
            this.comboBox2DZI.Location = new System.Drawing.Point(31, 111);
            this.comboBox2DZI.Name = "comboBox2DZI";
            this.comboBox2DZI.Size = new System.Drawing.Size(226, 21);
            this.comboBox2DZI.Sorted = true;
            this.comboBox2DZI.TabIndex = 1124;
            this.comboBox2DZI.Text = "Втори ДЗИ";
            this.comboBox2DZI.SelectedIndexChanged += new System.EventHandler(this.comboBox2DZI_SelectedIndexChanged);
            // 
            // comboBox1DZI
            // 
            this.comboBox1DZI.FormattingEnabled = true;
            this.comboBox1DZI.Location = new System.Drawing.Point(31, 90);
            this.comboBox1DZI.Name = "comboBox1DZI";
            this.comboBox1DZI.Size = new System.Drawing.Size(226, 21);
            this.comboBox1DZI.Sorted = true;
            this.comboBox1DZI.TabIndex = 1124;
            this.comboBox1DZI.SelectedIndexChanged += new System.EventHandler(this.comboBox1DZI_SelectedIndexChanged);
            // 
            // comboBox1SIP
            // 
            this.comboBox1SIP.FormattingEnabled = true;
            this.comboBox1SIP.Location = new System.Drawing.Point(31, 551);
            this.comboBox1SIP.Name = "comboBox1SIP";
            this.comboBox1SIP.Size = new System.Drawing.Size(215, 21);
            this.comboBox1SIP.Sorted = true;
            this.comboBox1SIP.TabIndex = 1124;
            this.comboBox1SIP.Text = "Първи СИП";
            this.comboBox1SIP.SelectedIndexChanged += new System.EventHandler(this.comboBox1SIP_SelectedIndexChanged);
            // 
            // buttonSaveDZI
            // 
            this.buttonSaveDZI.Image = ((System.Drawing.Image)(resources.GetObject("buttonSaveDZI.Image")));
            this.buttonSaveDZI.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonSaveDZI.Location = new System.Drawing.Point(456, 38);
            this.buttonSaveDZI.Name = "buttonSaveDZI";
            this.buttonSaveDZI.Size = new System.Drawing.Size(99, 30);
            this.buttonSaveDZI.TabIndex = 4;
            this.buttonSaveDZI.Text = "Запиши ДЗИ";
            this.buttonSaveDZI.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttonSaveDZI.UseVisualStyleBackColor = true;
            this.buttonSaveDZI.Click += new System.EventHandler(this.buttonSaveDZI_Click);
            // 
            // buttonSaveZPP
            // 
            this.buttonSaveZPP.Image = ((System.Drawing.Image)(resources.GetObject("buttonSaveZPP.Image")));
            this.buttonSaveZPP.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonSaveZPP.Location = new System.Drawing.Point(783, 228);
            this.buttonSaveZPP.Name = "buttonSaveZPP";
            this.buttonSaveZPP.Size = new System.Drawing.Size(95, 30);
            this.buttonSaveZPP.TabIndex = 17;
            this.buttonSaveZPP.Text = "Запиши ЗПП";
            this.buttonSaveZPP.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttonSaveZPP.UseVisualStyleBackColor = true;
            this.buttonSaveZPP.Click += new System.EventHandler(this.buttonSaveZPP_Click);
            // 
            // buttonSaveSIP
            // 
            this.buttonSaveSIP.Image = ((System.Drawing.Image)(resources.GetObject("buttonSaveSIP.Image")));
            this.buttonSaveSIP.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonSaveSIP.Location = new System.Drawing.Point(794, 492);
            this.buttonSaveSIP.Name = "buttonSaveSIP";
            this.buttonSaveSIP.Size = new System.Drawing.Size(97, 30);
            this.buttonSaveSIP.TabIndex = 32;
            this.buttonSaveSIP.Text = "Запиши СИП";
            this.buttonSaveSIP.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttonSaveSIP.UseVisualStyleBackColor = true;
            this.buttonSaveSIP.Click += new System.EventHandler(this.buttonSaveSIP_Click);
            // 
            // comboBox4DZI
            // 
            this.comboBox4DZI.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.comboBox4DZI.FormattingEnabled = true;
            this.comboBox4DZI.Items.AddRange(new object[] {
            ""});
            this.comboBox4DZI.Location = new System.Drawing.Point(31, 152);
            this.comboBox4DZI.Margin = new System.Windows.Forms.Padding(0);
            this.comboBox4DZI.Name = "comboBox4DZI";
            this.comboBox4DZI.Size = new System.Drawing.Size(226, 21);
            this.comboBox4DZI.Sorted = true;
            this.comboBox4DZI.TabIndex = 1122;
            this.comboBox4DZI.TabStop = false;
            this.comboBox4DZI.Text = "Четвърти ДЗИ";
            // 
            // comboBox3DZI
            // 
            this.comboBox3DZI.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.comboBox3DZI.FormattingEnabled = true;
            this.comboBox3DZI.Items.AddRange(new object[] {
            ""});
            this.comboBox3DZI.Location = new System.Drawing.Point(31, 132);
            this.comboBox3DZI.Margin = new System.Windows.Forms.Padding(0);
            this.comboBox3DZI.Name = "comboBox3DZI";
            this.comboBox3DZI.Size = new System.Drawing.Size(226, 21);
            this.comboBox3DZI.Sorted = true;
            this.comboBox3DZI.TabIndex = 1122;
            this.comboBox3DZI.TabStop = false;
            this.comboBox3DZI.Text = "Трети ДЗИ";
            // 
            // textBox443
            // 
            this.textBox443.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox443.Location = new System.Drawing.Point(9, 132);
            this.textBox443.Margin = new System.Windows.Forms.Padding(0);
            this.textBox443.Multiline = true;
            this.textBox443.Name = "textBox443";
            this.textBox443.ReadOnly = true;
            this.textBox443.Size = new System.Drawing.Size(22, 21);
            this.textBox443.TabIndex = 595;
            this.textBox443.TabStop = false;
            this.textBox443.Text = "3.";
            this.textBox443.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox454
            // 
            this.textBox454.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox454.Location = new System.Drawing.Point(9, 90);
            this.textBox454.Margin = new System.Windows.Forms.Padding(0);
            this.textBox454.Multiline = true;
            this.textBox454.Name = "textBox454";
            this.textBox454.ReadOnly = true;
            this.textBox454.Size = new System.Drawing.Size(22, 21);
            this.textBox454.TabIndex = 593;
            this.textBox454.TabStop = false;
            this.textBox454.Text = "1.";
            this.textBox454.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox526
            // 
            this.textBox526.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox526.Location = new System.Drawing.Point(9, 111);
            this.textBox526.Margin = new System.Windows.Forms.Padding(0);
            this.textBox526.Multiline = true;
            this.textBox526.Name = "textBox526";
            this.textBox526.ReadOnly = true;
            this.textBox526.Size = new System.Drawing.Size(22, 21);
            this.textBox526.TabIndex = 594;
            this.textBox526.TabStop = false;
            this.textBox526.Text = "2.";
            this.textBox526.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox527
            // 
            this.textBox527.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox527.Location = new System.Drawing.Point(9, 152);
            this.textBox527.Margin = new System.Windows.Forms.Padding(0);
            this.textBox527.Multiline = true;
            this.textBox527.Name = "textBox527";
            this.textBox527.ReadOnly = true;
            this.textBox527.Size = new System.Drawing.Size(22, 21);
            this.textBox527.TabIndex = 596;
            this.textBox527.TabStop = false;
            this.textBox527.Text = "4.";
            this.textBox527.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox3DZI
            // 
            this.textBox3DZI.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox3DZI.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox3DZI.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox3DZI.Location = new System.Drawing.Point(342, 132);
            this.textBox3DZI.Margin = new System.Windows.Forms.Padding(0);
            this.textBox3DZI.Name = "textBox3DZI";
            this.textBox3DZI.Size = new System.Drawing.Size(50, 21);
            this.textBox3DZI.TabIndex = 2;
            this.textBox3DZI.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox3DZI.TextChanged += new System.EventHandler(this.textBox3DZI_TextChanged);
            // 
            // textBox1DZI
            // 
            this.textBox1DZI.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox1DZI.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox1DZI.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox1DZI.Location = new System.Drawing.Point(342, 90);
            this.textBox1DZI.Margin = new System.Windows.Forms.Padding(0);
            this.textBox1DZI.Name = "textBox1DZI";
            this.textBox1DZI.Size = new System.Drawing.Size(50, 21);
            this.textBox1DZI.TabIndex = 0;
            this.textBox1DZI.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox1DZI.TextChanged += new System.EventHandler(this.textBox1DZI_TextChanged);
            // 
            // textBox2DZI
            // 
            this.textBox2DZI.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox2DZI.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox2DZI.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox2DZI.Location = new System.Drawing.Point(342, 111);
            this.textBox2DZI.Margin = new System.Windows.Forms.Padding(0);
            this.textBox2DZI.Name = "textBox2DZI";
            this.textBox2DZI.Size = new System.Drawing.Size(50, 21);
            this.textBox2DZI.TabIndex = 1;
            this.textBox2DZI.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox2DZI.TextChanged += new System.EventHandler(this.textBox2DZI_TextChanged);
            // 
            // textBoxDZISrUsp
            // 
            this.textBoxDZISrUsp.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBoxDZISrUsp.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxDZISrUsp.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxDZISrUsp.Location = new System.Drawing.Point(541, 132);
            this.textBoxDZISrUsp.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxDZISrUsp.Name = "textBoxDZISrUsp";
            this.textBoxDZISrUsp.ReadOnly = true;
            this.textBoxDZISrUsp.Size = new System.Drawing.Size(50, 21);
            this.textBoxDZISrUsp.TabIndex = 235;
            this.textBoxDZISrUsp.TabStop = false;
            this.textBoxDZISrUsp.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBoxDZISrUsp.TextChanged += new System.EventHandler(this.textBoxDZISrUsp_TextChanged);
            // 
            // textBoxZPPZIP
            // 
            this.textBoxZPPZIP.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBoxZPPZIP.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxZPPZIP.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxZPPZIP.Location = new System.Drawing.Point(861, 320);
            this.textBoxZPPZIP.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxZPPZIP.Name = "textBoxZPPZIP";
            this.textBoxZPPZIP.ReadOnly = true;
            this.textBoxZPPZIP.Size = new System.Drawing.Size(50, 21);
            this.textBoxZPPZIP.TabIndex = 235;
            this.textBoxZPPZIP.TabStop = false;
            this.textBoxZPPZIP.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBoxZPPZIP.TextChanged += new System.EventHandler(this.textBoxZPPZIP_TextChanged);
            // 
            // textBox4DZI
            // 
            this.textBox4DZI.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox4DZI.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox4DZI.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox4DZI.Location = new System.Drawing.Point(342, 152);
            this.textBox4DZI.Margin = new System.Windows.Forms.Padding(0);
            this.textBox4DZI.Name = "textBox4DZI";
            this.textBox4DZI.Size = new System.Drawing.Size(50, 21);
            this.textBox4DZI.TabIndex = 3;
            this.textBox4DZI.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox4DZI.TextChanged += new System.EventHandler(this.textBox4DZI_TextChanged);
            // 
            // textBox3DZIw
            // 
            this.textBox3DZIw.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox3DZIw.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox3DZIw.Location = new System.Drawing.Point(258, 132);
            this.textBox3DZIw.Margin = new System.Windows.Forms.Padding(0);
            this.textBox3DZIw.Name = "textBox3DZIw";
            this.textBox3DZIw.ReadOnly = true;
            this.textBox3DZIw.Size = new System.Drawing.Size(84, 21);
            this.textBox3DZIw.TabIndex = 592;
            this.textBox3DZIw.TabStop = false;
            // 
            // textBox1DZIw
            // 
            this.textBox1DZIw.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox1DZIw.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox1DZIw.Location = new System.Drawing.Point(258, 90);
            this.textBox1DZIw.Margin = new System.Windows.Forms.Padding(0);
            this.textBox1DZIw.Name = "textBox1DZIw";
            this.textBox1DZIw.ReadOnly = true;
            this.textBox1DZIw.Size = new System.Drawing.Size(84, 21);
            this.textBox1DZIw.TabIndex = 590;
            this.textBox1DZIw.TabStop = false;
            // 
            // textBoxDZISrUspW
            // 
            this.textBoxDZISrUspW.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxDZISrUspW.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxDZISrUspW.Location = new System.Drawing.Point(445, 132);
            this.textBoxDZISrUspW.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxDZISrUspW.Name = "textBoxDZISrUspW";
            this.textBoxDZISrUspW.ReadOnly = true;
            this.textBoxDZISrUspW.Size = new System.Drawing.Size(96, 21);
            this.textBoxDZISrUspW.TabIndex = 589;
            this.textBoxDZISrUspW.TabStop = false;
            // 
            // textBoxZPPZIPW
            // 
            this.textBoxZPPZIPW.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxZPPZIPW.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxZPPZIPW.Location = new System.Drawing.Point(777, 320);
            this.textBoxZPPZIPW.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxZPPZIPW.Name = "textBoxZPPZIPW";
            this.textBoxZPPZIPW.ReadOnly = true;
            this.textBoxZPPZIPW.Size = new System.Drawing.Size(84, 21);
            this.textBoxZPPZIPW.TabIndex = 589;
            this.textBoxZPPZIPW.TabStop = false;
            // 
            // textBox2DZIw
            // 
            this.textBox2DZIw.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox2DZIw.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox2DZIw.Location = new System.Drawing.Point(258, 111);
            this.textBox2DZIw.Margin = new System.Windows.Forms.Padding(0);
            this.textBox2DZIw.Name = "textBox2DZIw";
            this.textBox2DZIw.ReadOnly = true;
            this.textBox2DZIw.Size = new System.Drawing.Size(84, 21);
            this.textBox2DZIw.TabIndex = 591;
            this.textBox2DZIw.TabStop = false;
            // 
            // textBox4DZIw
            // 
            this.textBox4DZIw.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox4DZIw.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox4DZIw.Location = new System.Drawing.Point(258, 152);
            this.textBox4DZIw.Margin = new System.Windows.Forms.Padding(0);
            this.textBox4DZIw.Name = "textBox4DZIw";
            this.textBox4DZIw.ReadOnly = true;
            this.textBox4DZIw.Size = new System.Drawing.Size(84, 21);
            this.textBox4DZIw.TabIndex = 589;
            this.textBox4DZIw.TabStop = false;
            // 
            // textBox542
            // 
            this.textBox542.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox542.Location = new System.Drawing.Point(31, 38);
            this.textBox542.Margin = new System.Windows.Forms.Padding(0);
            this.textBox542.Multiline = true;
            this.textBox542.Name = "textBox542";
            this.textBox542.Size = new System.Drawing.Size(227, 52);
            this.textBox542.TabIndex = 586;
            this.textBox542.TabStop = false;
            this.textBox542.Text = "\r\n\r\nУ Ч Е Б Н И   П Р Е Д М Е Т И";
            this.textBox542.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox547
            // 
            this.textBox547.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox547.Location = new System.Drawing.Point(9, 12);
            this.textBox547.Margin = new System.Windows.Forms.Padding(0);
            this.textBox547.Multiline = true;
            this.textBox547.Name = "textBox547";
            this.textBox547.Size = new System.Drawing.Size(383, 26);
            this.textBox547.TabIndex = 588;
            this.textBox547.TabStop = false;
            this.textBox547.Text = "Успех от държавни зрелостни изпити";
            this.textBox547.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox73
            // 
            this.textBox73.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox73.Location = new System.Drawing.Point(445, 106);
            this.textBox73.Margin = new System.Windows.Forms.Padding(0);
            this.textBox73.Multiline = true;
            this.textBox73.Name = "textBox73";
            this.textBox73.Size = new System.Drawing.Size(146, 26);
            this.textBox73.TabIndex = 588;
            this.textBox73.TabStop = false;
            this.textBox73.Text = "Среден успех от ДЗИ";
            this.textBox73.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox70
            // 
            this.textBox70.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox70.Location = new System.Drawing.Point(777, 283);
            this.textBox70.Margin = new System.Windows.Forms.Padding(0);
            this.textBox70.Multiline = true;
            this.textBox70.Name = "textBox70";
            this.textBox70.Size = new System.Drawing.Size(134, 37);
            this.textBox70.TabIndex = 588;
            this.textBox70.TabStop = false;
            this.textBox70.Text = "Среден успех от\r\nЗИП и ЗПП";
            this.textBox70.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox543
            // 
            this.textBox543.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox543.Location = new System.Drawing.Point(258, 38);
            this.textBox543.Margin = new System.Windows.Forms.Padding(0);
            this.textBox543.Multiline = true;
            this.textBox543.Name = "textBox543";
            this.textBox543.Size = new System.Drawing.Size(134, 26);
            this.textBox543.TabIndex = 588;
            this.textBox543.TabStop = false;
            this.textBox543.Text = " сесия";
            this.textBox543.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxYear
            // 
            this.textBoxYear.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxYear.Location = new System.Drawing.Point(258, 64);
            this.textBoxYear.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxYear.Multiline = true;
            this.textBoxYear.Name = "textBoxYear";
            this.textBoxYear.Size = new System.Drawing.Size(134, 26);
            this.textBoxYear.TabIndex = 587;
            this.textBoxYear.TabStop = false;
            this.textBoxYear.Text = "ххх г. ";
            this.textBoxYear.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox545
            // 
            this.textBox545.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox545.Location = new System.Drawing.Point(9, 38);
            this.textBox545.Margin = new System.Windows.Forms.Padding(0);
            this.textBox545.Multiline = true;
            this.textBox545.Name = "textBox545";
            this.textBox545.Size = new System.Drawing.Size(22, 52);
            this.textBox545.TabIndex = 585;
            this.textBox545.TabStop = false;
            this.textBox545.Text = "\r\n\r\n№";
            this.textBox545.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox157
            // 
            this.textBox157.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox157.Location = new System.Drawing.Point(9, 362);
            this.textBox157.Margin = new System.Windows.Forms.Padding(0);
            this.textBox157.Multiline = true;
            this.textBox157.Name = "textBox157";
            this.textBox157.ReadOnly = true;
            this.textBox157.Size = new System.Drawing.Size(22, 21);
            this.textBox157.TabIndex = 512;
            this.textBox157.TabStop = false;
            this.textBox157.Text = "3.";
            this.textBox157.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox420
            // 
            this.textBox420.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox420.Location = new System.Drawing.Point(9, 593);
            this.textBox420.Margin = new System.Windows.Forms.Padding(0);
            this.textBox420.Multiline = true;
            this.textBox420.Name = "textBox420";
            this.textBox420.ReadOnly = true;
            this.textBox420.Size = new System.Drawing.Size(22, 21);
            this.textBox420.TabIndex = 512;
            this.textBox420.TabStop = false;
            this.textBox420.Text = "3.";
            this.textBox420.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox121
            // 
            this.textBox121.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox121.Location = new System.Drawing.Point(9, 320);
            this.textBox121.Margin = new System.Windows.Forms.Padding(0);
            this.textBox121.Multiline = true;
            this.textBox121.Name = "textBox121";
            this.textBox121.ReadOnly = true;
            this.textBox121.Size = new System.Drawing.Size(22, 21);
            this.textBox121.TabIndex = 510;
            this.textBox121.TabStop = false;
            this.textBox121.Text = "1.";
            this.textBox121.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox421
            // 
            this.textBox421.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox421.Location = new System.Drawing.Point(9, 551);
            this.textBox421.Margin = new System.Windows.Forms.Padding(0);
            this.textBox421.Multiline = true;
            this.textBox421.Name = "textBox421";
            this.textBox421.ReadOnly = true;
            this.textBox421.Size = new System.Drawing.Size(22, 21);
            this.textBox421.TabIndex = 510;
            this.textBox421.TabStop = false;
            this.textBox421.Text = "1.";
            this.textBox421.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox118
            // 
            this.textBox118.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox118.Location = new System.Drawing.Point(9, 341);
            this.textBox118.Margin = new System.Windows.Forms.Padding(0);
            this.textBox118.Multiline = true;
            this.textBox118.Name = "textBox118";
            this.textBox118.ReadOnly = true;
            this.textBox118.Size = new System.Drawing.Size(22, 21);
            this.textBox118.TabIndex = 511;
            this.textBox118.TabStop = false;
            this.textBox118.Text = "2.";
            this.textBox118.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox422
            // 
            this.textBox422.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox422.Location = new System.Drawing.Point(9, 572);
            this.textBox422.Margin = new System.Windows.Forms.Padding(0);
            this.textBox422.Multiline = true;
            this.textBox422.Name = "textBox422";
            this.textBox422.ReadOnly = true;
            this.textBox422.Size = new System.Drawing.Size(22, 21);
            this.textBox422.TabIndex = 511;
            this.textBox422.TabStop = false;
            this.textBox422.Text = "2.";
            this.textBox422.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxOkZPP3
            // 
            this.textBoxOkZPP3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBoxOkZPP3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxOkZPP3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxOkZPP3.Location = new System.Drawing.Point(721, 362);
            this.textBoxOkZPP3.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxOkZPP3.Name = "textBoxOkZPP3";
            this.textBoxOkZPP3.ReadOnly = true;
            this.textBoxOkZPP3.Size = new System.Drawing.Size(48, 21);
            this.textBoxOkZPP3.TabIndex = 185;
            this.textBoxOkZPP3.TabStop = false;
            this.textBoxOkZPP3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBoxOkZPP3.TextChanged += new System.EventHandler(this.textBoxOkZPP3_TextChanged);
            // 
            // textBoxOkon3
            // 
            this.textBoxOkon3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBoxOkon3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxOkon3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxOkon3.Location = new System.Drawing.Point(721, 593);
            this.textBoxOkon3.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxOkon3.Name = "textBoxOkon3";
            this.textBoxOkon3.ReadOnly = true;
            this.textBoxOkon3.Size = new System.Drawing.Size(48, 21);
            this.textBoxOkon3.TabIndex = 180;
            this.textBoxOkon3.TabStop = false;
            this.textBoxOkon3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBoxOkon3.TextChanged += new System.EventHandler(this.textBoxOkon3_TextChanged);
            // 
            // textBox12ZPP3
            // 
            this.textBox12ZPP3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox12ZPP3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox12ZPP3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox12ZPP3.Location = new System.Drawing.Point(622, 362);
            this.textBox12ZPP3.Margin = new System.Windows.Forms.Padding(0);
            this.textBox12ZPP3.Name = "textBox12ZPP3";
            this.textBox12ZPP3.Size = new System.Drawing.Size(21, 21);
            this.textBox12ZPP3.TabIndex = 16;
            this.textBox12ZPP3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox12ZPP3.TextChanged += new System.EventHandler(this.textBox12ZPP3_TextChanged);
            // 
            // textBox12SIP3
            // 
            this.textBox12SIP3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox12SIP3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox12SIP3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox12SIP3.Location = new System.Drawing.Point(622, 593);
            this.textBox12SIP3.Margin = new System.Windows.Forms.Padding(0);
            this.textBox12SIP3.Name = "textBox12SIP3";
            this.textBox12SIP3.Size = new System.Drawing.Size(21, 21);
            this.textBox12SIP3.TabIndex = 31;
            this.textBox12SIP3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox12SIP3.TextChanged += new System.EventHandler(this.textBox12SIP3_TextChanged);
            // 
            // textBox11ZPP3
            // 
            this.textBox11ZPP3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox11ZPP3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox11ZPP3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox11ZPP3.Location = new System.Drawing.Point(523, 362);
            this.textBox11ZPP3.Margin = new System.Windows.Forms.Padding(0);
            this.textBox11ZPP3.Name = "textBox11ZPP3";
            this.textBox11ZPP3.Size = new System.Drawing.Size(21, 21);
            this.textBox11ZPP3.TabIndex = 15;
            this.textBox11ZPP3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox11ZPP3.TextChanged += new System.EventHandler(this.textBox11ZPP3_TextChanged);
            // 
            // textBox11SIP3
            // 
            this.textBox11SIP3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox11SIP3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox11SIP3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox11SIP3.Location = new System.Drawing.Point(523, 593);
            this.textBox11SIP3.Margin = new System.Windows.Forms.Padding(0);
            this.textBox11SIP3.Name = "textBox11SIP3";
            this.textBox11SIP3.Size = new System.Drawing.Size(21, 21);
            this.textBox11SIP3.TabIndex = 30;
            this.textBox11SIP3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox11SIP3.TextChanged += new System.EventHandler(this.textBox11SIP3_TextChanged);
            // 
            // textBox10ZPP3
            // 
            this.textBox10ZPP3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox10ZPP3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox10ZPP3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox10ZPP3.Location = new System.Drawing.Point(424, 362);
            this.textBox10ZPP3.Margin = new System.Windows.Forms.Padding(0);
            this.textBox10ZPP3.Name = "textBox10ZPP3";
            this.textBox10ZPP3.Size = new System.Drawing.Size(21, 21);
            this.textBox10ZPP3.TabIndex = 14;
            this.textBox10ZPP3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox10ZPP3.TextChanged += new System.EventHandler(this.textBox10ZPP3_TextChanged);
            // 
            // textBox10SIP3
            // 
            this.textBox10SIP3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox10SIP3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox10SIP3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox10SIP3.Location = new System.Drawing.Point(424, 593);
            this.textBox10SIP3.Margin = new System.Windows.Forms.Padding(0);
            this.textBox10SIP3.Name = "textBox10SIP3";
            this.textBox10SIP3.Size = new System.Drawing.Size(21, 21);
            this.textBox10SIP3.TabIndex = 29;
            this.textBox10SIP3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox10SIP3.TextChanged += new System.EventHandler(this.textBox10SIP3_TextChanged);
            // 
            // textBox9ZPP3
            // 
            this.textBox9ZPP3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox9ZPP3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox9ZPP3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox9ZPP3.Location = new System.Drawing.Point(325, 362);
            this.textBox9ZPP3.Margin = new System.Windows.Forms.Padding(0);
            this.textBox9ZPP3.Name = "textBox9ZPP3";
            this.textBox9ZPP3.Size = new System.Drawing.Size(21, 21);
            this.textBox9ZPP3.TabIndex = 13;
            this.textBox9ZPP3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox9ZPP3.TextChanged += new System.EventHandler(this.textBox9ZPP3_TextChanged);
            // 
            // textBox9SIP3
            // 
            this.textBox9SIP3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox9SIP3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox9SIP3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox9SIP3.Location = new System.Drawing.Point(325, 593);
            this.textBox9SIP3.Margin = new System.Windows.Forms.Padding(0);
            this.textBox9SIP3.Name = "textBox9SIP3";
            this.textBox9SIP3.Size = new System.Drawing.Size(21, 21);
            this.textBox9SIP3.TabIndex = 28;
            this.textBox9SIP3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox9SIP3.TextChanged += new System.EventHandler(this.textBox9SIP3_TextChanged);
            // 
            // textBoxOkZPP1
            // 
            this.textBoxOkZPP1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBoxOkZPP1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxOkZPP1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxOkZPP1.Location = new System.Drawing.Point(721, 320);
            this.textBoxOkZPP1.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxOkZPP1.Name = "textBoxOkZPP1";
            this.textBoxOkZPP1.ReadOnly = true;
            this.textBoxOkZPP1.Size = new System.Drawing.Size(48, 21);
            this.textBoxOkZPP1.TabIndex = 165;
            this.textBoxOkZPP1.TabStop = false;
            this.textBoxOkZPP1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBoxOkZPP1.TextChanged += new System.EventHandler(this.textBoxOkZPP1_TextChanged);
            // 
            // textBoxOkon1
            // 
            this.textBoxOkon1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBoxOkon1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxOkon1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxOkon1.Location = new System.Drawing.Point(721, 551);
            this.textBoxOkon1.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxOkon1.Name = "textBoxOkon1";
            this.textBoxOkon1.ReadOnly = true;
            this.textBoxOkon1.Size = new System.Drawing.Size(48, 21);
            this.textBoxOkon1.TabIndex = 160;
            this.textBoxOkon1.TabStop = false;
            this.textBoxOkon1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBoxOkon1.TextChanged += new System.EventHandler(this.textBoxOkon1_TextChanged);
            // 
            // textBox12ZPP1
            // 
            this.textBox12ZPP1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox12ZPP1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox12ZPP1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox12ZPP1.Location = new System.Drawing.Point(622, 320);
            this.textBox12ZPP1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox12ZPP1.Name = "textBox12ZPP1";
            this.textBox12ZPP1.Size = new System.Drawing.Size(21, 21);
            this.textBox12ZPP1.TabIndex = 8;
            this.textBox12ZPP1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox12ZPP1.TextChanged += new System.EventHandler(this.textBox12ZPP1_TextChanged);
            // 
            // textBox12SIP1
            // 
            this.textBox12SIP1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox12SIP1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox12SIP1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox12SIP1.Location = new System.Drawing.Point(622, 551);
            this.textBox12SIP1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox12SIP1.Name = "textBox12SIP1";
            this.textBox12SIP1.Size = new System.Drawing.Size(21, 21);
            this.textBox12SIP1.TabIndex = 23;
            this.textBox12SIP1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox12SIP1.TextChanged += new System.EventHandler(this.textBox12SIP1_TextChanged);
            // 
            // textBox11ZPP1
            // 
            this.textBox11ZPP1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox11ZPP1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox11ZPP1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox11ZPP1.Location = new System.Drawing.Point(523, 320);
            this.textBox11ZPP1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox11ZPP1.Name = "textBox11ZPP1";
            this.textBox11ZPP1.Size = new System.Drawing.Size(21, 21);
            this.textBox11ZPP1.TabIndex = 7;
            this.textBox11ZPP1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox11ZPP1.TextChanged += new System.EventHandler(this.textBox11ZPP1_TextChanged);
            // 
            // textBox11SIP1
            // 
            this.textBox11SIP1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox11SIP1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox11SIP1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox11SIP1.Location = new System.Drawing.Point(523, 551);
            this.textBox11SIP1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox11SIP1.Name = "textBox11SIP1";
            this.textBox11SIP1.Size = new System.Drawing.Size(21, 21);
            this.textBox11SIP1.TabIndex = 22;
            this.textBox11SIP1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox11SIP1.TextChanged += new System.EventHandler(this.textBox11SIP1_TextChanged);
            // 
            // textBox10ZPP1
            // 
            this.textBox10ZPP1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox10ZPP1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox10ZPP1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox10ZPP1.Location = new System.Drawing.Point(424, 320);
            this.textBox10ZPP1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox10ZPP1.Name = "textBox10ZPP1";
            this.textBox10ZPP1.Size = new System.Drawing.Size(21, 21);
            this.textBox10ZPP1.TabIndex = 6;
            this.textBox10ZPP1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox10ZPP1.TextChanged += new System.EventHandler(this.textBox10ZPP1_TextChanged);
            // 
            // textBox10SIP1
            // 
            this.textBox10SIP1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox10SIP1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox10SIP1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox10SIP1.Location = new System.Drawing.Point(424, 551);
            this.textBox10SIP1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox10SIP1.Name = "textBox10SIP1";
            this.textBox10SIP1.Size = new System.Drawing.Size(21, 21);
            this.textBox10SIP1.TabIndex = 21;
            this.textBox10SIP1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox10SIP1.TextChanged += new System.EventHandler(this.textBox10SIP1_TextChanged);
            // 
            // textBox9ZPP1
            // 
            this.textBox9ZPP1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox9ZPP1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox9ZPP1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox9ZPP1.Location = new System.Drawing.Point(325, 320);
            this.textBox9ZPP1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox9ZPP1.Name = "textBox9ZPP1";
            this.textBox9ZPP1.Size = new System.Drawing.Size(21, 21);
            this.textBox9ZPP1.TabIndex = 5;
            this.textBox9ZPP1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox9ZPP1.TextChanged += new System.EventHandler(this.textBox9ZPP1_TextChanged);
            // 
            // textBox9SIP1
            // 
            this.textBox9SIP1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox9SIP1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox9SIP1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox9SIP1.Location = new System.Drawing.Point(325, 551);
            this.textBox9SIP1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox9SIP1.Name = "textBox9SIP1";
            this.textBox9SIP1.Size = new System.Drawing.Size(21, 21);
            this.textBox9SIP1.TabIndex = 20;
            this.textBox9SIP1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox9SIP1.TextChanged += new System.EventHandler(this.textBox9SIP1_TextChanged);
            // 
            // textBoxOkZPP2
            // 
            this.textBoxOkZPP2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBoxOkZPP2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxOkZPP2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxOkZPP2.Location = new System.Drawing.Point(721, 341);
            this.textBoxOkZPP2.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxOkZPP2.Name = "textBoxOkZPP2";
            this.textBoxOkZPP2.ReadOnly = true;
            this.textBoxOkZPP2.Size = new System.Drawing.Size(48, 21);
            this.textBoxOkZPP2.TabIndex = 176;
            this.textBoxOkZPP2.TabStop = false;
            this.textBoxOkZPP2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBoxOkZPP2.TextChanged += new System.EventHandler(this.textBoxOkZPP2_TextChanged);
            // 
            // textBoxOkon2
            // 
            this.textBoxOkon2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBoxOkon2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxOkon2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxOkon2.Location = new System.Drawing.Point(721, 572);
            this.textBoxOkon2.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxOkon2.Name = "textBoxOkon2";
            this.textBoxOkon2.ReadOnly = true;
            this.textBoxOkon2.Size = new System.Drawing.Size(48, 21);
            this.textBoxOkon2.TabIndex = 170;
            this.textBoxOkon2.TabStop = false;
            this.textBoxOkon2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBoxOkon2.TextChanged += new System.EventHandler(this.textBoxOkon2_TextChanged);
            // 
            // textBox12ZPP2
            // 
            this.textBox12ZPP2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox12ZPP2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox12ZPP2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox12ZPP2.Location = new System.Drawing.Point(622, 341);
            this.textBox12ZPP2.Margin = new System.Windows.Forms.Padding(0);
            this.textBox12ZPP2.Name = "textBox12ZPP2";
            this.textBox12ZPP2.Size = new System.Drawing.Size(21, 21);
            this.textBox12ZPP2.TabIndex = 12;
            this.textBox12ZPP2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox12ZPP2.TextChanged += new System.EventHandler(this.textBox12ZPP2_TextChanged);
            // 
            // textBox12SIP2
            // 
            this.textBox12SIP2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox12SIP2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox12SIP2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox12SIP2.Location = new System.Drawing.Point(622, 572);
            this.textBox12SIP2.Margin = new System.Windows.Forms.Padding(0);
            this.textBox12SIP2.Name = "textBox12SIP2";
            this.textBox12SIP2.Size = new System.Drawing.Size(21, 21);
            this.textBox12SIP2.TabIndex = 27;
            this.textBox12SIP2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox12SIP2.TextChanged += new System.EventHandler(this.textBox12SIP2_TextChanged);
            // 
            // textBox11ZPP2
            // 
            this.textBox11ZPP2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox11ZPP2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox11ZPP2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox11ZPP2.Location = new System.Drawing.Point(523, 341);
            this.textBox11ZPP2.Margin = new System.Windows.Forms.Padding(0);
            this.textBox11ZPP2.Name = "textBox11ZPP2";
            this.textBox11ZPP2.Size = new System.Drawing.Size(21, 21);
            this.textBox11ZPP2.TabIndex = 11;
            this.textBox11ZPP2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox11ZPP2.TextChanged += new System.EventHandler(this.textBox11ZPP2_TextChanged);
            // 
            // textBox11SIP2
            // 
            this.textBox11SIP2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox11SIP2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox11SIP2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox11SIP2.Location = new System.Drawing.Point(523, 572);
            this.textBox11SIP2.Margin = new System.Windows.Forms.Padding(0);
            this.textBox11SIP2.Name = "textBox11SIP2";
            this.textBox11SIP2.Size = new System.Drawing.Size(21, 21);
            this.textBox11SIP2.TabIndex = 26;
            this.textBox11SIP2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox11SIP2.TextChanged += new System.EventHandler(this.textBox11SIP2_TextChanged);
            // 
            // textBox10ZPP2
            // 
            this.textBox10ZPP2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox10ZPP2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox10ZPP2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox10ZPP2.Location = new System.Drawing.Point(424, 341);
            this.textBox10ZPP2.Margin = new System.Windows.Forms.Padding(0);
            this.textBox10ZPP2.Name = "textBox10ZPP2";
            this.textBox10ZPP2.Size = new System.Drawing.Size(21, 21);
            this.textBox10ZPP2.TabIndex = 10;
            this.textBox10ZPP2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox10ZPP2.TextChanged += new System.EventHandler(this.textBox10ZPP2_TextChanged);
            // 
            // textBox10SIP2
            // 
            this.textBox10SIP2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox10SIP2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox10SIP2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox10SIP2.Location = new System.Drawing.Point(424, 572);
            this.textBox10SIP2.Margin = new System.Windows.Forms.Padding(0);
            this.textBox10SIP2.Name = "textBox10SIP2";
            this.textBox10SIP2.Size = new System.Drawing.Size(21, 21);
            this.textBox10SIP2.TabIndex = 25;
            this.textBox10SIP2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox10SIP2.TextChanged += new System.EventHandler(this.textBox10SIP2_TextChanged);
            // 
            // textBox9ZPP2
            // 
            this.textBox9ZPP2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox9ZPP2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox9ZPP2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox9ZPP2.Location = new System.Drawing.Point(325, 341);
            this.textBox9ZPP2.Margin = new System.Windows.Forms.Padding(0);
            this.textBox9ZPP2.Name = "textBox9ZPP2";
            this.textBox9ZPP2.Size = new System.Drawing.Size(21, 21);
            this.textBox9ZPP2.TabIndex = 9;
            this.textBox9ZPP2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox9ZPP2.TextChanged += new System.EventHandler(this.textBox9ZPP2_TextChanged);
            // 
            // textBox9SIP2
            // 
            this.textBox9SIP2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox9SIP2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox9SIP2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox9SIP2.Location = new System.Drawing.Point(325, 572);
            this.textBox9SIP2.Margin = new System.Windows.Forms.Padding(0);
            this.textBox9SIP2.Name = "textBox9SIP2";
            this.textBox9SIP2.Size = new System.Drawing.Size(21, 21);
            this.textBox9SIP2.TabIndex = 24;
            this.textBox9SIP2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox9SIP2.TextChanged += new System.EventHandler(this.textBox9SIP2_TextChanged);
            // 
            // textBoxOkZPPw3
            // 
            this.textBoxOkZPPw3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxOkZPPw3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxOkZPPw3.Location = new System.Drawing.Point(643, 362);
            this.textBoxOkZPPw3.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxOkZPPw3.Name = "textBoxOkZPPw3";
            this.textBoxOkZPPw3.ReadOnly = true;
            this.textBoxOkZPPw3.Size = new System.Drawing.Size(78, 21);
            this.textBoxOkZPPw3.TabIndex = 509;
            this.textBoxOkZPPw3.TabStop = false;
            // 
            // textBoxOkW3
            // 
            this.textBoxOkW3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxOkW3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxOkW3.Location = new System.Drawing.Point(643, 593);
            this.textBoxOkW3.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxOkW3.Name = "textBoxOkW3";
            this.textBoxOkW3.ReadOnly = true;
            this.textBoxOkW3.Size = new System.Drawing.Size(78, 21);
            this.textBoxOkW3.TabIndex = 509;
            this.textBoxOkW3.TabStop = false;
            // 
            // textBox12ZPPw3
            // 
            this.textBox12ZPPw3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox12ZPPw3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox12ZPPw3.Location = new System.Drawing.Point(544, 362);
            this.textBox12ZPPw3.Margin = new System.Windows.Forms.Padding(0);
            this.textBox12ZPPw3.Name = "textBox12ZPPw3";
            this.textBox12ZPPw3.ReadOnly = true;
            this.textBox12ZPPw3.Size = new System.Drawing.Size(78, 21);
            this.textBox12ZPPw3.TabIndex = 509;
            this.textBox12ZPPw3.TabStop = false;
            // 
            // textBox12SIPw3
            // 
            this.textBox12SIPw3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox12SIPw3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox12SIPw3.Location = new System.Drawing.Point(544, 593);
            this.textBox12SIPw3.Margin = new System.Windows.Forms.Padding(0);
            this.textBox12SIPw3.Name = "textBox12SIPw3";
            this.textBox12SIPw3.ReadOnly = true;
            this.textBox12SIPw3.Size = new System.Drawing.Size(78, 21);
            this.textBox12SIPw3.TabIndex = 509;
            this.textBox12SIPw3.TabStop = false;
            // 
            // textBox11ZPPw3
            // 
            this.textBox11ZPPw3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox11ZPPw3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox11ZPPw3.Location = new System.Drawing.Point(445, 362);
            this.textBox11ZPPw3.Margin = new System.Windows.Forms.Padding(0);
            this.textBox11ZPPw3.Name = "textBox11ZPPw3";
            this.textBox11ZPPw3.ReadOnly = true;
            this.textBox11ZPPw3.Size = new System.Drawing.Size(78, 21);
            this.textBox11ZPPw3.TabIndex = 509;
            this.textBox11ZPPw3.TabStop = false;
            // 
            // textBox11SIPw3
            // 
            this.textBox11SIPw3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox11SIPw3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox11SIPw3.Location = new System.Drawing.Point(445, 593);
            this.textBox11SIPw3.Margin = new System.Windows.Forms.Padding(0);
            this.textBox11SIPw3.Name = "textBox11SIPw3";
            this.textBox11SIPw3.ReadOnly = true;
            this.textBox11SIPw3.Size = new System.Drawing.Size(78, 21);
            this.textBox11SIPw3.TabIndex = 509;
            this.textBox11SIPw3.TabStop = false;
            // 
            // textBox10ZPPw3
            // 
            this.textBox10ZPPw3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox10ZPPw3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox10ZPPw3.Location = new System.Drawing.Point(346, 362);
            this.textBox10ZPPw3.Margin = new System.Windows.Forms.Padding(0);
            this.textBox10ZPPw3.Name = "textBox10ZPPw3";
            this.textBox10ZPPw3.ReadOnly = true;
            this.textBox10ZPPw3.Size = new System.Drawing.Size(78, 21);
            this.textBox10ZPPw3.TabIndex = 509;
            this.textBox10ZPPw3.TabStop = false;
            // 
            // textBox10SIPw3
            // 
            this.textBox10SIPw3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox10SIPw3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox10SIPw3.Location = new System.Drawing.Point(346, 593);
            this.textBox10SIPw3.Margin = new System.Windows.Forms.Padding(0);
            this.textBox10SIPw3.Name = "textBox10SIPw3";
            this.textBox10SIPw3.ReadOnly = true;
            this.textBox10SIPw3.Size = new System.Drawing.Size(78, 21);
            this.textBox10SIPw3.TabIndex = 509;
            this.textBox10SIPw3.TabStop = false;
            // 
            // textBox9ZPPw3
            // 
            this.textBox9ZPPw3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox9ZPPw3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox9ZPPw3.Location = new System.Drawing.Point(247, 362);
            this.textBox9ZPPw3.Margin = new System.Windows.Forms.Padding(0);
            this.textBox9ZPPw3.Name = "textBox9ZPPw3";
            this.textBox9ZPPw3.ReadOnly = true;
            this.textBox9ZPPw3.Size = new System.Drawing.Size(78, 21);
            this.textBox9ZPPw3.TabIndex = 509;
            this.textBox9ZPPw3.TabStop = false;
            // 
            // textBox9SIPw3
            // 
            this.textBox9SIPw3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox9SIPw3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox9SIPw3.Location = new System.Drawing.Point(247, 593);
            this.textBox9SIPw3.Margin = new System.Windows.Forms.Padding(0);
            this.textBox9SIPw3.Name = "textBox9SIPw3";
            this.textBox9SIPw3.ReadOnly = true;
            this.textBox9SIPw3.Size = new System.Drawing.Size(78, 21);
            this.textBox9SIPw3.TabIndex = 509;
            this.textBox9SIPw3.TabStop = false;
            // 
            // textBoxOkZPPw1
            // 
            this.textBoxOkZPPw1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxOkZPPw1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxOkZPPw1.Location = new System.Drawing.Point(643, 320);
            this.textBoxOkZPPw1.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxOkZPPw1.Name = "textBoxOkZPPw1";
            this.textBoxOkZPPw1.ReadOnly = true;
            this.textBoxOkZPPw1.Size = new System.Drawing.Size(78, 21);
            this.textBoxOkZPPw1.TabIndex = 507;
            this.textBoxOkZPPw1.TabStop = false;
            // 
            // textBoxOkW1
            // 
            this.textBoxOkW1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxOkW1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxOkW1.Location = new System.Drawing.Point(643, 551);
            this.textBoxOkW1.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxOkW1.Name = "textBoxOkW1";
            this.textBoxOkW1.ReadOnly = true;
            this.textBoxOkW1.Size = new System.Drawing.Size(78, 21);
            this.textBoxOkW1.TabIndex = 507;
            this.textBoxOkW1.TabStop = false;
            // 
            // textBox12ZPPw1
            // 
            this.textBox12ZPPw1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox12ZPPw1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox12ZPPw1.Location = new System.Drawing.Point(544, 320);
            this.textBox12ZPPw1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox12ZPPw1.Name = "textBox12ZPPw1";
            this.textBox12ZPPw1.ReadOnly = true;
            this.textBox12ZPPw1.Size = new System.Drawing.Size(78, 21);
            this.textBox12ZPPw1.TabIndex = 507;
            this.textBox12ZPPw1.TabStop = false;
            // 
            // textBox12SIPw1
            // 
            this.textBox12SIPw1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox12SIPw1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox12SIPw1.Location = new System.Drawing.Point(544, 551);
            this.textBox12SIPw1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox12SIPw1.Name = "textBox12SIPw1";
            this.textBox12SIPw1.ReadOnly = true;
            this.textBox12SIPw1.Size = new System.Drawing.Size(78, 21);
            this.textBox12SIPw1.TabIndex = 507;
            this.textBox12SIPw1.TabStop = false;
            // 
            // textBox11ZPPw1
            // 
            this.textBox11ZPPw1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox11ZPPw1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox11ZPPw1.Location = new System.Drawing.Point(445, 320);
            this.textBox11ZPPw1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox11ZPPw1.Name = "textBox11ZPPw1";
            this.textBox11ZPPw1.ReadOnly = true;
            this.textBox11ZPPw1.Size = new System.Drawing.Size(78, 21);
            this.textBox11ZPPw1.TabIndex = 507;
            this.textBox11ZPPw1.TabStop = false;
            // 
            // textBox11SIPw1
            // 
            this.textBox11SIPw1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox11SIPw1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox11SIPw1.Location = new System.Drawing.Point(445, 551);
            this.textBox11SIPw1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox11SIPw1.Name = "textBox11SIPw1";
            this.textBox11SIPw1.ReadOnly = true;
            this.textBox11SIPw1.Size = new System.Drawing.Size(78, 21);
            this.textBox11SIPw1.TabIndex = 507;
            this.textBox11SIPw1.TabStop = false;
            // 
            // textBox10ZPPw1
            // 
            this.textBox10ZPPw1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox10ZPPw1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox10ZPPw1.Location = new System.Drawing.Point(346, 320);
            this.textBox10ZPPw1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox10ZPPw1.Name = "textBox10ZPPw1";
            this.textBox10ZPPw1.ReadOnly = true;
            this.textBox10ZPPw1.Size = new System.Drawing.Size(78, 21);
            this.textBox10ZPPw1.TabIndex = 507;
            this.textBox10ZPPw1.TabStop = false;
            // 
            // textBox10SIPw1
            // 
            this.textBox10SIPw1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox10SIPw1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox10SIPw1.Location = new System.Drawing.Point(346, 551);
            this.textBox10SIPw1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox10SIPw1.Name = "textBox10SIPw1";
            this.textBox10SIPw1.ReadOnly = true;
            this.textBox10SIPw1.Size = new System.Drawing.Size(78, 21);
            this.textBox10SIPw1.TabIndex = 507;
            this.textBox10SIPw1.TabStop = false;
            // 
            // textBox9ZPPw1
            // 
            this.textBox9ZPPw1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox9ZPPw1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox9ZPPw1.Location = new System.Drawing.Point(247, 320);
            this.textBox9ZPPw1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox9ZPPw1.Name = "textBox9ZPPw1";
            this.textBox9ZPPw1.ReadOnly = true;
            this.textBox9ZPPw1.Size = new System.Drawing.Size(78, 21);
            this.textBox9ZPPw1.TabIndex = 507;
            this.textBox9ZPPw1.TabStop = false;
            // 
            // textBox9SIPw1
            // 
            this.textBox9SIPw1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox9SIPw1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox9SIPw1.Location = new System.Drawing.Point(247, 551);
            this.textBox9SIPw1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox9SIPw1.Name = "textBox9SIPw1";
            this.textBox9SIPw1.ReadOnly = true;
            this.textBox9SIPw1.Size = new System.Drawing.Size(78, 21);
            this.textBox9SIPw1.TabIndex = 507;
            this.textBox9SIPw1.TabStop = false;
            // 
            // textBoxOkZPPw2
            // 
            this.textBoxOkZPPw2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxOkZPPw2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxOkZPPw2.Location = new System.Drawing.Point(643, 341);
            this.textBoxOkZPPw2.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxOkZPPw2.Name = "textBoxOkZPPw2";
            this.textBoxOkZPPw2.ReadOnly = true;
            this.textBoxOkZPPw2.Size = new System.Drawing.Size(78, 21);
            this.textBoxOkZPPw2.TabIndex = 508;
            this.textBoxOkZPPw2.TabStop = false;
            // 
            // textBoxOkW2
            // 
            this.textBoxOkW2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxOkW2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxOkW2.Location = new System.Drawing.Point(643, 572);
            this.textBoxOkW2.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxOkW2.Name = "textBoxOkW2";
            this.textBoxOkW2.ReadOnly = true;
            this.textBoxOkW2.Size = new System.Drawing.Size(78, 21);
            this.textBoxOkW2.TabIndex = 508;
            this.textBoxOkW2.TabStop = false;
            // 
            // textBox12ZPPw2
            // 
            this.textBox12ZPPw2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox12ZPPw2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox12ZPPw2.Location = new System.Drawing.Point(544, 341);
            this.textBox12ZPPw2.Margin = new System.Windows.Forms.Padding(0);
            this.textBox12ZPPw2.Name = "textBox12ZPPw2";
            this.textBox12ZPPw2.ReadOnly = true;
            this.textBox12ZPPw2.Size = new System.Drawing.Size(78, 21);
            this.textBox12ZPPw2.TabIndex = 508;
            this.textBox12ZPPw2.TabStop = false;
            // 
            // textBox12SIPw2
            // 
            this.textBox12SIPw2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox12SIPw2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox12SIPw2.Location = new System.Drawing.Point(544, 572);
            this.textBox12SIPw2.Margin = new System.Windows.Forms.Padding(0);
            this.textBox12SIPw2.Name = "textBox12SIPw2";
            this.textBox12SIPw2.ReadOnly = true;
            this.textBox12SIPw2.Size = new System.Drawing.Size(78, 21);
            this.textBox12SIPw2.TabIndex = 508;
            this.textBox12SIPw2.TabStop = false;
            // 
            // textBox11ZPPw2
            // 
            this.textBox11ZPPw2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox11ZPPw2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox11ZPPw2.Location = new System.Drawing.Point(445, 341);
            this.textBox11ZPPw2.Margin = new System.Windows.Forms.Padding(0);
            this.textBox11ZPPw2.Name = "textBox11ZPPw2";
            this.textBox11ZPPw2.ReadOnly = true;
            this.textBox11ZPPw2.Size = new System.Drawing.Size(78, 21);
            this.textBox11ZPPw2.TabIndex = 508;
            this.textBox11ZPPw2.TabStop = false;
            // 
            // textBox11SIPw2
            // 
            this.textBox11SIPw2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox11SIPw2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox11SIPw2.Location = new System.Drawing.Point(445, 572);
            this.textBox11SIPw2.Margin = new System.Windows.Forms.Padding(0);
            this.textBox11SIPw2.Name = "textBox11SIPw2";
            this.textBox11SIPw2.ReadOnly = true;
            this.textBox11SIPw2.Size = new System.Drawing.Size(78, 21);
            this.textBox11SIPw2.TabIndex = 508;
            this.textBox11SIPw2.TabStop = false;
            // 
            // textBox10ZPPw2
            // 
            this.textBox10ZPPw2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox10ZPPw2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox10ZPPw2.Location = new System.Drawing.Point(346, 341);
            this.textBox10ZPPw2.Margin = new System.Windows.Forms.Padding(0);
            this.textBox10ZPPw2.Name = "textBox10ZPPw2";
            this.textBox10ZPPw2.ReadOnly = true;
            this.textBox10ZPPw2.Size = new System.Drawing.Size(78, 21);
            this.textBox10ZPPw2.TabIndex = 508;
            this.textBox10ZPPw2.TabStop = false;
            // 
            // textBox10SIPw2
            // 
            this.textBox10SIPw2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox10SIPw2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox10SIPw2.Location = new System.Drawing.Point(346, 572);
            this.textBox10SIPw2.Margin = new System.Windows.Forms.Padding(0);
            this.textBox10SIPw2.Name = "textBox10SIPw2";
            this.textBox10SIPw2.ReadOnly = true;
            this.textBox10SIPw2.Size = new System.Drawing.Size(78, 21);
            this.textBox10SIPw2.TabIndex = 508;
            this.textBox10SIPw2.TabStop = false;
            // 
            // textBox9ZPPw2
            // 
            this.textBox9ZPPw2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox9ZPPw2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox9ZPPw2.Location = new System.Drawing.Point(247, 341);
            this.textBox9ZPPw2.Margin = new System.Windows.Forms.Padding(0);
            this.textBox9ZPPw2.Name = "textBox9ZPPw2";
            this.textBox9ZPPw2.ReadOnly = true;
            this.textBox9ZPPw2.Size = new System.Drawing.Size(78, 21);
            this.textBox9ZPPw2.TabIndex = 508;
            this.textBox9ZPPw2.TabStop = false;
            // 
            // textBox9SIPw2
            // 
            this.textBox9SIPw2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox9SIPw2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox9SIPw2.Location = new System.Drawing.Point(247, 572);
            this.textBox9SIPw2.Margin = new System.Windows.Forms.Padding(0);
            this.textBox9SIPw2.Name = "textBox9SIPw2";
            this.textBox9SIPw2.ReadOnly = true;
            this.textBox9SIPw2.Size = new System.Drawing.Size(78, 21);
            this.textBox9SIPw2.TabIndex = 508;
            this.textBox9SIPw2.TabStop = false;
            // 
            // textBox41
            // 
            this.textBox41.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox41.Location = new System.Drawing.Point(31, 209);
            this.textBox41.Margin = new System.Windows.Forms.Padding(0);
            this.textBox41.Multiline = true;
            this.textBox41.Name = "textBox41";
            this.textBox41.Size = new System.Drawing.Size(216, 111);
            this.textBox41.TabIndex = 498;
            this.textBox41.TabStop = false;
            this.textBox41.Text = "\r\n\r\nУ Ч Е Б Н И   П Р Е Д М Е Т И";
            this.textBox41.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox411
            // 
            this.textBox411.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox411.Location = new System.Drawing.Point(31, 440);
            this.textBox411.Margin = new System.Windows.Forms.Padding(0);
            this.textBox411.Multiline = true;
            this.textBox411.Name = "textBox411";
            this.textBox411.Size = new System.Drawing.Size(216, 111);
            this.textBox411.TabIndex = 498;
            this.textBox411.TabStop = false;
            this.textBox411.Text = "\r\n\r\nУ Ч Е Б Н И   П Р Е Д М Е Т И";
            this.textBox411.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox40
            // 
            this.textBox40.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox40.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox40.Location = new System.Drawing.Point(544, 261);
            this.textBox40.Margin = new System.Windows.Forms.Padding(0);
            this.textBox40.Multiline = true;
            this.textBox40.Name = "textBox40";
            this.textBox40.Size = new System.Drawing.Size(99, 59);
            this.textBox40.TabIndex = 501;
            this.textBox40.TabStop = false;
            this.textBox40.Text = "Годишна \r\nоценка";
            this.textBox40.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox456
            // 
            this.textBox456.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox456.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox456.Location = new System.Drawing.Point(544, 492);
            this.textBox456.Margin = new System.Windows.Forms.Padding(0);
            this.textBox456.Multiline = true;
            this.textBox456.Name = "textBox456";
            this.textBox456.Size = new System.Drawing.Size(99, 59);
            this.textBox456.TabIndex = 501;
            this.textBox456.TabStop = false;
            this.textBox456.Text = "Годишна \r\nоценка";
            this.textBox456.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox39
            // 
            this.textBox39.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox39.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox39.Location = new System.Drawing.Point(445, 261);
            this.textBox39.Margin = new System.Windows.Forms.Padding(0);
            this.textBox39.Multiline = true;
            this.textBox39.Name = "textBox39";
            this.textBox39.Size = new System.Drawing.Size(99, 59);
            this.textBox39.TabIndex = 501;
            this.textBox39.TabStop = false;
            this.textBox39.Text = "Годишна \r\nоценка";
            this.textBox39.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox445
            // 
            this.textBox445.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox445.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox445.Location = new System.Drawing.Point(445, 492);
            this.textBox445.Margin = new System.Windows.Forms.Padding(0);
            this.textBox445.Multiline = true;
            this.textBox445.Name = "textBox445";
            this.textBox445.Size = new System.Drawing.Size(99, 59);
            this.textBox445.TabIndex = 501;
            this.textBox445.TabStop = false;
            this.textBox445.Text = "Годишна \r\nоценка";
            this.textBox445.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox26
            // 
            this.textBox26.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox26.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox26.Location = new System.Drawing.Point(346, 261);
            this.textBox26.Margin = new System.Windows.Forms.Padding(0);
            this.textBox26.Multiline = true;
            this.textBox26.Name = "textBox26";
            this.textBox26.Size = new System.Drawing.Size(99, 59);
            this.textBox26.TabIndex = 501;
            this.textBox26.TabStop = false;
            this.textBox26.Text = "Годишна \r\nоценка";
            this.textBox26.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox434
            // 
            this.textBox434.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox434.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox434.Location = new System.Drawing.Point(346, 492);
            this.textBox434.Margin = new System.Windows.Forms.Padding(0);
            this.textBox434.Multiline = true;
            this.textBox434.Name = "textBox434";
            this.textBox434.Size = new System.Drawing.Size(99, 59);
            this.textBox434.TabIndex = 501;
            this.textBox434.TabStop = false;
            this.textBox434.Text = "Годишна \r\nоценка";
            this.textBox434.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox22
            // 
            this.textBox22.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox22.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox22.Location = new System.Drawing.Point(247, 261);
            this.textBox22.Margin = new System.Windows.Forms.Padding(0);
            this.textBox22.Multiline = true;
            this.textBox22.Name = "textBox22";
            this.textBox22.Size = new System.Drawing.Size(99, 59);
            this.textBox22.TabIndex = 501;
            this.textBox22.TabStop = false;
            this.textBox22.Text = "Годишна \r\nоценка";
            this.textBox22.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox412
            // 
            this.textBox412.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox412.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox412.Location = new System.Drawing.Point(247, 492);
            this.textBox412.Margin = new System.Windows.Forms.Padding(0);
            this.textBox412.Multiline = true;
            this.textBox412.Name = "textBox412";
            this.textBox412.Size = new System.Drawing.Size(99, 59);
            this.textBox412.TabIndex = 501;
            this.textBox412.TabStop = false;
            this.textBox412.Text = "Годишна \r\nоценка";
            this.textBox412.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox21
            // 
            this.textBox21.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox21.Location = new System.Drawing.Point(643, 209);
            this.textBox21.Margin = new System.Windows.Forms.Padding(0);
            this.textBox21.Multiline = true;
            this.textBox21.Name = "textBox21";
            this.textBox21.Size = new System.Drawing.Size(126, 111);
            this.textBox21.TabIndex = 500;
            this.textBox21.TabStop = false;
            this.textBox21.Text = "\r\n\r\nОкончателна \r\nоценка";
            this.textBox21.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox466
            // 
            this.textBox466.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox466.Location = new System.Drawing.Point(643, 440);
            this.textBox466.Margin = new System.Windows.Forms.Padding(0);
            this.textBox466.Multiline = true;
            this.textBox466.Name = "textBox466";
            this.textBox466.Size = new System.Drawing.Size(126, 111);
            this.textBox466.TabIndex = 500;
            this.textBox466.TabStop = false;
            this.textBox466.Text = "\r\n\r\nОкончателна \r\nоценка";
            this.textBox466.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox19
            // 
            this.textBox19.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox19.Location = new System.Drawing.Point(544, 235);
            this.textBox19.Margin = new System.Windows.Forms.Padding(0);
            this.textBox19.Multiline = true;
            this.textBox19.Name = "textBox19";
            this.textBox19.Size = new System.Drawing.Size(99, 26);
            this.textBox19.TabIndex = 500;
            this.textBox19.TabStop = false;
            this.textBox19.Text = "XII клас ";
            this.textBox19.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox455
            // 
            this.textBox455.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox455.Location = new System.Drawing.Point(544, 466);
            this.textBox455.Margin = new System.Windows.Forms.Padding(0);
            this.textBox455.Multiline = true;
            this.textBox455.Name = "textBox455";
            this.textBox455.Size = new System.Drawing.Size(99, 26);
            this.textBox455.TabIndex = 500;
            this.textBox455.TabStop = false;
            this.textBox455.Text = "XII клас ";
            this.textBox455.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox18
            // 
            this.textBox18.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox18.Location = new System.Drawing.Point(445, 235);
            this.textBox18.Margin = new System.Windows.Forms.Padding(0);
            this.textBox18.Multiline = true;
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new System.Drawing.Size(99, 26);
            this.textBox18.TabIndex = 500;
            this.textBox18.TabStop = false;
            this.textBox18.Text = "XI клас ";
            this.textBox18.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox444
            // 
            this.textBox444.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox444.Location = new System.Drawing.Point(445, 466);
            this.textBox444.Margin = new System.Windows.Forms.Padding(0);
            this.textBox444.Multiline = true;
            this.textBox444.Name = "textBox444";
            this.textBox444.Size = new System.Drawing.Size(99, 26);
            this.textBox444.TabIndex = 500;
            this.textBox444.TabStop = false;
            this.textBox444.Text = "XI клас ";
            this.textBox444.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox17
            // 
            this.textBox17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox17.Location = new System.Drawing.Point(346, 235);
            this.textBox17.Margin = new System.Windows.Forms.Padding(0);
            this.textBox17.Multiline = true;
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new System.Drawing.Size(99, 26);
            this.textBox17.TabIndex = 500;
            this.textBox17.TabStop = false;
            this.textBox17.Text = "X клас ";
            this.textBox17.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox433
            // 
            this.textBox433.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox433.Location = new System.Drawing.Point(346, 466);
            this.textBox433.Margin = new System.Windows.Forms.Padding(0);
            this.textBox433.Multiline = true;
            this.textBox433.Name = "textBox433";
            this.textBox433.Size = new System.Drawing.Size(99, 26);
            this.textBox433.TabIndex = 500;
            this.textBox433.TabStop = false;
            this.textBox433.Text = "X клас ";
            this.textBox433.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox16
            // 
            this.textBox16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox16.Location = new System.Drawing.Point(9, 183);
            this.textBox16.Margin = new System.Windows.Forms.Padding(0);
            this.textBox16.Multiline = true;
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(760, 26);
            this.textBox16.TabIndex = 500;
            this.textBox16.TabStop = false;
            this.textBox16.Text = "Успех от задължителноизбираема/профилирана подготовка (ЗПП)";
            this.textBox16.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox14
            // 
            this.textBox14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox14.Location = new System.Drawing.Point(247, 235);
            this.textBox14.Margin = new System.Windows.Forms.Padding(0);
            this.textBox14.Multiline = true;
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(99, 26);
            this.textBox14.TabIndex = 500;
            this.textBox14.TabStop = false;
            this.textBox14.Text = "IX клас ";
            this.textBox14.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox546
            // 
            this.textBox546.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox546.Location = new System.Drawing.Point(9, 414);
            this.textBox546.Margin = new System.Windows.Forms.Padding(0);
            this.textBox546.Multiline = true;
            this.textBox546.Name = "textBox546";
            this.textBox546.Size = new System.Drawing.Size(760, 26);
            this.textBox546.TabIndex = 500;
            this.textBox546.TabStop = false;
            this.textBox546.Text = "Успех от свободноизбираема подготовка";
            this.textBox546.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox412kl
            // 
            this.textBox412kl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox412kl.Location = new System.Drawing.Point(544, 209);
            this.textBox412kl.Margin = new System.Windows.Forms.Padding(0);
            this.textBox412kl.Multiline = true;
            this.textBox412kl.Name = "textBox412kl";
            this.textBox412kl.Size = new System.Drawing.Size(99, 26);
            this.textBox412kl.TabIndex = 499;
            this.textBox412kl.TabStop = false;
            this.textBox412kl.Text = "ххх г. ";
            this.textBox412kl.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox413
            // 
            this.textBox413.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox413.Location = new System.Drawing.Point(247, 466);
            this.textBox413.Margin = new System.Windows.Forms.Padding(0);
            this.textBox413.Multiline = true;
            this.textBox413.Name = "textBox413";
            this.textBox413.Size = new System.Drawing.Size(99, 26);
            this.textBox413.TabIndex = 500;
            this.textBox413.TabStop = false;
            this.textBox413.Text = "IX клас ";
            this.textBox413.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox411kl
            // 
            this.textBox411kl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox411kl.Location = new System.Drawing.Point(445, 209);
            this.textBox411kl.Margin = new System.Windows.Forms.Padding(0);
            this.textBox411kl.Multiline = true;
            this.textBox411kl.Name = "textBox411kl";
            this.textBox411kl.Size = new System.Drawing.Size(99, 26);
            this.textBox411kl.TabIndex = 499;
            this.textBox411kl.TabStop = false;
            this.textBox411kl.Text = "ххх г. ";
            this.textBox411kl.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox12kl
            // 
            this.textBox12kl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox12kl.Location = new System.Drawing.Point(544, 440);
            this.textBox12kl.Margin = new System.Windows.Forms.Padding(0);
            this.textBox12kl.Multiline = true;
            this.textBox12kl.Name = "textBox12kl";
            this.textBox12kl.Size = new System.Drawing.Size(99, 26);
            this.textBox12kl.TabIndex = 499;
            this.textBox12kl.TabStop = false;
            this.textBox12kl.Text = "ххх г. ";
            this.textBox12kl.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox410kl
            // 
            this.textBox410kl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox410kl.Location = new System.Drawing.Point(346, 209);
            this.textBox410kl.Margin = new System.Windows.Forms.Padding(0);
            this.textBox410kl.Multiline = true;
            this.textBox410kl.Name = "textBox410kl";
            this.textBox410kl.Size = new System.Drawing.Size(99, 26);
            this.textBox410kl.TabIndex = 499;
            this.textBox410kl.TabStop = false;
            this.textBox410kl.Text = "ххх г. ";
            this.textBox410kl.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox11kl
            // 
            this.textBox11kl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox11kl.Location = new System.Drawing.Point(445, 440);
            this.textBox11kl.Margin = new System.Windows.Forms.Padding(0);
            this.textBox11kl.Multiline = true;
            this.textBox11kl.Name = "textBox11kl";
            this.textBox11kl.Size = new System.Drawing.Size(99, 26);
            this.textBox11kl.TabIndex = 499;
            this.textBox11kl.TabStop = false;
            this.textBox11kl.Text = "ххх г. ";
            this.textBox11kl.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox49kl
            // 
            this.textBox49kl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox49kl.Location = new System.Drawing.Point(247, 209);
            this.textBox49kl.Margin = new System.Windows.Forms.Padding(0);
            this.textBox49kl.Multiline = true;
            this.textBox49kl.Name = "textBox49kl";
            this.textBox49kl.Size = new System.Drawing.Size(99, 26);
            this.textBox49kl.TabIndex = 499;
            this.textBox49kl.TabStop = false;
            this.textBox49kl.Text = "ххх г. ";
            this.textBox49kl.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox10kl
            // 
            this.textBox10kl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox10kl.Location = new System.Drawing.Point(346, 440);
            this.textBox10kl.Margin = new System.Windows.Forms.Padding(0);
            this.textBox10kl.Multiline = true;
            this.textBox10kl.Name = "textBox10kl";
            this.textBox10kl.Size = new System.Drawing.Size(99, 26);
            this.textBox10kl.TabIndex = 499;
            this.textBox10kl.TabStop = false;
            this.textBox10kl.Text = "ххх г. ";
            this.textBox10kl.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox3
            // 
            this.textBox3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox3.Location = new System.Drawing.Point(9, 209);
            this.textBox3.Margin = new System.Windows.Forms.Padding(0);
            this.textBox3.Multiline = true;
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(22, 111);
            this.textBox3.TabIndex = 497;
            this.textBox3.TabStop = false;
            this.textBox3.Text = "\r\n\r\n№";
            this.textBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox9kl
            // 
            this.textBox9kl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox9kl.Location = new System.Drawing.Point(247, 440);
            this.textBox9kl.Margin = new System.Windows.Forms.Padding(0);
            this.textBox9kl.Multiline = true;
            this.textBox9kl.Name = "textBox9kl";
            this.textBox9kl.Size = new System.Drawing.Size(99, 26);
            this.textBox9kl.TabIndex = 499;
            this.textBox9kl.TabStop = false;
            this.textBox9kl.Text = "ххх г. ";
            this.textBox9kl.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox416
            // 
            this.textBox416.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox416.Location = new System.Drawing.Point(9, 440);
            this.textBox416.Margin = new System.Windows.Forms.Padding(0);
            this.textBox416.Multiline = true;
            this.textBox416.Name = "textBox416";
            this.textBox416.Size = new System.Drawing.Size(22, 111);
            this.textBox416.TabIndex = 497;
            this.textBox416.TabStop = false;
            this.textBox416.Text = "\r\n\r\n№";
            this.textBox416.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // buttonSaveSuccess
            // 
            this.buttonSaveSuccess.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonSaveSuccess.Image = global::E_school.Properties.Resources.Ok_icon1;
            this.buttonSaveSuccess.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonSaveSuccess.Location = new System.Drawing.Point(997, 18);
            this.buttonSaveSuccess.Name = "buttonSaveSuccess";
            this.buttonSaveSuccess.Size = new System.Drawing.Size(183, 46);
            this.buttonSaveSuccess.TabIndex = 1126;
            this.buttonSaveSuccess.Text = "Запиши успеха за дипломата";
            this.buttonSaveSuccess.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttonSaveSuccess.UseVisualStyleBackColor = true;
            this.buttonSaveSuccess.Click += new System.EventHandler(this.buttonSaveSuccess_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPageUspeh);
            this.tabControl1.Controls.Add(this.tabPageDZI_SIP);
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Location = new System.Drawing.Point(13, 72);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1250, 750);
            this.tabControl1.TabIndex = 400;
            // 
            // tabPageUspeh
            // 
            this.tabPageUspeh.AutoScroll = true;
            this.tabPageUspeh.BackColor = System.Drawing.Color.WhiteSmoke;
            this.tabPageUspeh.Controls.Add(this.buttonEditFinaly);
            this.tabPageUspeh.Controls.Add(this.buttonEdit12klas);
            this.tabPageUspeh.Controls.Add(this.buttonEdit11klas);
            this.tabPageUspeh.Controls.Add(this.buttonEdit10klas);
            this.tabPageUspeh.Controls.Add(this.buttonEdit9klas);
            this.tabPageUspeh.Controls.Add(this.buttonFinally);
            this.tabPageUspeh.Controls.Add(this.comboBox1Lang);
            this.tabPageUspeh.Controls.Add(this.buttonSave12kl);
            this.tabPageUspeh.Controls.Add(this.buttonSave11kl);
            this.tabPageUspeh.Controls.Add(this.buttonSave10kl);
            this.tabPageUspeh.Controls.Add(this.buttonSave9kl);
            this.tabPageUspeh.Controls.Add(this.label2);
            this.tabPageUspeh.Controls.Add(this.textBoxStuName);
            this.tabPageUspeh.Controls.Add(this.textBox1);
            this.tabPageUspeh.Controls.Add(this.textBox600);
            this.tabPageUspeh.Controls.Add(this.textBox358);
            this.tabPageUspeh.Controls.Add(this.textBox407);
            this.tabPageUspeh.Controls.Add(this.textBox409);
            this.tabPageUspeh.Controls.Add(this.textBox278);
            this.tabPageUspeh.Controls.Add(this.textBox357);
            this.tabPageUspeh.Controls.Add(this.textBox408);
            this.tabPageUspeh.Controls.Add(this.textBox277);
            this.tabPageUspeh.Controls.Add(this.textBox198);
            this.tabPageUspeh.Controls.Add(this.textBox525);
            this.tabPageUspeh.Controls.Add(this.textBox356);
            this.tabPageUspeh.Controls.Add(this.textBox197);
            this.tabPageUspeh.Controls.Add(this.textBox801);
            this.tabPageUspeh.Controls.Add(this.textBox196);
            this.tabPageUspeh.Controls.Add(this.textBox900);
            this.tabPageUspeh.Controls.Add(this.textBox800);
            this.tabPageUspeh.Controls.Add(this.textBoxFil);
            this.tabPageUspeh.Controls.Add(this.textBoxIzIzk);
            this.tabPageUspeh.Controls.Add(this.textBoxPsi);
            this.tabPageUspeh.Controls.Add(this.textBoxHim);
            this.tabPageUspeh.Controls.Add(this.textBoxIsto);
            this.tabPageUspeh.Controls.Add(this.textBoxFVSp);
            this.tabPageUspeh.Controls.Add(this.textBoxBiol);
            this.tabPageUspeh.Controls.Add(this.textBoxEtika);
            this.tabPageUspeh.Controls.Add(this.textBoxInfor);
            this.tabPageUspeh.Controls.Add(this.textBoxFiz);
            this.tabPageUspeh.Controls.Add(this.textBox670);
            this.tabPageUspeh.Controls.Add(this.textBoxMuz);
            this.tabPageUspeh.Controls.Add(this.textBoxInfT);
            this.tabPageUspeh.Controls.Add(this.textBox674);
            this.tabPageUspeh.Controls.Add(this.textBoxGeo);
            this.tabPageUspeh.Controls.Add(this.textBox676);
            this.tabPageUspeh.Controls.Add(this.textBox440);
            this.tabPageUspeh.Controls.Add(this.textBoxSvL);
            this.tabPageUspeh.Controls.Add(this.textBox650);
            this.tabPageUspeh.Controls.Add(this.textBox677);
            this.tabPageUspeh.Controls.Add(this.textBoxMath);
            this.tabPageUspeh.Controls.Add(this.textBox672);
            this.tabPageUspeh.Controls.Add(this.textBox640);
            this.tabPageUspeh.Controls.Add(this.textBox673);
            this.tabPageUspeh.Controls.Add(this.textBox255);
            this.tabPageUspeh.Controls.Add(this.textBox675);
            this.tabPageUspeh.Controls.Add(this.textBox430);
            this.tabPageUspeh.Controls.Add(this.textBox12Year);
            this.tabPageUspeh.Controls.Add(this.textBox63);
            this.tabPageUspeh.Controls.Add(this.textBox11Year);
            this.tabPageUspeh.Controls.Add(this.textBox671);
            this.tabPageUspeh.Controls.Add(this.textBoxBel);
            this.tabPageUspeh.Controls.Add(this.textBox10Year);
            this.tabPageUspeh.Controls.Add(this.textBox250);
            this.tabPageUspeh.Controls.Add(this.textBox11ZIP11);
            this.tabPageUspeh.Controls.Add(this.textBoxdipZIP11);
            this.tabPageUspeh.Controls.Add(this.textBox9Year);
            this.tabPageUspeh.Controls.Add(this.textBox12ZIP11);
            this.tabPageUspeh.Controls.Add(this.textBox11ZIP15);
            this.tabPageUspeh.Controls.Add(this.textBoxdipZIP15);
            this.tabPageUspeh.Controls.Add(this.textBox10ZIP11);
            this.tabPageUspeh.Controls.Add(this.textBox12ZIP15);
            this.tabPageUspeh.Controls.Add(this.textBox320);
            this.tabPageUspeh.Controls.Add(this.textBox10ZIP15);
            this.tabPageUspeh.Controls.Add(this.textBox11ZIP17);
            this.tabPageUspeh.Controls.Add(this.textBoxdipZIP17);
            this.tabPageUspeh.Controls.Add(this.textBox9ZIP11);
            this.tabPageUspeh.Controls.Add(this.textBox12ZIP17);
            this.tabPageUspeh.Controls.Add(this.textBox9ZIP15);
            this.tabPageUspeh.Controls.Add(this.textBox11ZIP7);
            this.tabPageUspeh.Controls.Add(this.textBoxdipZIP7);
            this.tabPageUspeh.Controls.Add(this.textBox10ZIP17);
            this.tabPageUspeh.Controls.Add(this.textBox12ZIP7);
            this.tabPageUspeh.Controls.Add(this.textBox270);
            this.tabPageUspeh.Controls.Add(this.textBox11ZIP9);
            this.tabPageUspeh.Controls.Add(this.textBoxdipZIP9);
            this.tabPageUspeh.Controls.Add(this.textBox10ZIP7);
            this.tabPageUspeh.Controls.Add(this.textBox12ZIP9);
            this.tabPageUspeh.Controls.Add(this.textBox9ZIP17);
            this.tabPageUspeh.Controls.Add(this.textBox10ZIP9);
            this.tabPageUspeh.Controls.Add(this.textBox9ZIP7);
            this.tabPageUspeh.Controls.Add(this.textBox11ZIP13);
            this.tabPageUspeh.Controls.Add(this.textBoxdipZIP13);
            this.tabPageUspeh.Controls.Add(this.textBox9ZIP9);
            this.tabPageUspeh.Controls.Add(this.textBox12ZIP13);
            this.tabPageUspeh.Controls.Add(this.textBox11ZP11);
            this.tabPageUspeh.Controls.Add(this.textBoxdipZP11);
            this.tabPageUspeh.Controls.Add(this.textBox10ZIP13);
            this.tabPageUspeh.Controls.Add(this.textBox12ZP11);
            this.tabPageUspeh.Controls.Add(this.textBox230);
            this.tabPageUspeh.Controls.Add(this.textBox11ZP15);
            this.tabPageUspeh.Controls.Add(this.textBoxdipZP15);
            this.tabPageUspeh.Controls.Add(this.textBox10ZP11);
            this.tabPageUspeh.Controls.Add(this.textBox12ZP15);
            this.tabPageUspeh.Controls.Add(this.textBox9ZIP13);
            this.tabPageUspeh.Controls.Add(this.textBox11ZIP5);
            this.tabPageUspeh.Controls.Add(this.textBoxdipZIP5);
            this.tabPageUspeh.Controls.Add(this.textBox10ZP15);
            this.tabPageUspeh.Controls.Add(this.textBox12ZIP5);
            this.tabPageUspeh.Controls.Add(this.textBox9ZP11);
            this.tabPageUspeh.Controls.Add(this.textBox11ZIP18);
            this.tabPageUspeh.Controls.Add(this.textBoxSumOcZIP);
            this.tabPageUspeh.Controls.Add(this.textBox1300);
            this.tabPageUspeh.Controls.Add(this.textBoxdipZIP18);
            this.tabPageUspeh.Controls.Add(this.textBox10ZIP5);
            this.tabPageUspeh.Controls.Add(this.textBox12ZIP18);
            this.tabPageUspeh.Controls.Add(this.textBox9ZP15);
            this.tabPageUspeh.Controls.Add(this.textBox11ZP7);
            this.tabPageUspeh.Controls.Add(this.textBoxdipZP7);
            this.tabPageUspeh.Controls.Add(this.textBox10ZIP18);
            this.tabPageUspeh.Controls.Add(this.textBox12ZP7);
            this.tabPageUspeh.Controls.Add(this.textBox9ZIP5);
            this.tabPageUspeh.Controls.Add(this.textBox11ZIP10);
            this.tabPageUspeh.Controls.Add(this.textBoxdipZIP10);
            this.tabPageUspeh.Controls.Add(this.textBox10ZP7);
            this.tabPageUspeh.Controls.Add(this.textBox12ZIP10);
            this.tabPageUspeh.Controls.Add(this.textBox9ZIP18);
            this.tabPageUspeh.Controls.Add(this.textBox11ZP17);
            this.tabPageUspeh.Controls.Add(this.textBoxdipZP17);
            this.tabPageUspeh.Controls.Add(this.textBox10ZIP10);
            this.tabPageUspeh.Controls.Add(this.textBox12ZP17);
            this.tabPageUspeh.Controls.Add(this.textBox9ZP7);
            this.tabPageUspeh.Controls.Add(this.textBox10ZP17);
            this.tabPageUspeh.Controls.Add(this.textBox11ZIP14);
            this.tabPageUspeh.Controls.Add(this.textBoxdipZIP14);
            this.tabPageUspeh.Controls.Add(this.textBox9ZIP10);
            this.tabPageUspeh.Controls.Add(this.textBox12ZIP14);
            this.tabPageUspeh.Controls.Add(this.textBox9ZP17);
            this.tabPageUspeh.Controls.Add(this.textBox11ZP9);
            this.tabPageUspeh.Controls.Add(this.textBoxdipZP9);
            this.tabPageUspeh.Controls.Add(this.textBox10ZIP14);
            this.tabPageUspeh.Controls.Add(this.textBox12ZP9);
            this.tabPageUspeh.Controls.Add(this.textBox500);
            this.tabPageUspeh.Controls.Add(this.textBox11ZP18);
            this.tabPageUspeh.Controls.Add(this.textBoxSrZP);
            this.tabPageUspeh.Controls.Add(this.textBoxdipZP18);
            this.tabPageUspeh.Controls.Add(this.textBox10ZP9);
            this.tabPageUspeh.Controls.Add(this.textBox12ZP18);
            this.tabPageUspeh.Controls.Add(this.textBox9ZIP14);
            this.tabPageUspeh.Controls.Add(this.textBox11ZIP6);
            this.tabPageUspeh.Controls.Add(this.textBoxdipZIP6);
            this.tabPageUspeh.Controls.Add(this.textBox10ZP18);
            this.tabPageUspeh.Controls.Add(this.textBox12ZIP6);
            this.tabPageUspeh.Controls.Add(this.textBox9ZP9);
            this.tabPageUspeh.Controls.Add(this.textBox11ZP13);
            this.tabPageUspeh.Controls.Add(this.textBoxdipZP13);
            this.tabPageUspeh.Controls.Add(this.textBox10ZIP6);
            this.tabPageUspeh.Controls.Add(this.textBox12ZP13);
            this.tabPageUspeh.Controls.Add(this.textBox9ZP18);
            this.tabPageUspeh.Controls.Add(this.textBox11ZP10);
            this.tabPageUspeh.Controls.Add(this.textBoxdipZP10);
            this.tabPageUspeh.Controls.Add(this.textBox10ZP13);
            this.tabPageUspeh.Controls.Add(this.textBox12ZP10);
            this.tabPageUspeh.Controls.Add(this.textBox9ZIP6);
            this.tabPageUspeh.Controls.Add(this.textBox11ZIP16);
            this.tabPageUspeh.Controls.Add(this.textBoxdipZIP16);
            this.tabPageUspeh.Controls.Add(this.textBox10ZP10);
            this.tabPageUspeh.Controls.Add(this.textBox12ZIP16);
            this.tabPageUspeh.Controls.Add(this.textBox9ZP13);
            this.tabPageUspeh.Controls.Add(this.textBox11ZP5);
            this.tabPageUspeh.Controls.Add(this.textBoxdipZP5);
            this.tabPageUspeh.Controls.Add(this.textBox10ZIP16);
            this.tabPageUspeh.Controls.Add(this.textBox12ZP5);
            this.tabPageUspeh.Controls.Add(this.textBox9ZP10);
            this.tabPageUspeh.Controls.Add(this.textBox11ZP14);
            this.tabPageUspeh.Controls.Add(this.textBoxdipZP14);
            this.tabPageUspeh.Controls.Add(this.textBox10ZP5);
            this.tabPageUspeh.Controls.Add(this.textBox12ZP14);
            this.tabPageUspeh.Controls.Add(this.textBox9ZIP16);
            this.tabPageUspeh.Controls.Add(this.textBox11ZIP8);
            this.tabPageUspeh.Controls.Add(this.textBoxdipZIP8);
            this.tabPageUspeh.Controls.Add(this.textBox10ZP14);
            this.tabPageUspeh.Controls.Add(this.textBox12ZIP8);
            this.tabPageUspeh.Controls.Add(this.textBox9ZP5);
            this.tabPageUspeh.Controls.Add(this.textBox10ZIP8);
            this.tabPageUspeh.Controls.Add(this.textBox9ZP14);
            this.tabPageUspeh.Controls.Add(this.textBox11ZP6);
            this.tabPageUspeh.Controls.Add(this.textBoxdipZP6);
            this.tabPageUspeh.Controls.Add(this.textBox12ZP6);
            this.tabPageUspeh.Controls.Add(this.textBox9ZIP8);
            this.tabPageUspeh.Controls.Add(this.textBox11ZIP12);
            this.tabPageUspeh.Controls.Add(this.textBoxdipZIP12);
            this.tabPageUspeh.Controls.Add(this.textBox10ZP6);
            this.tabPageUspeh.Controls.Add(this.textBox12ZIP12);
            this.tabPageUspeh.Controls.Add(this.textBox11ZIPFil1);
            this.tabPageUspeh.Controls.Add(this.textBoxdipFilZIP1);
            this.tabPageUspeh.Controls.Add(this.textBox10ZIP12);
            this.tabPageUspeh.Controls.Add(this.textBox246);
            this.tabPageUspeh.Controls.Add(this.textBox9ZP6);
            this.tabPageUspeh.Controls.Add(this.textBox11ZP16);
            this.tabPageUspeh.Controls.Add(this.textBoxdipZP16);
            this.tabPageUspeh.Controls.Add(this.textBox166);
            this.tabPageUspeh.Controls.Add(this.textBox12ZP16);
            this.tabPageUspeh.Controls.Add(this.textBox9ZIP12);
            this.tabPageUspeh.Controls.Add(this.textBox11ZIP4);
            this.tabPageUspeh.Controls.Add(this.textBoxdipZIP4);
            this.tabPageUspeh.Controls.Add(this.textBox10ZP16);
            this.tabPageUspeh.Controls.Add(this.textBox12ZIP4);
            this.tabPageUspeh.Controls.Add(this.textBox55);
            this.tabPageUspeh.Controls.Add(this.textBox11ZIPHim1);
            this.tabPageUspeh.Controls.Add(this.textBoxdipHimZIP1);
            this.tabPageUspeh.Controls.Add(this.textBox10ZIP4);
            this.tabPageUspeh.Controls.Add(this.textBox12ZIPHim1);
            this.tabPageUspeh.Controls.Add(this.textBox9ZP16);
            this.tabPageUspeh.Controls.Add(this.textBox11ZP8);
            this.tabPageUspeh.Controls.Add(this.textBoxdipZP8);
            this.tabPageUspeh.Controls.Add(this.textBox10ZIPHim1);
            this.tabPageUspeh.Controls.Add(this.textBox12ZP8);
            this.tabPageUspeh.Controls.Add(this.textBox9ZIP4);
            this.tabPageUspeh.Controls.Add(this.textBox321);
            this.tabPageUspeh.Controls.Add(this.textBoxdipIzobrZIP1);
            this.tabPageUspeh.Controls.Add(this.textBox10ZP8);
            this.tabPageUspeh.Controls.Add(this.textBox241);
            this.tabPageUspeh.Controls.Add(this.textBox9ZIPHim1);
            this.tabPageUspeh.Controls.Add(this.textBox11ZIPIst1);
            this.tabPageUspeh.Controls.Add(this.textBoxdipIstZIP1);
            this.tabPageUspeh.Controls.Add(this.textBox161);
            this.tabPageUspeh.Controls.Add(this.textBox12ZIPIst1);
            this.tabPageUspeh.Controls.Add(this.textBox9ZP8);
            this.tabPageUspeh.Controls.Add(this.textBox11ZP12);
            this.tabPageUspeh.Controls.Add(this.textBoxdipZP12);
            this.tabPageUspeh.Controls.Add(this.textBox10ZIPIst1);
            this.tabPageUspeh.Controls.Add(this.textBox12ZP12);
            this.tabPageUspeh.Controls.Add(this.textBox85);
            this.tabPageUspeh.Controls.Add(this.textBox318);
            this.tabPageUspeh.Controls.Add(this.textBoxdipPsZIP1);
            this.tabPageUspeh.Controls.Add(this.textBox10ZP12);
            this.tabPageUspeh.Controls.Add(this.textBox238);
            this.tabPageUspeh.Controls.Add(this.textBox9ZIPIst1);
            this.tabPageUspeh.Controls.Add(this.textBox10ZIPPs1);
            this.tabPageUspeh.Controls.Add(this.textBox9ZP12);
            this.tabPageUspeh.Controls.Add(this.textBox11ZP4);
            this.tabPageUspeh.Controls.Add(this.textBoxdipZP4);
            this.tabPageUspeh.Controls.Add(this.textBox12ZP4);
            this.tabPageUspeh.Controls.Add(this.textBox9ZIPPs1);
            this.tabPageUspeh.Controls.Add(this.textBox11ZIPBio1);
            this.tabPageUspeh.Controls.Add(this.textBoxdipBioZIP1);
            this.tabPageUspeh.Controls.Add(this.textBox10ZP4);
            this.tabPageUspeh.Controls.Add(this.textBox12ZIPBio1);
            this.tabPageUspeh.Controls.Add(this.textBox11Fil1);
            this.tabPageUspeh.Controls.Add(this.textBoxdipFil1);
            this.tabPageUspeh.Controls.Add(this.textBox10ZIPBio1);
            this.tabPageUspeh.Controls.Add(this.textBox234);
            this.tabPageUspeh.Controls.Add(this.textBox9ZP4);
            this.tabPageUspeh.Controls.Add(this.textBox11Him1);
            this.tabPageUspeh.Controls.Add(this.textBoxdipHim1);
            this.tabPageUspeh.Controls.Add(this.textBox154);
            this.tabPageUspeh.Controls.Add(this.textBox12Him1);
            this.tabPageUspeh.Controls.Add(this.textBox9BioZIP1);
            this.tabPageUspeh.Controls.Add(this.textBox11ZIPInf1);
            this.tabPageUspeh.Controls.Add(this.textBoxdipInfZIP1);
            this.tabPageUspeh.Controls.Add(this.textBox10Him1);
            this.tabPageUspeh.Controls.Add(this.textBox12ZIPInf1);
            this.tabPageUspeh.Controls.Add(this.textBox52);
            this.tabPageUspeh.Controls.Add(this.textBoxBrOcZIP);
            this.tabPageUspeh.Controls.Add(this.textBox11ZIPFV1);
            this.tabPageUspeh.Controls.Add(this.textBox1100);
            this.tabPageUspeh.Controls.Add(this.textBoxdipFVZIP1);
            this.tabPageUspeh.Controls.Add(this.textBox10ZIPInf1);
            this.tabPageUspeh.Controls.Add(this.textBox231);
            this.tabPageUspeh.Controls.Add(this.textBox9Him1);
            this.tabPageUspeh.Controls.Add(this.textBox11Ist1);
            this.tabPageUspeh.Controls.Add(this.textBoxdipIst1);
            this.tabPageUspeh.Controls.Add(this.textBox10ZIPFV1);
            this.tabPageUspeh.Controls.Add(this.textBox12Ist1);
            this.tabPageUspeh.Controls.Add(this.textBox9ZIPInf1);
            this.tabPageUspeh.Controls.Add(this.textBox309);
            this.tabPageUspeh.Controls.Add(this.textBoxdipEtZIP1);
            this.tabPageUspeh.Controls.Add(this.textBox10Ist1);
            this.tabPageUspeh.Controls.Add(this.textBox229);
            this.tabPageUspeh.Controls.Add(this.textBox9ZIPFv1);
            this.tabPageUspeh.Controls.Add(this.textBox308);
            this.tabPageUspeh.Controls.Add(this.textBoxdipIzobr1);
            this.tabPageUspeh.Controls.Add(this.textBox10ZIPEt1);
            this.tabPageUspeh.Controls.Add(this.textBox228);
            this.tabPageUspeh.Controls.Add(this.textBox9Ist1);
            this.tabPageUspeh.Controls.Add(this.textBox148);
            this.tabPageUspeh.Controls.Add(this.textBox11ZIPFz1);
            this.tabPageUspeh.Controls.Add(this.textBoxdipFzZIP1);
            this.tabPageUspeh.Controls.Add(this.textBox9ZIPEt1);
            this.tabPageUspeh.Controls.Add(this.textBox12ZIPFz1);
            this.tabPageUspeh.Controls.Add(this.textBox9Izobr1);
            this.tabPageUspeh.Controls.Add(this.textBox11Ps1);
            this.tabPageUspeh.Controls.Add(this.textBoxdipPs1);
            this.tabPageUspeh.Controls.Add(this.textBox10ZIPFz1);
            this.tabPageUspeh.Controls.Add(this.textBox226);
            this.tabPageUspeh.Controls.Add(this.textBox450);
            this.tabPageUspeh.Controls.Add(this.textBoxSrZPW);
            this.tabPageUspeh.Controls.Add(this.textBox11FV1);
            this.tabPageUspeh.Controls.Add(this.textBoxdipFV1);
            this.tabPageUspeh.Controls.Add(this.textBox10Ps1);
            this.tabPageUspeh.Controls.Add(this.textBox12FV1);
            this.tabPageUspeh.Controls.Add(this.textBox9ZIPFz1);
            this.tabPageUspeh.Controls.Add(this.textBox11ZIPIT1);
            this.tabPageUspeh.Controls.Add(this.textBoxdipITZIP1);
            this.tabPageUspeh.Controls.Add(this.textBox10FV1);
            this.tabPageUspeh.Controls.Add(this.textBox12ZIPIT1);
            this.tabPageUspeh.Controls.Add(this.textBox9Ps1);
            this.tabPageUspeh.Controls.Add(this.textBox11Bio1);
            this.tabPageUspeh.Controls.Add(this.textBoxdipBio1);
            this.tabPageUspeh.Controls.Add(this.textBox10ZIPIT1);
            this.tabPageUspeh.Controls.Add(this.textBox12Bio1);
            this.tabPageUspeh.Controls.Add(this.textBox9FV1);
            this.tabPageUspeh.Controls.Add(this.textBox302);
            this.tabPageUspeh.Controls.Add(this.textBoxdipEt1);
            this.tabPageUspeh.Controls.Add(this.textBox10Bio1);
            this.tabPageUspeh.Controls.Add(this.textBox222);
            this.tabPageUspeh.Controls.Add(this.textBox9ZIPIT1);
            this.tabPageUspeh.Controls.Add(this.textBox301);
            this.tabPageUspeh.Controls.Add(this.textBoxdipMzZIP1);
            this.tabPageUspeh.Controls.Add(this.textBox10Et1);
            this.tabPageUspeh.Controls.Add(this.textBox221);
            this.tabPageUspeh.Controls.Add(this.textBox9Bio1);
            this.tabPageUspeh.Controls.Add(this.textBox11Inf1);
            this.tabPageUspeh.Controls.Add(this.textBoxdipInf1);
            this.tabPageUspeh.Controls.Add(this.textBox141);
            this.tabPageUspeh.Controls.Add(this.textBox12Inf1);
            this.tabPageUspeh.Controls.Add(this.textBox9Et1);
            this.tabPageUspeh.Controls.Add(this.textBox11Fz1);
            this.tabPageUspeh.Controls.Add(this.textBoxdipFz1);
            this.tabPageUspeh.Controls.Add(this.textBox10Inf1);
            this.tabPageUspeh.Controls.Add(this.textBox12Fz1);
            this.tabPageUspeh.Controls.Add(this.textBox75);
            this.tabPageUspeh.Controls.Add(this.textBox11ZIPG1);
            this.tabPageUspeh.Controls.Add(this.textBoxdipGZIP1);
            this.tabPageUspeh.Controls.Add(this.textBox10Fz1);
            this.tabPageUspeh.Controls.Add(this.textBox12ZIPG1);
            this.tabPageUspeh.Controls.Add(this.textBox9Inf1);
            this.tabPageUspeh.Controls.Add(this.textBox297);
            this.tabPageUspeh.Controls.Add(this.textBoxdipMz1);
            this.tabPageUspeh.Controls.Add(this.textBox10ZIPG1);
            this.tabPageUspeh.Controls.Add(this.textBox217);
            this.tabPageUspeh.Controls.Add(this.textBox9Fz1);
            this.tabPageUspeh.Controls.Add(this.textBox11IT1);
            this.tabPageUspeh.Controls.Add(this.textBoxdipIT1);
            this.tabPageUspeh.Controls.Add(this.textBox137);
            this.tabPageUspeh.Controls.Add(this.textBox12IT1);
            this.tabPageUspeh.Controls.Add(this.textBox9ZIPG1);
            this.tabPageUspeh.Controls.Add(this.textBox295);
            this.tabPageUspeh.Controls.Add(this.textBoxdipSvZIP1);
            this.tabPageUspeh.Controls.Add(this.textBox10IT1);
            this.tabPageUspeh.Controls.Add(this.textBox12ZIPSv1);
            this.tabPageUspeh.Controls.Add(this.textBox9Mz1);
            this.tabPageUspeh.Controls.Add(this.textBox11G1);
            this.tabPageUspeh.Controls.Add(this.textBoxdipG1);
            this.tabPageUspeh.Controls.Add(this.textBox135);
            this.tabPageUspeh.Controls.Add(this.textBox12G1);
            this.tabPageUspeh.Controls.Add(this.textBox9IT1);
            this.tabPageUspeh.Controls.Add(this.textBox293);
            this.tabPageUspeh.Controls.Add(this.textBoxdipSv1);
            this.tabPageUspeh.Controls.Add(this.textBox10G1);
            this.tabPageUspeh.Controls.Add(this.textBox12Sv1);
            this.tabPageUspeh.Controls.Add(this.textBox72);
            this.tabPageUspeh.Controls.Add(this.textBox11ZIPMat1);
            this.tabPageUspeh.Controls.Add(this.textBoxdipMatZIP1);
            this.tabPageUspeh.Controls.Add(this.textBox133);
            this.tabPageUspeh.Controls.Add(this.textBox12ZIPMat1);
            this.tabPageUspeh.Controls.Add(this.textBox9G1);
            this.tabPageUspeh.Controls.Add(this.textBox11Mat1);
            this.tabPageUspeh.Controls.Add(this.textBoxdipMat1);
            this.tabPageUspeh.Controls.Add(this.textBox10ZIPMat1);
            this.tabPageUspeh.Controls.Add(this.textBox12Mat1);
            this.tabPageUspeh.Controls.Add(this.textBox71);
            this.tabPageUspeh.Controls.Add(this.textBox11ZIP3);
            this.tabPageUspeh.Controls.Add(this.textBoxdipZIP3);
            this.tabPageUspeh.Controls.Add(this.textBox10Mat1);
            this.tabPageUspeh.Controls.Add(this.textBox12ZIP3);
            this.tabPageUspeh.Controls.Add(this.textBox9ZIPMat1);
            this.tabPageUspeh.Controls.Add(this.textBox11ZP3);
            this.tabPageUspeh.Controls.Add(this.textBoxdipZP3);
            this.tabPageUspeh.Controls.Add(this.textBox10ZIP3);
            this.tabPageUspeh.Controls.Add(this.textBox12ZP3);
            this.tabPageUspeh.Controls.Add(this.textBox9Mat1);
            this.tabPageUspeh.Controls.Add(this.textBox11ZIP2);
            this.tabPageUspeh.Controls.Add(this.textBoxdipZIP2);
            this.tabPageUspeh.Controls.Add(this.textBox10ZP3);
            this.tabPageUspeh.Controls.Add(this.textBox12ZIP2);
            this.tabPageUspeh.Controls.Add(this.textBox9ZIP3);
            this.tabPageUspeh.Controls.Add(this.textBox11ZP2);
            this.tabPageUspeh.Controls.Add(this.textBoxdipZP2);
            this.tabPageUspeh.Controls.Add(this.textBox10ZIP2);
            this.tabPageUspeh.Controls.Add(this.textBox12ZP2);
            this.tabPageUspeh.Controls.Add(this.textBox9ZP3);
            this.tabPageUspeh.Controls.Add(this.textBox11ZIP1);
            this.tabPageUspeh.Controls.Add(this.textBoxdipZIP1);
            this.tabPageUspeh.Controls.Add(this.textBox10ZP2);
            this.tabPageUspeh.Controls.Add(this.textBox12ZIP1);
            this.tabPageUspeh.Controls.Add(this.textBox9ZIP2);
            this.tabPageUspeh.Controls.Add(this.textBox11ZP1);
            this.tabPageUspeh.Controls.Add(this.textBoxdipZP1);
            this.tabPageUspeh.Controls.Add(this.textBox10ZIP1);
            this.tabPageUspeh.Controls.Add(this.textBox12ZP1);
            this.tabPageUspeh.Controls.Add(this.textBox9ZP2);
            this.tabPageUspeh.Controls.Add(this.textBox11ZIP2Lang1);
            this.tabPageUspeh.Controls.Add(this.textBoxdip2LangZIP1);
            this.tabPageUspeh.Controls.Add(this.textBox10ZP1);
            this.tabPageUspeh.Controls.Add(this.textBox12ZIP2Lang1);
            this.tabPageUspeh.Controls.Add(this.textBox9ZIP1);
            this.tabPageUspeh.Controls.Add(this.textBox112Lang1);
            this.tabPageUspeh.Controls.Add(this.textBoxdip2Lang1);
            this.tabPageUspeh.Controls.Add(this.textBox10ZIP2Lang1);
            this.tabPageUspeh.Controls.Add(this.textBox122Lang1);
            this.tabPageUspeh.Controls.Add(this.textBox9ZP1);
            this.tabPageUspeh.Controls.Add(this.textBox11ZIP1Lang1);
            this.tabPageUspeh.Controls.Add(this.textBoxdip1LangZIP1);
            this.tabPageUspeh.Controls.Add(this.textBox102Lang1);
            this.tabPageUspeh.Controls.Add(this.textBox121LangZIP1);
            this.tabPageUspeh.Controls.Add(this.textBox92LangZIP1);
            this.tabPageUspeh.Controls.Add(this.textBox111Lang1);
            this.tabPageUspeh.Controls.Add(this.textBoxdip1Lang1);
            this.tabPageUspeh.Controls.Add(this.textBox10ZIP1Lang1);
            this.tabPageUspeh.Controls.Add(this.textBox121Lang1);
            this.tabPageUspeh.Controls.Add(this.textBox92Lang1);
            this.tabPageUspeh.Controls.Add(this.textBox11BelZIP1);
            this.tabPageUspeh.Controls.Add(this.textBoxdipBELZIP1);
            this.tabPageUspeh.Controls.Add(this.textBox101Lang1);
            this.tabPageUspeh.Controls.Add(this.textBox12BelZIP1);
            this.tabPageUspeh.Controls.Add(this.textBox9ZIP1Lang1);
            this.tabPageUspeh.Controls.Add(this.textBox11Bel1);
            this.tabPageUspeh.Controls.Add(this.textBoxdipBEL1);
            this.tabPageUspeh.Controls.Add(this.textBox10BelZIP1);
            this.tabPageUspeh.Controls.Add(this.textBox12Bel1);
            this.tabPageUspeh.Controls.Add(this.textBox91Lang1);
            this.tabPageUspeh.Controls.Add(this.textBox10Bel1);
            this.tabPageUspeh.Controls.Add(this.textBox9BelZIP1);
            this.tabPageUspeh.Controls.Add(this.textBox9Bel1);
            this.tabPageUspeh.Controls.Add(this.comboBox2Lang);
            this.tabPageUspeh.Location = new System.Drawing.Point(4, 22);
            this.tabPageUspeh.Margin = new System.Windows.Forms.Padding(0);
            this.tabPageUspeh.Name = "tabPageUspeh";
            this.tabPageUspeh.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tabPageUspeh.Size = new System.Drawing.Size(1242, 724);
            this.tabPageUspeh.TabIndex = 0;
            this.tabPageUspeh.Text = "Успех за дипломата за средно образование";
            this.tabPageUspeh.Paint += new System.Windows.Forms.PaintEventHandler(this.tabPageUspeh_Paint);
            // 
            // buttonEditFinaly
            // 
            this.buttonEditFinaly.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonEditFinaly.Image = ((System.Drawing.Image)(resources.GetObject("buttonEditFinaly.Image")));
            this.buttonEditFinaly.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.buttonEditFinaly.Location = new System.Drawing.Point(1077, 567);
            this.buttonEditFinaly.Name = "buttonEditFinaly";
            this.buttonEditFinaly.Size = new System.Drawing.Size(122, 53);
            this.buttonEditFinaly.TabIndex = 1148;
            this.buttonEditFinaly.Text = "Промяна на окончателни оценки";
            this.buttonEditFinaly.UseVisualStyleBackColor = true;
            this.buttonEditFinaly.Click += new System.EventHandler(this.buttonEditFinaly_Click);
            // 
            // buttonEdit12klas
            // 
            this.buttonEdit12klas.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonEdit12klas.Image = ((System.Drawing.Image)(resources.GetObject("buttonEdit12klas.Image")));
            this.buttonEdit12klas.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonEdit12klas.Location = new System.Drawing.Point(854, 567);
            this.buttonEdit12klas.Name = "buttonEdit12klas";
            this.buttonEdit12klas.Size = new System.Drawing.Size(121, 35);
            this.buttonEdit12klas.TabIndex = 801;
            this.buttonEdit12klas.Text = "Промяна 12 клас";
            this.buttonEdit12klas.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttonEdit12klas.UseVisualStyleBackColor = true;
            this.buttonEdit12klas.Click += new System.EventHandler(this.buttonEdit12klas_Click);
            // 
            // buttonEdit11klas
            // 
            this.buttonEdit11klas.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonEdit11klas.Image = ((System.Drawing.Image)(resources.GetObject("buttonEdit11klas.Image")));
            this.buttonEdit11klas.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonEdit11klas.Location = new System.Drawing.Point(658, 567);
            this.buttonEdit11klas.Name = "buttonEdit11klas";
            this.buttonEdit11klas.Size = new System.Drawing.Size(120, 35);
            this.buttonEdit11klas.TabIndex = 801;
            this.buttonEdit11klas.Text = "Промяна 11 клас";
            this.buttonEdit11klas.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttonEdit11klas.UseVisualStyleBackColor = true;
            this.buttonEdit11klas.Click += new System.EventHandler(this.buttonEdit11klas_Click);
            // 
            // buttonEdit10klas
            // 
            this.buttonEdit10klas.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonEdit10klas.Image = ((System.Drawing.Image)(resources.GetObject("buttonEdit10klas.Image")));
            this.buttonEdit10klas.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonEdit10klas.Location = new System.Drawing.Point(472, 567);
            this.buttonEdit10klas.Name = "buttonEdit10klas";
            this.buttonEdit10klas.Size = new System.Drawing.Size(120, 35);
            this.buttonEdit10klas.TabIndex = 801;
            this.buttonEdit10klas.Text = "Промяна10 клас";
            this.buttonEdit10klas.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttonEdit10klas.UseVisualStyleBackColor = true;
            this.buttonEdit10klas.Click += new System.EventHandler(this.buttonEdit10klas_Click);
            // 
            // buttonEdit9klas
            // 
            this.buttonEdit9klas.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonEdit9klas.Image = ((System.Drawing.Image)(resources.GetObject("buttonEdit9klas.Image")));
            this.buttonEdit9klas.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonEdit9klas.Location = new System.Drawing.Point(275, 567);
            this.buttonEdit9klas.Name = "buttonEdit9klas";
            this.buttonEdit9klas.Size = new System.Drawing.Size(120, 35);
            this.buttonEdit9klas.TabIndex = 801;
            this.buttonEdit9klas.Text = "Промяна 9 клас";
            this.buttonEdit9klas.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttonEdit9klas.UseVisualStyleBackColor = true;
            this.buttonEdit9klas.Click += new System.EventHandler(this.buttonEdit9klas_Click);
            // 
            // buttonFinally
            // 
            this.buttonFinally.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonFinally.Image = ((System.Drawing.Image)(resources.GetObject("buttonFinally.Image")));
            this.buttonFinally.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.buttonFinally.Location = new System.Drawing.Point(1076, 518);
            this.buttonFinally.Name = "buttonFinally";
            this.buttonFinally.Size = new System.Drawing.Size(122, 43);
            this.buttonFinally.TabIndex = 109;
            this.buttonFinally.Text = "Запис окончателни оценки";
            this.buttonFinally.UseVisualStyleBackColor = true;
            this.buttonFinally.Click += new System.EventHandler(this.buttonFinally_Click);
            // 
            // comboBox1Lang
            // 
            this.comboBox1Lang.BackColor = System.Drawing.SystemColors.Control;
            this.comboBox1Lang.FormattingEnabled = true;
            this.comboBox1Lang.Location = new System.Drawing.Point(35, 161);
            this.comboBox1Lang.Margin = new System.Windows.Forms.Padding(0);
            this.comboBox1Lang.Name = "comboBox1Lang";
            this.comboBox1Lang.Size = new System.Drawing.Size(188, 21);
            this.comboBox1Lang.Sorted = true;
            this.comboBox1Lang.TabIndex = 1146;
            this.comboBox1Lang.Text = "Първи чужд език";
            this.comboBox1Lang.SelectedIndexChanged += new System.EventHandler(this.comboBox1Lang_SelectedIndexChanged);
            // 
            // buttonSave12kl
            // 
            this.buttonSave12kl.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonSave12kl.Image = ((System.Drawing.Image)(resources.GetObject("buttonSave12kl.Image")));
            this.buttonSave12kl.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonSave12kl.Location = new System.Drawing.Point(854, 518);
            this.buttonSave12kl.Name = "buttonSave12kl";
            this.buttonSave12kl.Size = new System.Drawing.Size(121, 35);
            this.buttonSave12kl.TabIndex = 100;
            this.buttonSave12kl.Text = "Запис 12 клас";
            this.buttonSave12kl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttonSave12kl.UseVisualStyleBackColor = true;
            this.buttonSave12kl.Click += new System.EventHandler(this.buttonSave12kl_Click);
            // 
            // buttonSave11kl
            // 
            this.buttonSave11kl.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonSave11kl.Image = ((System.Drawing.Image)(resources.GetObject("buttonSave11kl.Image")));
            this.buttonSave11kl.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonSave11kl.Location = new System.Drawing.Point(658, 518);
            this.buttonSave11kl.Name = "buttonSave11kl";
            this.buttonSave11kl.Size = new System.Drawing.Size(120, 35);
            this.buttonSave11kl.TabIndex = 77;
            this.buttonSave11kl.Text = "Запис 11 клас";
            this.buttonSave11kl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttonSave11kl.UseVisualStyleBackColor = true;
            this.buttonSave11kl.Click += new System.EventHandler(this.buttonSave11kl_Click);
            // 
            // buttonSave10kl
            // 
            this.buttonSave10kl.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonSave10kl.Image = ((System.Drawing.Image)(resources.GetObject("buttonSave10kl.Image")));
            this.buttonSave10kl.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonSave10kl.Location = new System.Drawing.Point(472, 522);
            this.buttonSave10kl.Name = "buttonSave10kl";
            this.buttonSave10kl.Size = new System.Drawing.Size(120, 35);
            this.buttonSave10kl.TabIndex = 47;
            this.buttonSave10kl.Text = "Запис 10 клас";
            this.buttonSave10kl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttonSave10kl.UseVisualStyleBackColor = true;
            this.buttonSave10kl.Click += new System.EventHandler(this.buttonSave10kl_Click);
            // 
            // buttonSave9kl
            // 
            this.buttonSave9kl.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonSave9kl.Image = ((System.Drawing.Image)(resources.GetObject("buttonSave9kl.Image")));
            this.buttonSave9kl.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonSave9kl.Location = new System.Drawing.Point(275, 518);
            this.buttonSave9kl.Name = "buttonSave9kl";
            this.buttonSave9kl.Size = new System.Drawing.Size(120, 35);
            this.buttonSave9kl.TabIndex = 19;
            this.buttonSave9kl.Text = "Запис 9 клас";
            this.buttonSave9kl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttonSave9kl.UseVisualStyleBackColor = true;
            this.buttonSave9kl.Click += new System.EventHandler(this.buttonSave9kl_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(140, -62);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(33, 25);
            this.label2.TabIndex = 1144;
            this.label2.Text = "№";
            // 
            // textBoxStuName
            // 
            this.textBoxStuName.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxStuName.Location = new System.Drawing.Point(237, -65);
            this.textBoxStuName.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxStuName.Name = "textBoxStuName";
            this.textBoxStuName.ReadOnly = true;
            this.textBoxStuName.Size = new System.Drawing.Size(390, 31);
            this.textBoxStuName.TabIndex = 1143;
            this.textBoxStuName.TabStop = false;
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox1.Location = new System.Drawing.Point(182, -65);
            this.textBox1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(47, 31);
            this.textBox1.TabIndex = 1142;
            this.textBox1.TabStop = false;
            // 
            // textBox600
            // 
            this.textBox600.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox600.Location = new System.Drawing.Point(35, 28);
            this.textBox600.Margin = new System.Windows.Forms.Padding(0);
            this.textBox600.Multiline = true;
            this.textBox600.Name = "textBox600";
            this.textBox600.Size = new System.Drawing.Size(190, 111);
            this.textBox600.TabIndex = 1080;
            this.textBox600.TabStop = false;
            this.textBox600.Text = "\r\n\r\nУ Ч Е Б Н И   П Р Е Д М Е Т И";
            this.textBox600.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox358
            // 
            this.textBox358.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox358.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox358.Location = new System.Drawing.Point(720, 80);
            this.textBox358.Margin = new System.Windows.Forms.Padding(0);
            this.textBox358.Multiline = true;
            this.textBox358.Name = "textBox358";
            this.textBox358.Size = new System.Drawing.Size(99, 60);
            this.textBox358.TabIndex = 1092;
            this.textBox358.TabStop = false;
            this.textBox358.Text = "ЗИП ";
            this.textBox358.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox407
            // 
            this.textBox407.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox407.Location = new System.Drawing.Point(1017, 28);
            this.textBox407.Margin = new System.Windows.Forms.Padding(0);
            this.textBox407.Multiline = true;
            this.textBox407.Name = "textBox407";
            this.textBox407.Size = new System.Drawing.Size(216, 52);
            this.textBox407.TabIndex = 1099;
            this.textBox407.TabStop = false;
            this.textBox407.Text = "Окончателна\r\nоценка\r\nза дипломата";
            this.textBox407.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox409
            // 
            this.textBox409.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox409.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox409.Location = new System.Drawing.Point(1125, 80);
            this.textBox409.Margin = new System.Windows.Forms.Padding(0);
            this.textBox409.Multiline = true;
            this.textBox409.Name = "textBox409";
            this.textBox409.Size = new System.Drawing.Size(108, 60);
            this.textBox409.TabIndex = 1095;
            this.textBox409.TabStop = false;
            this.textBox409.Text = "ЗИП ";
            this.textBox409.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox278
            // 
            this.textBox278.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox278.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox278.Location = new System.Drawing.Point(918, 80);
            this.textBox278.Margin = new System.Windows.Forms.Padding(0);
            this.textBox278.Multiline = true;
            this.textBox278.Name = "textBox278";
            this.textBox278.Size = new System.Drawing.Size(99, 60);
            this.textBox278.TabIndex = 1096;
            this.textBox278.TabStop = false;
            this.textBox278.Text = "ЗИП ";
            this.textBox278.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox357
            // 
            this.textBox357.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox357.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox357.Location = new System.Drawing.Point(621, 80);
            this.textBox357.Margin = new System.Windows.Forms.Padding(0);
            this.textBox357.Multiline = true;
            this.textBox357.Name = "textBox357";
            this.textBox357.Size = new System.Drawing.Size(99, 60);
            this.textBox357.TabIndex = 1091;
            this.textBox357.TabStop = false;
            this.textBox357.Text = "ЗП или \r\nпрофили-\r\nрана подго-\r\nтовка";
            this.textBox357.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox408
            // 
            this.textBox408.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox408.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox408.Location = new System.Drawing.Point(1017, 80);
            this.textBox408.Margin = new System.Windows.Forms.Padding(0);
            this.textBox408.Multiline = true;
            this.textBox408.Name = "textBox408";
            this.textBox408.Size = new System.Drawing.Size(108, 60);
            this.textBox408.TabIndex = 1094;
            this.textBox408.TabStop = false;
            this.textBox408.Text = "ЗП или \r\nпрофили-\r\nрана подго-\r\nтовка";
            this.textBox408.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox277
            // 
            this.textBox277.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox277.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox277.Location = new System.Drawing.Point(819, 80);
            this.textBox277.Margin = new System.Windows.Forms.Padding(0);
            this.textBox277.Multiline = true;
            this.textBox277.Name = "textBox277";
            this.textBox277.Size = new System.Drawing.Size(99, 60);
            this.textBox277.TabIndex = 1093;
            this.textBox277.TabStop = false;
            this.textBox277.Text = "ЗП или \r\nпрофили-\r\nрана подго-\r\nтовка";
            this.textBox277.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox198
            // 
            this.textBox198.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox198.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox198.Location = new System.Drawing.Point(522, 80);
            this.textBox198.Margin = new System.Windows.Forms.Padding(0);
            this.textBox198.Multiline = true;
            this.textBox198.Name = "textBox198";
            this.textBox198.Size = new System.Drawing.Size(99, 60);
            this.textBox198.TabIndex = 1088;
            this.textBox198.TabStop = false;
            this.textBox198.Text = "ЗИП ";
            this.textBox198.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox525
            // 
            this.textBox525.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox525.Location = new System.Drawing.Point(819, 54);
            this.textBox525.Margin = new System.Windows.Forms.Padding(0);
            this.textBox525.Multiline = true;
            this.textBox525.Name = "textBox525";
            this.textBox525.Size = new System.Drawing.Size(198, 26);
            this.textBox525.TabIndex = 1090;
            this.textBox525.TabStop = false;
            this.textBox525.Text = "XII клас ";
            this.textBox525.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox356
            // 
            this.textBox356.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox356.Location = new System.Drawing.Point(621, 54);
            this.textBox356.Margin = new System.Windows.Forms.Padding(0);
            this.textBox356.Multiline = true;
            this.textBox356.Name = "textBox356";
            this.textBox356.Size = new System.Drawing.Size(198, 26);
            this.textBox356.TabIndex = 1090;
            this.textBox356.TabStop = false;
            this.textBox356.Text = "XI клас ";
            this.textBox356.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox197
            // 
            this.textBox197.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox197.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox197.Location = new System.Drawing.Point(423, 80);
            this.textBox197.Margin = new System.Windows.Forms.Padding(0);
            this.textBox197.Multiline = true;
            this.textBox197.Name = "textBox197";
            this.textBox197.Size = new System.Drawing.Size(99, 60);
            this.textBox197.TabIndex = 1087;
            this.textBox197.TabStop = false;
            this.textBox197.Text = "ЗП или \r\nпрофили-\r\nрана подго-\r\nтовка";
            this.textBox197.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox801
            // 
            this.textBox801.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox801.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox801.Location = new System.Drawing.Point(324, 80);
            this.textBox801.Margin = new System.Windows.Forms.Padding(0);
            this.textBox801.Multiline = true;
            this.textBox801.Name = "textBox801";
            this.textBox801.Size = new System.Drawing.Size(99, 60);
            this.textBox801.TabIndex = 1084;
            this.textBox801.TabStop = false;
            this.textBox801.Text = "ЗИП ";
            this.textBox801.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox196
            // 
            this.textBox196.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox196.Location = new System.Drawing.Point(423, 54);
            this.textBox196.Margin = new System.Windows.Forms.Padding(0);
            this.textBox196.Multiline = true;
            this.textBox196.Name = "textBox196";
            this.textBox196.Size = new System.Drawing.Size(198, 26);
            this.textBox196.TabIndex = 1086;
            this.textBox196.TabStop = false;
            this.textBox196.Text = "X клас ";
            this.textBox196.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox900
            // 
            this.textBox900.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox900.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox900.Location = new System.Drawing.Point(225, 80);
            this.textBox900.Margin = new System.Windows.Forms.Padding(0);
            this.textBox900.Multiline = true;
            this.textBox900.Name = "textBox900";
            this.textBox900.Size = new System.Drawing.Size(99, 60);
            this.textBox900.TabIndex = 1083;
            this.textBox900.TabStop = false;
            this.textBox900.Text = "ЗП или \r\nпрофили-\r\nрана подго-\r\nтовка";
            this.textBox900.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox800
            // 
            this.textBox800.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox800.Location = new System.Drawing.Point(225, 54);
            this.textBox800.Margin = new System.Windows.Forms.Padding(0);
            this.textBox800.Multiline = true;
            this.textBox800.Name = "textBox800";
            this.textBox800.Size = new System.Drawing.Size(198, 26);
            this.textBox800.TabIndex = 1082;
            this.textBox800.TabStop = false;
            this.textBox800.Text = "IX клас ";
            this.textBox800.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxFil
            // 
            this.textBoxFil.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxFil.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxFil.Location = new System.Drawing.Point(35, 349);
            this.textBoxFil.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxFil.Multiline = true;
            this.textBoxFil.Name = "textBoxFil";
            this.textBoxFil.ReadOnly = true;
            this.textBoxFil.Size = new System.Drawing.Size(190, 21);
            this.textBoxFil.TabIndex = 1130;
            this.textBoxFil.TabStop = false;
            this.textBoxFil.Text = "Философия";
            // 
            // textBoxIzIzk
            // 
            this.textBoxIzIzk.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxIzIzk.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxIzIzk.Location = new System.Drawing.Point(35, 473);
            this.textBoxIzIzk.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxIzIzk.Multiline = true;
            this.textBoxIzIzk.Name = "textBoxIzIzk";
            this.textBoxIzIzk.ReadOnly = true;
            this.textBoxIzIzk.Size = new System.Drawing.Size(190, 21);
            this.textBoxIzIzk.TabIndex = 1136;
            this.textBoxIzIzk.TabStop = false;
            this.textBoxIzIzk.Text = "Изобразително изкуство";
            // 
            // textBoxPsi
            // 
            this.textBoxPsi.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxPsi.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxPsi.Location = new System.Drawing.Point(35, 307);
            this.textBoxPsi.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxPsi.Multiline = true;
            this.textBoxPsi.Name = "textBoxPsi";
            this.textBoxPsi.ReadOnly = true;
            this.textBoxPsi.Size = new System.Drawing.Size(190, 21);
            this.textBoxPsi.TabIndex = 1128;
            this.textBoxPsi.TabStop = false;
            this.textBoxPsi.Text = "Психология и логика";
            // 
            // textBoxHim
            // 
            this.textBoxHim.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxHim.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxHim.Location = new System.Drawing.Point(35, 432);
            this.textBoxHim.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxHim.Multiline = true;
            this.textBoxHim.Name = "textBoxHim";
            this.textBoxHim.ReadOnly = true;
            this.textBoxHim.Size = new System.Drawing.Size(190, 21);
            this.textBoxHim.TabIndex = 1134;
            this.textBoxHim.TabStop = false;
            this.textBoxHim.Text = "Химия и ООС";
            // 
            // textBoxIsto
            // 
            this.textBoxIsto.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxIsto.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxIsto.Location = new System.Drawing.Point(35, 266);
            this.textBoxIsto.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxIsto.Multiline = true;
            this.textBoxIsto.Name = "textBoxIsto";
            this.textBoxIsto.ReadOnly = true;
            this.textBoxIsto.Size = new System.Drawing.Size(190, 21);
            this.textBoxIsto.TabIndex = 1126;
            this.textBoxIsto.TabStop = false;
            this.textBoxIsto.Text = "История и цивилизация";
            // 
            // textBoxFVSp
            // 
            this.textBoxFVSp.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxFVSp.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxFVSp.Location = new System.Drawing.Point(35, 494);
            this.textBoxFVSp.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxFVSp.Multiline = true;
            this.textBoxFVSp.Name = "textBoxFVSp";
            this.textBoxFVSp.ReadOnly = true;
            this.textBoxFVSp.Size = new System.Drawing.Size(190, 21);
            this.textBoxFVSp.TabIndex = 1137;
            this.textBoxFVSp.TabStop = false;
            this.textBoxFVSp.Text = "Физическо възпитание и спорт";
            // 
            // textBoxBiol
            // 
            this.textBoxBiol.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxBiol.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxBiol.Location = new System.Drawing.Point(35, 390);
            this.textBoxBiol.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxBiol.Multiline = true;
            this.textBoxBiol.Name = "textBoxBiol";
            this.textBoxBiol.ReadOnly = true;
            this.textBoxBiol.Size = new System.Drawing.Size(190, 21);
            this.textBoxBiol.TabIndex = 1132;
            this.textBoxBiol.TabStop = false;
            this.textBoxBiol.Text = "Биология и ЗО";
            // 
            // textBoxEtika
            // 
            this.textBoxEtika.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxEtika.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxEtika.Location = new System.Drawing.Point(35, 328);
            this.textBoxEtika.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxEtika.Multiline = true;
            this.textBoxEtika.Name = "textBoxEtika";
            this.textBoxEtika.ReadOnly = true;
            this.textBoxEtika.Size = new System.Drawing.Size(190, 21);
            this.textBoxEtika.TabIndex = 1129;
            this.textBoxEtika.TabStop = false;
            this.textBoxEtika.Text = "Етика и право";
            // 
            // textBoxInfor
            // 
            this.textBoxInfor.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxInfor.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxInfor.Location = new System.Drawing.Point(35, 224);
            this.textBoxInfor.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxInfor.Multiline = true;
            this.textBoxInfor.Name = "textBoxInfor";
            this.textBoxInfor.ReadOnly = true;
            this.textBoxInfor.Size = new System.Drawing.Size(190, 21);
            this.textBoxInfor.TabIndex = 1124;
            this.textBoxInfor.TabStop = false;
            this.textBoxInfor.Text = "Информатика";
            // 
            // textBoxFiz
            // 
            this.textBoxFiz.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxFiz.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxFiz.Location = new System.Drawing.Point(35, 411);
            this.textBoxFiz.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxFiz.Multiline = true;
            this.textBoxFiz.Name = "textBoxFiz";
            this.textBoxFiz.ReadOnly = true;
            this.textBoxFiz.Size = new System.Drawing.Size(190, 21);
            this.textBoxFiz.TabIndex = 1133;
            this.textBoxFiz.TabStop = false;
            this.textBoxFiz.Text = "Физика и астрономия";
            // 
            // textBox670
            // 
            this.textBox670.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox670.Location = new System.Drawing.Point(13, 349);
            this.textBox670.Margin = new System.Windows.Forms.Padding(0);
            this.textBox670.Multiline = true;
            this.textBox670.Name = "textBox670";
            this.textBox670.ReadOnly = true;
            this.textBox670.Size = new System.Drawing.Size(22, 21);
            this.textBox670.TabIndex = 1111;
            this.textBox670.TabStop = false;
            this.textBox670.Text = "11.";
            this.textBox670.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxMuz
            // 
            this.textBoxMuz.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxMuz.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxMuz.Location = new System.Drawing.Point(35, 452);
            this.textBoxMuz.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxMuz.Multiline = true;
            this.textBoxMuz.Name = "textBoxMuz";
            this.textBoxMuz.ReadOnly = true;
            this.textBoxMuz.Size = new System.Drawing.Size(190, 21);
            this.textBoxMuz.TabIndex = 1135;
            this.textBoxMuz.TabStop = false;
            this.textBoxMuz.Text = "Музика";
            // 
            // textBoxInfT
            // 
            this.textBoxInfT.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxInfT.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxInfT.Location = new System.Drawing.Point(35, 245);
            this.textBoxInfT.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxInfT.Multiline = true;
            this.textBoxInfT.Name = "textBoxInfT";
            this.textBoxInfT.ReadOnly = true;
            this.textBoxInfT.Size = new System.Drawing.Size(190, 21);
            this.textBoxInfT.TabIndex = 1125;
            this.textBoxInfT.TabStop = false;
            this.textBoxInfT.Text = "Информационни технологии";
            // 
            // textBox674
            // 
            this.textBox674.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox674.Location = new System.Drawing.Point(13, 432);
            this.textBox674.Margin = new System.Windows.Forms.Padding(0);
            this.textBox674.Multiline = true;
            this.textBox674.Name = "textBox674";
            this.textBox674.ReadOnly = true;
            this.textBox674.Size = new System.Drawing.Size(22, 21);
            this.textBox674.TabIndex = 1115;
            this.textBox674.TabStop = false;
            this.textBox674.Text = "15.";
            this.textBox674.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxGeo
            // 
            this.textBoxGeo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxGeo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxGeo.Location = new System.Drawing.Point(35, 286);
            this.textBoxGeo.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxGeo.Multiline = true;
            this.textBoxGeo.Name = "textBoxGeo";
            this.textBoxGeo.ReadOnly = true;
            this.textBoxGeo.Size = new System.Drawing.Size(190, 21);
            this.textBoxGeo.TabIndex = 1127;
            this.textBoxGeo.TabStop = false;
            this.textBoxGeo.Text = "География и икономика";
            // 
            // textBox676
            // 
            this.textBox676.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox676.Location = new System.Drawing.Point(13, 473);
            this.textBox676.Margin = new System.Windows.Forms.Padding(0);
            this.textBox676.Multiline = true;
            this.textBox676.Name = "textBox676";
            this.textBox676.ReadOnly = true;
            this.textBox676.Size = new System.Drawing.Size(22, 21);
            this.textBox676.TabIndex = 1117;
            this.textBox676.TabStop = false;
            this.textBox676.Text = "17.";
            this.textBox676.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox440
            // 
            this.textBox440.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox440.Location = new System.Drawing.Point(13, 266);
            this.textBox440.Margin = new System.Windows.Forms.Padding(0);
            this.textBox440.Multiline = true;
            this.textBox440.Name = "textBox440";
            this.textBox440.ReadOnly = true;
            this.textBox440.Size = new System.Drawing.Size(22, 21);
            this.textBox440.TabIndex = 1107;
            this.textBox440.TabStop = false;
            this.textBox440.Text = "7.";
            this.textBox440.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxSvL
            // 
            this.textBoxSvL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxSvL.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxSvL.Location = new System.Drawing.Point(35, 369);
            this.textBoxSvL.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxSvL.Multiline = true;
            this.textBoxSvL.Name = "textBoxSvL";
            this.textBoxSvL.ReadOnly = true;
            this.textBoxSvL.Size = new System.Drawing.Size(190, 21);
            this.textBoxSvL.TabIndex = 1131;
            this.textBoxSvL.TabStop = false;
            this.textBoxSvL.Text = "Свят и личност";
            // 
            // textBox650
            // 
            this.textBox650.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox650.Location = new System.Drawing.Point(13, 307);
            this.textBox650.Margin = new System.Windows.Forms.Padding(0);
            this.textBox650.Multiline = true;
            this.textBox650.Name = "textBox650";
            this.textBox650.ReadOnly = true;
            this.textBox650.Size = new System.Drawing.Size(22, 21);
            this.textBox650.TabIndex = 1109;
            this.textBox650.TabStop = false;
            this.textBox650.Text = "9.";
            this.textBox650.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox677
            // 
            this.textBox677.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox677.Location = new System.Drawing.Point(13, 494);
            this.textBox677.Margin = new System.Windows.Forms.Padding(0);
            this.textBox677.Multiline = true;
            this.textBox677.Name = "textBox677";
            this.textBox677.ReadOnly = true;
            this.textBox677.Size = new System.Drawing.Size(22, 21);
            this.textBox677.TabIndex = 1118;
            this.textBox677.TabStop = false;
            this.textBox677.Text = "18.";
            this.textBox677.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxMath
            // 
            this.textBoxMath.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxMath.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxMath.Location = new System.Drawing.Point(35, 203);
            this.textBoxMath.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxMath.Multiline = true;
            this.textBoxMath.Name = "textBoxMath";
            this.textBoxMath.ReadOnly = true;
            this.textBoxMath.Size = new System.Drawing.Size(190, 21);
            this.textBoxMath.TabIndex = 1123;
            this.textBoxMath.TabStop = false;
            this.textBoxMath.Text = "Математика";
            // 
            // textBox672
            // 
            this.textBox672.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox672.Location = new System.Drawing.Point(13, 390);
            this.textBox672.Margin = new System.Windows.Forms.Padding(0);
            this.textBox672.Multiline = true;
            this.textBox672.Name = "textBox672";
            this.textBox672.ReadOnly = true;
            this.textBox672.Size = new System.Drawing.Size(22, 21);
            this.textBox672.TabIndex = 1113;
            this.textBox672.TabStop = false;
            this.textBox672.Text = "13.";
            this.textBox672.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox640
            // 
            this.textBox640.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox640.Location = new System.Drawing.Point(13, 328);
            this.textBox640.Margin = new System.Windows.Forms.Padding(0);
            this.textBox640.Multiline = true;
            this.textBox640.Name = "textBox640";
            this.textBox640.ReadOnly = true;
            this.textBox640.Size = new System.Drawing.Size(22, 21);
            this.textBox640.TabIndex = 1110;
            this.textBox640.TabStop = false;
            this.textBox640.Text = "10.";
            this.textBox640.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox673
            // 
            this.textBox673.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox673.Location = new System.Drawing.Point(13, 411);
            this.textBox673.Margin = new System.Windows.Forms.Padding(0);
            this.textBox673.Multiline = true;
            this.textBox673.Name = "textBox673";
            this.textBox673.ReadOnly = true;
            this.textBox673.Size = new System.Drawing.Size(22, 21);
            this.textBox673.TabIndex = 1114;
            this.textBox673.TabStop = false;
            this.textBox673.Text = "14.";
            this.textBox673.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox255
            // 
            this.textBox255.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox255.Location = new System.Drawing.Point(13, 224);
            this.textBox255.Margin = new System.Windows.Forms.Padding(0);
            this.textBox255.Multiline = true;
            this.textBox255.Name = "textBox255";
            this.textBox255.ReadOnly = true;
            this.textBox255.Size = new System.Drawing.Size(22, 21);
            this.textBox255.TabIndex = 1105;
            this.textBox255.TabStop = false;
            this.textBox255.Text = "5.";
            this.textBox255.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox675
            // 
            this.textBox675.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox675.Location = new System.Drawing.Point(13, 452);
            this.textBox675.Margin = new System.Windows.Forms.Padding(0);
            this.textBox675.Multiline = true;
            this.textBox675.Name = "textBox675";
            this.textBox675.ReadOnly = true;
            this.textBox675.Size = new System.Drawing.Size(22, 21);
            this.textBox675.TabIndex = 1116;
            this.textBox675.TabStop = false;
            this.textBox675.Text = "16";
            this.textBox675.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox430
            // 
            this.textBox430.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox430.Location = new System.Drawing.Point(13, 245);
            this.textBox430.Margin = new System.Windows.Forms.Padding(0);
            this.textBox430.Multiline = true;
            this.textBox430.Name = "textBox430";
            this.textBox430.ReadOnly = true;
            this.textBox430.Size = new System.Drawing.Size(22, 21);
            this.textBox430.TabIndex = 1106;
            this.textBox430.TabStop = false;
            this.textBox430.Text = "6.";
            this.textBox430.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox12Year
            // 
            this.textBox12Year.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox12Year.Location = new System.Drawing.Point(819, 28);
            this.textBox12Year.Margin = new System.Windows.Forms.Padding(0);
            this.textBox12Year.Multiline = true;
            this.textBox12Year.Name = "textBox12Year";
            this.textBox12Year.Size = new System.Drawing.Size(198, 26);
            this.textBox12Year.TabIndex = 1089;
            this.textBox12Year.TabStop = false;
            this.textBox12Year.Text = "ххх г. ";
            this.textBox12Year.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox63
            // 
            this.textBox63.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox63.Location = new System.Drawing.Point(13, 286);
            this.textBox63.Margin = new System.Windows.Forms.Padding(0);
            this.textBox63.Multiline = true;
            this.textBox63.Name = "textBox63";
            this.textBox63.ReadOnly = true;
            this.textBox63.Size = new System.Drawing.Size(22, 21);
            this.textBox63.TabIndex = 1108;
            this.textBox63.TabStop = false;
            this.textBox63.Text = "8.";
            this.textBox63.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox11Year
            // 
            this.textBox11Year.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox11Year.Location = new System.Drawing.Point(621, 28);
            this.textBox11Year.Margin = new System.Windows.Forms.Padding(0);
            this.textBox11Year.Multiline = true;
            this.textBox11Year.Name = "textBox11Year";
            this.textBox11Year.Size = new System.Drawing.Size(198, 26);
            this.textBox11Year.TabIndex = 1089;
            this.textBox11Year.TabStop = false;
            this.textBox11Year.Text = "ххх г. ";
            this.textBox11Year.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox671
            // 
            this.textBox671.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox671.Location = new System.Drawing.Point(13, 369);
            this.textBox671.Margin = new System.Windows.Forms.Padding(0);
            this.textBox671.Multiline = true;
            this.textBox671.Name = "textBox671";
            this.textBox671.ReadOnly = true;
            this.textBox671.Size = new System.Drawing.Size(22, 21);
            this.textBox671.TabIndex = 1112;
            this.textBox671.TabStop = false;
            this.textBox671.Text = "12.";
            this.textBox671.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxBel
            // 
            this.textBoxBel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxBel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxBel.Location = new System.Drawing.Point(35, 139);
            this.textBoxBel.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxBel.Multiline = true;
            this.textBoxBel.Name = "textBoxBel";
            this.textBoxBel.ReadOnly = true;
            this.textBoxBel.Size = new System.Drawing.Size(190, 21);
            this.textBoxBel.TabIndex = 1120;
            this.textBoxBel.TabStop = false;
            this.textBoxBel.Text = "Български език и литература";
            // 
            // textBox10Year
            // 
            this.textBox10Year.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox10Year.Location = new System.Drawing.Point(423, 28);
            this.textBox10Year.Margin = new System.Windows.Forms.Padding(0);
            this.textBox10Year.Multiline = true;
            this.textBox10Year.Name = "textBox10Year";
            this.textBox10Year.Size = new System.Drawing.Size(198, 26);
            this.textBox10Year.TabIndex = 1085;
            this.textBox10Year.TabStop = false;
            this.textBox10Year.Text = "ххх г. ";
            this.textBox10Year.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox250
            // 
            this.textBox250.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox250.Location = new System.Drawing.Point(13, 203);
            this.textBox250.Margin = new System.Windows.Forms.Padding(0);
            this.textBox250.Multiline = true;
            this.textBox250.Name = "textBox250";
            this.textBox250.ReadOnly = true;
            this.textBox250.Size = new System.Drawing.Size(22, 21);
            this.textBox250.TabIndex = 1104;
            this.textBox250.TabStop = false;
            this.textBox250.Text = "4.";
            this.textBox250.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox11ZIP11
            // 
            this.textBox11ZIP11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox11ZIP11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox11ZIP11.Enabled = false;
            this.textBox11ZIP11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox11ZIP11.Location = new System.Drawing.Point(798, 348);
            this.textBox11ZIP11.Margin = new System.Windows.Forms.Padding(0);
            this.textBox11ZIP11.Name = "textBox11ZIP11";
            this.textBox11ZIP11.Size = new System.Drawing.Size(21, 21);
            this.textBox11ZIP11.TabIndex = 806;
            this.textBox11ZIP11.TabStop = false;
            this.textBox11ZIP11.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox11ZIP11.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBoxdipZIP11
            // 
            this.textBoxdipZIP11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBoxdipZIP11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxdipZIP11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxdipZIP11.Location = new System.Drawing.Point(1203, 348);
            this.textBoxdipZIP11.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxdipZIP11.Name = "textBoxdipZIP11";
            this.textBoxdipZIP11.ReadOnly = true;
            this.textBoxdipZIP11.Size = new System.Drawing.Size(30, 21);
            this.textBoxdipZIP11.TabIndex = 140;
            this.textBoxdipZIP11.TabStop = false;
            this.textBoxdipZIP11.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBoxdipZIP11.TextChanged += new System.EventHandler(this.textBoxdipZIP11_TextChanged);
            this.textBoxdipZIP11.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox9Year
            // 
            this.textBox9Year.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox9Year.Location = new System.Drawing.Point(225, 28);
            this.textBox9Year.Margin = new System.Windows.Forms.Padding(0);
            this.textBox9Year.Multiline = true;
            this.textBox9Year.Name = "textBox9Year";
            this.textBox9Year.Size = new System.Drawing.Size(198, 26);
            this.textBox9Year.TabIndex = 1081;
            this.textBox9Year.TabStop = false;
            this.textBox9Year.Text = "ххх г. ";
            this.textBox9Year.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox12ZIP11
            // 
            this.textBox12ZIP11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox12ZIP11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox12ZIP11.Enabled = false;
            this.textBox12ZIP11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox12ZIP11.Location = new System.Drawing.Point(996, 348);
            this.textBox12ZIP11.Margin = new System.Windows.Forms.Padding(0);
            this.textBox12ZIP11.Name = "textBox12ZIP11";
            this.textBox12ZIP11.Size = new System.Drawing.Size(21, 21);
            this.textBox12ZIP11.TabIndex = 873;
            this.textBox12ZIP11.TabStop = false;
            this.textBox12ZIP11.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox12ZIP11.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox11ZIP15
            // 
            this.textBox11ZIP15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox11ZIP15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox11ZIP15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox11ZIP15.Location = new System.Drawing.Point(798, 431);
            this.textBox11ZIP15.Margin = new System.Windows.Forms.Padding(0);
            this.textBox11ZIP15.Name = "textBox11ZIP15";
            this.textBox11ZIP15.Size = new System.Drawing.Size(21, 21);
            this.textBox11ZIP15.TabIndex = 87;
            this.textBox11ZIP15.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox11ZIP15.TextChanged += new System.EventHandler(this.textBox11ZIP15_TextChanged);
            this.textBox11ZIP15.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBoxdipZIP15
            // 
            this.textBoxdipZIP15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBoxdipZIP15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxdipZIP15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxdipZIP15.Location = new System.Drawing.Point(1203, 431);
            this.textBoxdipZIP15.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxdipZIP15.Name = "textBoxdipZIP15";
            this.textBoxdipZIP15.ReadOnly = true;
            this.textBoxdipZIP15.Size = new System.Drawing.Size(30, 21);
            this.textBoxdipZIP15.TabIndex = 144;
            this.textBoxdipZIP15.TabStop = false;
            this.textBoxdipZIP15.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBoxdipZIP15.TextChanged += new System.EventHandler(this.textBoxdipZIP15_TextChanged);
            this.textBoxdipZIP15.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox10ZIP11
            // 
            this.textBox10ZIP11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox10ZIP11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox10ZIP11.Enabled = false;
            this.textBox10ZIP11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox10ZIP11.Location = new System.Drawing.Point(600, 349);
            this.textBox10ZIP11.Margin = new System.Windows.Forms.Padding(0);
            this.textBox10ZIP11.Name = "textBox10ZIP11";
            this.textBox10ZIP11.Size = new System.Drawing.Size(21, 21);
            this.textBox10ZIP11.TabIndex = 768;
            this.textBox10ZIP11.TabStop = false;
            this.textBox10ZIP11.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox10ZIP11.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox12ZIP15
            // 
            this.textBox12ZIP15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox12ZIP15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox12ZIP15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox12ZIP15.Location = new System.Drawing.Point(996, 431);
            this.textBox12ZIP15.Margin = new System.Windows.Forms.Padding(0);
            this.textBox12ZIP15.Name = "textBox12ZIP15";
            this.textBox12ZIP15.Size = new System.Drawing.Size(21, 21);
            this.textBox12ZIP15.TabIndex = 110;
            this.textBox12ZIP15.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox12ZIP15.TextChanged += new System.EventHandler(this.textBox12ZIP15_TextChanged);
            this.textBox12ZIP15.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox320
            // 
            this.textBox320.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox320.Location = new System.Drawing.Point(13, 182);
            this.textBox320.Margin = new System.Windows.Forms.Padding(0);
            this.textBox320.Multiline = true;
            this.textBox320.Name = "textBox320";
            this.textBox320.ReadOnly = true;
            this.textBox320.Size = new System.Drawing.Size(22, 21);
            this.textBox320.TabIndex = 1103;
            this.textBox320.TabStop = false;
            this.textBox320.Text = "3.";
            this.textBox320.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox10ZIP15
            // 
            this.textBox10ZIP15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox10ZIP15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox10ZIP15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox10ZIP15.Location = new System.Drawing.Point(600, 432);
            this.textBox10ZIP15.Margin = new System.Windows.Forms.Padding(0);
            this.textBox10ZIP15.Name = "textBox10ZIP15";
            this.textBox10ZIP15.Size = new System.Drawing.Size(21, 21);
            this.textBox10ZIP15.TabIndex = 62;
            this.textBox10ZIP15.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox10ZIP15.TextChanged += new System.EventHandler(this.textBox10ZIP15_TextChanged);
            this.textBox10ZIP15.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox11ZIP17
            // 
            this.textBox11ZIP17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox11ZIP17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox11ZIP17.Enabled = false;
            this.textBox11ZIP17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox11ZIP17.Location = new System.Drawing.Point(798, 472);
            this.textBox11ZIP17.Margin = new System.Windows.Forms.Padding(0);
            this.textBox11ZIP17.Name = "textBox11ZIP17";
            this.textBox11ZIP17.Size = new System.Drawing.Size(21, 21);
            this.textBox11ZIP17.TabIndex = 812;
            this.textBox11ZIP17.TabStop = false;
            this.textBox11ZIP17.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox11ZIP17.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBoxdipZIP17
            // 
            this.textBoxdipZIP17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBoxdipZIP17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxdipZIP17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxdipZIP17.Location = new System.Drawing.Point(1203, 472);
            this.textBoxdipZIP17.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxdipZIP17.Name = "textBoxdipZIP17";
            this.textBoxdipZIP17.ReadOnly = true;
            this.textBoxdipZIP17.Size = new System.Drawing.Size(30, 21);
            this.textBoxdipZIP17.TabIndex = 146;
            this.textBoxdipZIP17.TabStop = false;
            this.textBoxdipZIP17.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBoxdipZIP17.TextChanged += new System.EventHandler(this.textBoxdipZIP17_TextChanged);
            this.textBoxdipZIP17.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox9ZIP11
            // 
            this.textBox9ZIP11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox9ZIP11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox9ZIP11.Enabled = false;
            this.textBox9ZIP11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox9ZIP11.Location = new System.Drawing.Point(402, 349);
            this.textBox9ZIP11.Margin = new System.Windows.Forms.Padding(0);
            this.textBox9ZIP11.Name = "textBox9ZIP11";
            this.textBox9ZIP11.Size = new System.Drawing.Size(21, 21);
            this.textBox9ZIP11.TabIndex = 730;
            this.textBox9ZIP11.TabStop = false;
            this.textBox9ZIP11.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox9ZIP11.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox12ZIP17
            // 
            this.textBox12ZIP17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox12ZIP17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox12ZIP17.Enabled = false;
            this.textBox12ZIP17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox12ZIP17.Location = new System.Drawing.Point(996, 472);
            this.textBox12ZIP17.Margin = new System.Windows.Forms.Padding(0);
            this.textBox12ZIP17.Name = "textBox12ZIP17";
            this.textBox12ZIP17.Size = new System.Drawing.Size(21, 21);
            this.textBox12ZIP17.TabIndex = 886;
            this.textBox12ZIP17.TabStop = false;
            this.textBox12ZIP17.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox12ZIP17.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox9ZIP15
            // 
            this.textBox9ZIP15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox9ZIP15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox9ZIP15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox9ZIP15.Location = new System.Drawing.Point(402, 432);
            this.textBox9ZIP15.Margin = new System.Windows.Forms.Padding(0);
            this.textBox9ZIP15.Name = "textBox9ZIP15";
            this.textBox9ZIP15.Size = new System.Drawing.Size(21, 21);
            this.textBox9ZIP15.TabIndex = 29;
            this.textBox9ZIP15.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox9ZIP15.TextChanged += new System.EventHandler(this.textBox9ZIP15_TextChanged);
            this.textBox9ZIP15.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox11ZIP7
            // 
            this.textBox11ZIP7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox11ZIP7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox11ZIP7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox11ZIP7.Location = new System.Drawing.Point(798, 265);
            this.textBox11ZIP7.Margin = new System.Windows.Forms.Padding(0);
            this.textBox11ZIP7.Name = "textBox11ZIP7";
            this.textBox11ZIP7.Size = new System.Drawing.Size(21, 21);
            this.textBox11ZIP7.TabIndex = 83;
            this.textBox11ZIP7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox11ZIP7.TextChanged += new System.EventHandler(this.textBox11ZIP7_TextChanged);
            this.textBox11ZIP7.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBoxdipZIP7
            // 
            this.textBoxdipZIP7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBoxdipZIP7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxdipZIP7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxdipZIP7.Location = new System.Drawing.Point(1203, 265);
            this.textBoxdipZIP7.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxdipZIP7.Name = "textBoxdipZIP7";
            this.textBoxdipZIP7.ReadOnly = true;
            this.textBoxdipZIP7.Size = new System.Drawing.Size(30, 21);
            this.textBoxdipZIP7.TabIndex = 136;
            this.textBoxdipZIP7.TabStop = false;
            this.textBoxdipZIP7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBoxdipZIP7.TextChanged += new System.EventHandler(this.textBoxdipZIP7_TextChanged);
            this.textBoxdipZIP7.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox10ZIP17
            // 
            this.textBox10ZIP17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox10ZIP17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox10ZIP17.Enabled = false;
            this.textBox10ZIP17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox10ZIP17.Location = new System.Drawing.Point(600, 473);
            this.textBox10ZIP17.Margin = new System.Windows.Forms.Padding(0);
            this.textBox10ZIP17.Name = "textBox10ZIP17";
            this.textBox10ZIP17.Size = new System.Drawing.Size(21, 21);
            this.textBox10ZIP17.TabIndex = 774;
            this.textBox10ZIP17.TabStop = false;
            this.textBox10ZIP17.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox10ZIP17.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox12ZIP7
            // 
            this.textBox12ZIP7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox12ZIP7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox12ZIP7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox12ZIP7.Location = new System.Drawing.Point(996, 265);
            this.textBox12ZIP7.Margin = new System.Windows.Forms.Padding(0);
            this.textBox12ZIP7.Name = "textBox12ZIP7";
            this.textBox12ZIP7.Size = new System.Drawing.Size(21, 21);
            this.textBox12ZIP7.TabIndex = 107;
            this.textBox12ZIP7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox12ZIP7.TextChanged += new System.EventHandler(this.textBox12ZIP7_TextChanged);
            this.textBox12ZIP7.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox270
            // 
            this.textBox270.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox270.Location = new System.Drawing.Point(13, 160);
            this.textBox270.Margin = new System.Windows.Forms.Padding(0);
            this.textBox270.Multiline = true;
            this.textBox270.Name = "textBox270";
            this.textBox270.ReadOnly = true;
            this.textBox270.Size = new System.Drawing.Size(22, 21);
            this.textBox270.TabIndex = 1100;
            this.textBox270.TabStop = false;
            this.textBox270.Text = "2.";
            this.textBox270.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox11ZIP9
            // 
            this.textBox11ZIP9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox11ZIP9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox11ZIP9.Enabled = false;
            this.textBox11ZIP9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox11ZIP9.Location = new System.Drawing.Point(798, 306);
            this.textBox11ZIP9.Margin = new System.Windows.Forms.Padding(0);
            this.textBox11ZIP9.Name = "textBox11ZIP9";
            this.textBox11ZIP9.Size = new System.Drawing.Size(21, 21);
            this.textBox11ZIP9.TabIndex = 804;
            this.textBox11ZIP9.TabStop = false;
            this.textBox11ZIP9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox11ZIP9.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBoxdipZIP9
            // 
            this.textBoxdipZIP9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBoxdipZIP9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxdipZIP9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxdipZIP9.Location = new System.Drawing.Point(1203, 306);
            this.textBoxdipZIP9.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxdipZIP9.Name = "textBoxdipZIP9";
            this.textBoxdipZIP9.ReadOnly = true;
            this.textBoxdipZIP9.Size = new System.Drawing.Size(30, 21);
            this.textBoxdipZIP9.TabIndex = 138;
            this.textBoxdipZIP9.TabStop = false;
            this.textBoxdipZIP9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBoxdipZIP9.TextChanged += new System.EventHandler(this.textBoxdipZIP9_TextChanged);
            this.textBoxdipZIP9.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox10ZIP7
            // 
            this.textBox10ZIP7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox10ZIP7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox10ZIP7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox10ZIP7.Location = new System.Drawing.Point(600, 266);
            this.textBox10ZIP7.Margin = new System.Windows.Forms.Padding(0);
            this.textBox10ZIP7.Name = "textBox10ZIP7";
            this.textBox10ZIP7.Size = new System.Drawing.Size(21, 21);
            this.textBox10ZIP7.TabIndex = 58;
            this.textBox10ZIP7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox10ZIP7.TextChanged += new System.EventHandler(this.textBox10ZIP7_TextChanged);
            this.textBox10ZIP7.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox12ZIP9
            // 
            this.textBox12ZIP9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox12ZIP9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox12ZIP9.Enabled = false;
            this.textBox12ZIP9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox12ZIP9.Location = new System.Drawing.Point(996, 306);
            this.textBox12ZIP9.Margin = new System.Windows.Forms.Padding(0);
            this.textBox12ZIP9.Name = "textBox12ZIP9";
            this.textBox12ZIP9.Size = new System.Drawing.Size(21, 21);
            this.textBox12ZIP9.TabIndex = 869;
            this.textBox12ZIP9.TabStop = false;
            this.textBox12ZIP9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox12ZIP9.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox9ZIP17
            // 
            this.textBox9ZIP17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox9ZIP17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox9ZIP17.Enabled = false;
            this.textBox9ZIP17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox9ZIP17.Location = new System.Drawing.Point(402, 473);
            this.textBox9ZIP17.Margin = new System.Windows.Forms.Padding(0);
            this.textBox9ZIP17.Name = "textBox9ZIP17";
            this.textBox9ZIP17.Size = new System.Drawing.Size(21, 21);
            this.textBox9ZIP17.TabIndex = 310;
            this.textBox9ZIP17.TabStop = false;
            this.textBox9ZIP17.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox9ZIP17.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox10ZIP9
            // 
            this.textBox10ZIP9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox10ZIP9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox10ZIP9.Enabled = false;
            this.textBox10ZIP9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox10ZIP9.Location = new System.Drawing.Point(600, 307);
            this.textBox10ZIP9.Margin = new System.Windows.Forms.Padding(0);
            this.textBox10ZIP9.Name = "textBox10ZIP9";
            this.textBox10ZIP9.Size = new System.Drawing.Size(21, 21);
            this.textBox10ZIP9.TabIndex = 766;
            this.textBox10ZIP9.TabStop = false;
            this.textBox10ZIP9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox10ZIP9.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox9ZIP7
            // 
            this.textBox9ZIP7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox9ZIP7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox9ZIP7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox9ZIP7.Location = new System.Drawing.Point(402, 266);
            this.textBox9ZIP7.Margin = new System.Windows.Forms.Padding(0);
            this.textBox9ZIP7.Name = "textBox9ZIP7";
            this.textBox9ZIP7.Size = new System.Drawing.Size(21, 21);
            this.textBox9ZIP7.TabIndex = 25;
            this.textBox9ZIP7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox9ZIP7.TextChanged += new System.EventHandler(this.textBox9ZIP7_TextChanged);
            this.textBox9ZIP7.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox11ZIP13
            // 
            this.textBox11ZIP13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox11ZIP13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox11ZIP13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox11ZIP13.Location = new System.Drawing.Point(798, 389);
            this.textBox11ZIP13.Margin = new System.Windows.Forms.Padding(0);
            this.textBox11ZIP13.Name = "textBox11ZIP13";
            this.textBox11ZIP13.Size = new System.Drawing.Size(21, 21);
            this.textBox11ZIP13.TabIndex = 85;
            this.textBox11ZIP13.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox11ZIP13.TextChanged += new System.EventHandler(this.textBox11ZIP13_TextChanged);
            this.textBox11ZIP13.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBoxdipZIP13
            // 
            this.textBoxdipZIP13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBoxdipZIP13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxdipZIP13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxdipZIP13.Location = new System.Drawing.Point(1203, 389);
            this.textBoxdipZIP13.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxdipZIP13.Name = "textBoxdipZIP13";
            this.textBoxdipZIP13.ReadOnly = true;
            this.textBoxdipZIP13.Size = new System.Drawing.Size(30, 21);
            this.textBoxdipZIP13.TabIndex = 142;
            this.textBoxdipZIP13.TabStop = false;
            this.textBoxdipZIP13.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBoxdipZIP13.TextChanged += new System.EventHandler(this.textBoxdipZIP13_TextChanged);
            this.textBoxdipZIP13.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox9ZIP9
            // 
            this.textBox9ZIP9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox9ZIP9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox9ZIP9.Enabled = false;
            this.textBox9ZIP9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox9ZIP9.Location = new System.Drawing.Point(402, 307);
            this.textBox9ZIP9.Margin = new System.Windows.Forms.Padding(0);
            this.textBox9ZIP9.Name = "textBox9ZIP9";
            this.textBox9ZIP9.Size = new System.Drawing.Size(21, 21);
            this.textBox9ZIP9.TabIndex = 250;
            this.textBox9ZIP9.TabStop = false;
            this.textBox9ZIP9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox9ZIP9.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox12ZIP13
            // 
            this.textBox12ZIP13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox12ZIP13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox12ZIP13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox12ZIP13.Location = new System.Drawing.Point(996, 389);
            this.textBox12ZIP13.Margin = new System.Windows.Forms.Padding(0);
            this.textBox12ZIP13.Name = "textBox12ZIP13";
            this.textBox12ZIP13.Size = new System.Drawing.Size(21, 21);
            this.textBox12ZIP13.TabIndex = 108;
            this.textBox12ZIP13.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox12ZIP13.TextChanged += new System.EventHandler(this.textBox12ZIP13_TextChanged);
            this.textBox12ZIP13.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox11ZP11
            // 
            this.textBox11ZP11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox11ZP11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox11ZP11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox11ZP11.Location = new System.Drawing.Point(699, 348);
            this.textBox11ZP11.Margin = new System.Windows.Forms.Padding(0);
            this.textBox11ZP11.Name = "textBox11ZP11";
            this.textBox11ZP11.Size = new System.Drawing.Size(21, 21);
            this.textBox11ZP11.TabIndex = 72;
            this.textBox11ZP11.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox11ZP11.TextChanged += new System.EventHandler(this.textBox11ZP11_TextChanged);
            this.textBox11ZP11.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBoxdipZP11
            // 
            this.textBoxdipZP11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBoxdipZP11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxdipZP11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxdipZP11.Location = new System.Drawing.Point(1095, 348);
            this.textBoxdipZP11.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxdipZP11.Name = "textBoxdipZP11";
            this.textBoxdipZP11.ReadOnly = true;
            this.textBoxdipZP11.Size = new System.Drawing.Size(30, 21);
            this.textBoxdipZP11.TabIndex = 121;
            this.textBoxdipZP11.TabStop = false;
            this.textBoxdipZP11.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBoxdipZP11.TextChanged += new System.EventHandler(this.textBoxdipZP11_TextChanged);
            this.textBoxdipZP11.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox10ZIP13
            // 
            this.textBox10ZIP13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox10ZIP13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox10ZIP13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox10ZIP13.Location = new System.Drawing.Point(600, 390);
            this.textBox10ZIP13.Margin = new System.Windows.Forms.Padding(0);
            this.textBox10ZIP13.Name = "textBox10ZIP13";
            this.textBox10ZIP13.Size = new System.Drawing.Size(21, 21);
            this.textBox10ZIP13.TabIndex = 60;
            this.textBox10ZIP13.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox10ZIP13.TextChanged += new System.EventHandler(this.textBox10ZIP13_TextChanged);
            this.textBox10ZIP13.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox12ZP11
            // 
            this.textBox12ZP11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox12ZP11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox12ZP11.Enabled = false;
            this.textBox12ZP11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox12ZP11.Location = new System.Drawing.Point(897, 348);
            this.textBox12ZP11.Margin = new System.Windows.Forms.Padding(0);
            this.textBox12ZP11.Name = "textBox12ZP11";
            this.textBox12ZP11.Size = new System.Drawing.Size(21, 21);
            this.textBox12ZP11.TabIndex = 835;
            this.textBox12ZP11.TabStop = false;
            this.textBox12ZP11.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox12ZP11.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox230
            // 
            this.textBox230.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox230.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox230.Location = new System.Drawing.Point(13, 139);
            this.textBox230.Margin = new System.Windows.Forms.Padding(0);
            this.textBox230.Multiline = true;
            this.textBox230.Name = "textBox230";
            this.textBox230.ReadOnly = true;
            this.textBox230.Size = new System.Drawing.Size(22, 21);
            this.textBox230.TabIndex = 1098;
            this.textBox230.TabStop = false;
            this.textBox230.Text = "1.";
            this.textBox230.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox11ZP15
            // 
            this.textBox11ZP15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox11ZP15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox11ZP15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox11ZP15.Location = new System.Drawing.Point(699, 431);
            this.textBox11ZP15.Margin = new System.Windows.Forms.Padding(0);
            this.textBox11ZP15.Name = "textBox11ZP15";
            this.textBox11ZP15.Size = new System.Drawing.Size(21, 21);
            this.textBox11ZP15.TabIndex = 75;
            this.textBox11ZP15.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox11ZP15.TextChanged += new System.EventHandler(this.textBox11ZP15_TextChanged);
            this.textBox11ZP15.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBoxdipZP15
            // 
            this.textBoxdipZP15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBoxdipZP15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxdipZP15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxdipZP15.Location = new System.Drawing.Point(1095, 431);
            this.textBoxdipZP15.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxdipZP15.Name = "textBoxdipZP15";
            this.textBoxdipZP15.ReadOnly = true;
            this.textBoxdipZP15.Size = new System.Drawing.Size(30, 21);
            this.textBoxdipZP15.TabIndex = 125;
            this.textBoxdipZP15.TabStop = false;
            this.textBoxdipZP15.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBoxdipZP15.TextChanged += new System.EventHandler(this.textBoxdipZP15_TextChanged);
            this.textBoxdipZP15.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox10ZP11
            // 
            this.textBox10ZP11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox10ZP11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox10ZP11.Enabled = false;
            this.textBox10ZP11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox10ZP11.Location = new System.Drawing.Point(501, 349);
            this.textBox10ZP11.Margin = new System.Windows.Forms.Padding(0);
            this.textBox10ZP11.Name = "textBox10ZP11";
            this.textBox10ZP11.ReadOnly = true;
            this.textBox10ZP11.Size = new System.Drawing.Size(21, 21);
            this.textBox10ZP11.TabIndex = 440;
            this.textBox10ZP11.TabStop = false;
            this.textBox10ZP11.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox10ZP11.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox12ZP15
            // 
            this.textBox12ZP15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox12ZP15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox12ZP15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox12ZP15.Location = new System.Drawing.Point(897, 431);
            this.textBox12ZP15.Margin = new System.Windows.Forms.Padding(0);
            this.textBox12ZP15.Name = "textBox12ZP15";
            this.textBox12ZP15.Size = new System.Drawing.Size(21, 21);
            this.textBox12ZP15.TabIndex = 98;
            this.textBox12ZP15.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox12ZP15.TextChanged += new System.EventHandler(this.textBox12ZP15_TextChanged);
            this.textBox12ZP15.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox9ZIP13
            // 
            this.textBox9ZIP13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox9ZIP13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox9ZIP13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox9ZIP13.Location = new System.Drawing.Point(402, 390);
            this.textBox9ZIP13.Margin = new System.Windows.Forms.Padding(0);
            this.textBox9ZIP13.Name = "textBox9ZIP13";
            this.textBox9ZIP13.Size = new System.Drawing.Size(21, 21);
            this.textBox9ZIP13.TabIndex = 27;
            this.textBox9ZIP13.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox9ZIP13.TextChanged += new System.EventHandler(this.textBox9ZIP13_TextChanged);
            this.textBox9ZIP13.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox11ZIP5
            // 
            this.textBox11ZIP5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox11ZIP5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox11ZIP5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox11ZIP5.Location = new System.Drawing.Point(798, 223);
            this.textBox11ZIP5.Margin = new System.Windows.Forms.Padding(0);
            this.textBox11ZIP5.Name = "textBox11ZIP5";
            this.textBox11ZIP5.Size = new System.Drawing.Size(21, 21);
            this.textBox11ZIP5.TabIndex = 81;
            this.textBox11ZIP5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox11ZIP5.TextChanged += new System.EventHandler(this.textBox11ZIP5_TextChanged);
            this.textBox11ZIP5.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBoxdipZIP5
            // 
            this.textBoxdipZIP5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBoxdipZIP5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxdipZIP5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxdipZIP5.Location = new System.Drawing.Point(1203, 223);
            this.textBoxdipZIP5.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxdipZIP5.Name = "textBoxdipZIP5";
            this.textBoxdipZIP5.ReadOnly = true;
            this.textBoxdipZIP5.Size = new System.Drawing.Size(30, 21);
            this.textBoxdipZIP5.TabIndex = 134;
            this.textBoxdipZIP5.TabStop = false;
            this.textBoxdipZIP5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBoxdipZIP5.TextChanged += new System.EventHandler(this.textBoxdipZIP5_TextChanged);
            this.textBoxdipZIP5.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox10ZP15
            // 
            this.textBox10ZP15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox10ZP15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox10ZP15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox10ZP15.Location = new System.Drawing.Point(501, 432);
            this.textBox10ZP15.Margin = new System.Windows.Forms.Padding(0);
            this.textBox10ZP15.Name = "textBox10ZP15";
            this.textBox10ZP15.Size = new System.Drawing.Size(21, 21);
            this.textBox10ZP15.TabIndex = 45;
            this.textBox10ZP15.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox10ZP15.TextChanged += new System.EventHandler(this.textBox10ZP15_TextChanged);
            this.textBox10ZP15.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox12ZIP5
            // 
            this.textBox12ZIP5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox12ZIP5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox12ZIP5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox12ZIP5.Location = new System.Drawing.Point(996, 223);
            this.textBox12ZIP5.Margin = new System.Windows.Forms.Padding(0);
            this.textBox12ZIP5.Name = "textBox12ZIP5";
            this.textBox12ZIP5.Size = new System.Drawing.Size(21, 21);
            this.textBox12ZIP5.TabIndex = 105;
            this.textBox12ZIP5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox12ZIP5.TextChanged += new System.EventHandler(this.textBox12ZIP5_TextChanged);
            this.textBox12ZIP5.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox9ZP11
            // 
            this.textBox9ZP11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox9ZP11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox9ZP11.Enabled = false;
            this.textBox9ZP11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox9ZP11.Location = new System.Drawing.Point(303, 349);
            this.textBox9ZP11.Margin = new System.Windows.Forms.Padding(0);
            this.textBox9ZP11.Name = "textBox9ZP11";
            this.textBox9ZP11.Size = new System.Drawing.Size(21, 21);
            this.textBox9ZP11.TabIndex = 911;
            this.textBox9ZP11.TabStop = false;
            this.textBox9ZP11.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox9ZP11.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox11ZIP18
            // 
            this.textBox11ZIP18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox11ZIP18.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox11ZIP18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox11ZIP18.Location = new System.Drawing.Point(798, 493);
            this.textBox11ZIP18.Margin = new System.Windows.Forms.Padding(0);
            this.textBox11ZIP18.Name = "textBox11ZIP18";
            this.textBox11ZIP18.Size = new System.Drawing.Size(21, 21);
            this.textBox11ZIP18.TabIndex = 880;
            this.textBox11ZIP18.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox11ZIP18.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBoxSumOcZIP
            // 
            this.textBoxSumOcZIP.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBoxSumOcZIP.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxSumOcZIP.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxSumOcZIP.Location = new System.Drawing.Point(893, 674);
            this.textBoxSumOcZIP.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxSumOcZIP.Name = "textBoxSumOcZIP";
            this.textBoxSumOcZIP.ReadOnly = true;
            this.textBoxSumOcZIP.Size = new System.Drawing.Size(74, 21);
            this.textBoxSumOcZIP.TabIndex = 147;
            this.textBoxSumOcZIP.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBoxSumOcZIP.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox1300
            // 
            this.textBox1300.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox1300.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox1300.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox1300.Location = new System.Drawing.Point(893, 639);
            this.textBox1300.Margin = new System.Windows.Forms.Padding(0);
            this.textBox1300.Multiline = true;
            this.textBox1300.Name = "textBox1300";
            this.textBox1300.Size = new System.Drawing.Size(74, 35);
            this.textBox1300.TabIndex = 147;
            this.textBox1300.Text = "Сума оценки ЗИП";
            this.textBox1300.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox1300.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBoxdipZIP18
            // 
            this.textBoxdipZIP18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBoxdipZIP18.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxdipZIP18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxdipZIP18.Location = new System.Drawing.Point(1203, 493);
            this.textBoxdipZIP18.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxdipZIP18.Name = "textBoxdipZIP18";
            this.textBoxdipZIP18.ReadOnly = true;
            this.textBoxdipZIP18.Size = new System.Drawing.Size(30, 21);
            this.textBoxdipZIP18.TabIndex = 147;
            this.textBoxdipZIP18.TabStop = false;
            this.textBoxdipZIP18.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBoxdipZIP18.TextChanged += new System.EventHandler(this.textBoxdipZIP18_TextChanged);
            this.textBoxdipZIP18.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox10ZIP5
            // 
            this.textBox10ZIP5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox10ZIP5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox10ZIP5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox10ZIP5.Location = new System.Drawing.Point(600, 224);
            this.textBox10ZIP5.Margin = new System.Windows.Forms.Padding(0);
            this.textBox10ZIP5.Name = "textBox10ZIP5";
            this.textBox10ZIP5.Size = new System.Drawing.Size(21, 21);
            this.textBox10ZIP5.TabIndex = 56;
            this.textBox10ZIP5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox10ZIP5.TextChanged += new System.EventHandler(this.textBox10ZIP5_TextChanged);
            this.textBox10ZIP5.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox12ZIP18
            // 
            this.textBox12ZIP18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox12ZIP18.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox12ZIP18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox12ZIP18.Location = new System.Drawing.Point(996, 493);
            this.textBox12ZIP18.Margin = new System.Windows.Forms.Padding(0);
            this.textBox12ZIP18.Name = "textBox12ZIP18";
            this.textBox12ZIP18.Size = new System.Drawing.Size(21, 21);
            this.textBox12ZIP18.TabIndex = 887;
            this.textBox12ZIP18.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox12ZIP18.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox9ZP15
            // 
            this.textBox9ZP15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox9ZP15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox9ZP15.Enabled = false;
            this.textBox9ZP15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox9ZP15.Location = new System.Drawing.Point(303, 432);
            this.textBox9ZP15.Margin = new System.Windows.Forms.Padding(0);
            this.textBox9ZP15.Name = "textBox9ZP15";
            this.textBox9ZP15.Size = new System.Drawing.Size(21, 21);
            this.textBox9ZP15.TabIndex = 915;
            this.textBox9ZP15.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox9ZP15.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox11ZP7
            // 
            this.textBox11ZP7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox11ZP7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox11ZP7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox11ZP7.Location = new System.Drawing.Point(699, 265);
            this.textBox11ZP7.Margin = new System.Windows.Forms.Padding(0);
            this.textBox11ZP7.Name = "textBox11ZP7";
            this.textBox11ZP7.Size = new System.Drawing.Size(21, 21);
            this.textBox11ZP7.TabIndex = 70;
            this.textBox11ZP7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox11ZP7.TextChanged += new System.EventHandler(this.textBox11ZP7_TextChanged);
            this.textBox11ZP7.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBoxdipZP7
            // 
            this.textBoxdipZP7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBoxdipZP7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxdipZP7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxdipZP7.Location = new System.Drawing.Point(1095, 265);
            this.textBoxdipZP7.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxdipZP7.Name = "textBoxdipZP7";
            this.textBoxdipZP7.ReadOnly = true;
            this.textBoxdipZP7.Size = new System.Drawing.Size(30, 21);
            this.textBoxdipZP7.TabIndex = 117;
            this.textBoxdipZP7.TabStop = false;
            this.textBoxdipZP7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBoxdipZP7.TextChanged += new System.EventHandler(this.textBoxdipZP7_TextChanged);
            this.textBoxdipZP7.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox10ZIP18
            // 
            this.textBox10ZIP18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox10ZIP18.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox10ZIP18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox10ZIP18.Location = new System.Drawing.Point(600, 494);
            this.textBox10ZIP18.Margin = new System.Windows.Forms.Padding(0);
            this.textBox10ZIP18.Name = "textBox10ZIP18";
            this.textBox10ZIP18.Size = new System.Drawing.Size(21, 21);
            this.textBox10ZIP18.TabIndex = 630;
            this.textBox10ZIP18.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox10ZIP18.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox12ZP7
            // 
            this.textBox12ZP7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox12ZP7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox12ZP7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox12ZP7.Location = new System.Drawing.Point(897, 265);
            this.textBox12ZP7.Margin = new System.Windows.Forms.Padding(0);
            this.textBox12ZP7.Name = "textBox12ZP7";
            this.textBox12ZP7.Size = new System.Drawing.Size(21, 21);
            this.textBox12ZP7.TabIndex = 93;
            this.textBox12ZP7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox12ZP7.TextChanged += new System.EventHandler(this.textBox12ZP7_TextChanged);
            this.textBox12ZP7.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox9ZIP5
            // 
            this.textBox9ZIP5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox9ZIP5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox9ZIP5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox9ZIP5.Location = new System.Drawing.Point(402, 224);
            this.textBox9ZIP5.Margin = new System.Windows.Forms.Padding(0);
            this.textBox9ZIP5.Name = "textBox9ZIP5";
            this.textBox9ZIP5.Size = new System.Drawing.Size(21, 21);
            this.textBox9ZIP5.TabIndex = 24;
            this.textBox9ZIP5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox9ZIP5.TextChanged += new System.EventHandler(this.textBox9ZIP5_TextChanged);
            this.textBox9ZIP5.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox11ZIP10
            // 
            this.textBox11ZIP10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox11ZIP10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox11ZIP10.Enabled = false;
            this.textBox11ZIP10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox11ZIP10.Location = new System.Drawing.Point(798, 327);
            this.textBox11ZIP10.Margin = new System.Windows.Forms.Padding(0);
            this.textBox11ZIP10.Name = "textBox11ZIP10";
            this.textBox11ZIP10.Size = new System.Drawing.Size(21, 21);
            this.textBox11ZIP10.TabIndex = 805;
            this.textBox11ZIP10.TabStop = false;
            this.textBox11ZIP10.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox11ZIP10.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBoxdipZIP10
            // 
            this.textBoxdipZIP10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBoxdipZIP10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxdipZIP10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxdipZIP10.Location = new System.Drawing.Point(1203, 327);
            this.textBoxdipZIP10.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxdipZIP10.Name = "textBoxdipZIP10";
            this.textBoxdipZIP10.ReadOnly = true;
            this.textBoxdipZIP10.Size = new System.Drawing.Size(30, 21);
            this.textBoxdipZIP10.TabIndex = 139;
            this.textBoxdipZIP10.TabStop = false;
            this.textBoxdipZIP10.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBoxdipZIP10.TextChanged += new System.EventHandler(this.textBoxdipZIP10_TextChanged);
            this.textBoxdipZIP10.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox10ZP7
            // 
            this.textBox10ZP7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox10ZP7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox10ZP7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox10ZP7.Location = new System.Drawing.Point(501, 266);
            this.textBox10ZP7.Margin = new System.Windows.Forms.Padding(0);
            this.textBox10ZP7.Name = "textBox10ZP7";
            this.textBox10ZP7.Size = new System.Drawing.Size(21, 21);
            this.textBox10ZP7.TabIndex = 40;
            this.textBox10ZP7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox10ZP7.TextChanged += new System.EventHandler(this.textBox10ZP7_TextChanged);
            this.textBox10ZP7.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox12ZIP10
            // 
            this.textBox12ZIP10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox12ZIP10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox12ZIP10.Enabled = false;
            this.textBox12ZIP10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox12ZIP10.Location = new System.Drawing.Point(996, 327);
            this.textBox12ZIP10.Margin = new System.Windows.Forms.Padding(0);
            this.textBox12ZIP10.Name = "textBox12ZIP10";
            this.textBox12ZIP10.Size = new System.Drawing.Size(21, 21);
            this.textBox12ZIP10.TabIndex = 871;
            this.textBox12ZIP10.TabStop = false;
            this.textBox12ZIP10.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox12ZIP10.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox9ZIP18
            // 
            this.textBox9ZIP18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox9ZIP18.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox9ZIP18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox9ZIP18.Location = new System.Drawing.Point(402, 494);
            this.textBox9ZIP18.Margin = new System.Windows.Forms.Padding(0);
            this.textBox9ZIP18.Name = "textBox9ZIP18";
            this.textBox9ZIP18.ReadOnly = true;
            this.textBox9ZIP18.Size = new System.Drawing.Size(21, 21);
            this.textBox9ZIP18.TabIndex = 326;
            this.textBox9ZIP18.TabStop = false;
            this.textBox9ZIP18.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox9ZIP18.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox11ZP17
            // 
            this.textBox11ZP17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox11ZP17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox11ZP17.Enabled = false;
            this.textBox11ZP17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox11ZP17.Location = new System.Drawing.Point(699, 472);
            this.textBox11ZP17.Margin = new System.Windows.Forms.Padding(0);
            this.textBox11ZP17.Name = "textBox11ZP17";
            this.textBox11ZP17.Size = new System.Drawing.Size(21, 21);
            this.textBox11ZP17.TabIndex = 793;
            this.textBox11ZP17.TabStop = false;
            this.textBox11ZP17.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox11ZP17.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBoxdipZP17
            // 
            this.textBoxdipZP17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBoxdipZP17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxdipZP17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxdipZP17.Location = new System.Drawing.Point(1095, 472);
            this.textBoxdipZP17.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxdipZP17.Name = "textBoxdipZP17";
            this.textBoxdipZP17.ReadOnly = true;
            this.textBoxdipZP17.Size = new System.Drawing.Size(30, 21);
            this.textBoxdipZP17.TabIndex = 127;
            this.textBoxdipZP17.TabStop = false;
            this.textBoxdipZP17.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBoxdipZP17.TextChanged += new System.EventHandler(this.textBoxdipZP17_TextChanged);
            this.textBoxdipZP17.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox10ZIP10
            // 
            this.textBox10ZIP10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox10ZIP10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox10ZIP10.Enabled = false;
            this.textBox10ZIP10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox10ZIP10.Location = new System.Drawing.Point(600, 328);
            this.textBox10ZIP10.Margin = new System.Windows.Forms.Padding(0);
            this.textBox10ZIP10.Name = "textBox10ZIP10";
            this.textBox10ZIP10.Size = new System.Drawing.Size(21, 21);
            this.textBox10ZIP10.TabIndex = 600;
            this.textBox10ZIP10.TabStop = false;
            this.textBox10ZIP10.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox10ZIP10.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox12ZP17
            // 
            this.textBox12ZP17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox12ZP17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox12ZP17.Enabled = false;
            this.textBox12ZP17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox12ZP17.Location = new System.Drawing.Point(897, 472);
            this.textBox12ZP17.Margin = new System.Windows.Forms.Padding(0);
            this.textBox12ZP17.Name = "textBox12ZP17";
            this.textBox12ZP17.Size = new System.Drawing.Size(21, 21);
            this.textBox12ZP17.TabIndex = 848;
            this.textBox12ZP17.TabStop = false;
            this.textBox12ZP17.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox12ZP17.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox9ZP7
            // 
            this.textBox9ZP7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox9ZP7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox9ZP7.Enabled = false;
            this.textBox9ZP7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox9ZP7.Location = new System.Drawing.Point(303, 266);
            this.textBox9ZP7.Margin = new System.Windows.Forms.Padding(0);
            this.textBox9ZP7.Name = "textBox9ZP7";
            this.textBox9ZP7.Size = new System.Drawing.Size(21, 21);
            this.textBox9ZP7.TabIndex = 600;
            this.textBox9ZP7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox9ZP7.TextChanged += new System.EventHandler(this.textBox9ZP7_TextChanged);
            this.textBox9ZP7.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox10ZP17
            // 
            this.textBox10ZP17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox10ZP17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox10ZP17.Enabled = false;
            this.textBox10ZP17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox10ZP17.Location = new System.Drawing.Point(501, 473);
            this.textBox10ZP17.Margin = new System.Windows.Forms.Padding(0);
            this.textBox10ZP17.Name = "textBox10ZP17";
            this.textBox10ZP17.Size = new System.Drawing.Size(21, 21);
            this.textBox10ZP17.TabIndex = 470;
            this.textBox10ZP17.TabStop = false;
            this.textBox10ZP17.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox10ZP17.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox11ZIP14
            // 
            this.textBox11ZIP14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox11ZIP14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox11ZIP14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox11ZIP14.Location = new System.Drawing.Point(798, 410);
            this.textBox11ZIP14.Margin = new System.Windows.Forms.Padding(0);
            this.textBox11ZIP14.Name = "textBox11ZIP14";
            this.textBox11ZIP14.Size = new System.Drawing.Size(21, 21);
            this.textBox11ZIP14.TabIndex = 86;
            this.textBox11ZIP14.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox11ZIP14.TextChanged += new System.EventHandler(this.textBox11ZIP14_TextChanged);
            this.textBox11ZIP14.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBoxdipZIP14
            // 
            this.textBoxdipZIP14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBoxdipZIP14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxdipZIP14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxdipZIP14.Location = new System.Drawing.Point(1203, 410);
            this.textBoxdipZIP14.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxdipZIP14.Name = "textBoxdipZIP14";
            this.textBoxdipZIP14.ReadOnly = true;
            this.textBoxdipZIP14.Size = new System.Drawing.Size(30, 21);
            this.textBoxdipZIP14.TabIndex = 142;
            this.textBoxdipZIP14.TabStop = false;
            this.textBoxdipZIP14.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBoxdipZIP14.TextChanged += new System.EventHandler(this.textBoxdipZIP14_TextChanged);
            this.textBoxdipZIP14.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox9ZIP10
            // 
            this.textBox9ZIP10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox9ZIP10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox9ZIP10.Enabled = false;
            this.textBox9ZIP10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox9ZIP10.Location = new System.Drawing.Point(402, 328);
            this.textBox9ZIP10.Margin = new System.Windows.Forms.Padding(0);
            this.textBox9ZIP10.Name = "textBox9ZIP10";
            this.textBox9ZIP10.Size = new System.Drawing.Size(21, 21);
            this.textBox9ZIP10.TabIndex = 255;
            this.textBox9ZIP10.TabStop = false;
            this.textBox9ZIP10.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox9ZIP10.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox12ZIP14
            // 
            this.textBox12ZIP14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox12ZIP14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox12ZIP14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox12ZIP14.Location = new System.Drawing.Point(996, 410);
            this.textBox12ZIP14.Margin = new System.Windows.Forms.Padding(0);
            this.textBox12ZIP14.Name = "textBox12ZIP14";
            this.textBox12ZIP14.Size = new System.Drawing.Size(21, 21);
            this.textBox12ZIP14.TabIndex = 109;
            this.textBox12ZIP14.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox12ZIP14.TextChanged += new System.EventHandler(this.textBox12ZIP14_TextChanged);
            this.textBox12ZIP14.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox9ZP17
            // 
            this.textBox9ZP17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox9ZP17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox9ZP17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox9ZP17.Location = new System.Drawing.Point(303, 473);
            this.textBox9ZP17.Margin = new System.Windows.Forms.Padding(0);
            this.textBox9ZP17.Name = "textBox9ZP17";
            this.textBox9ZP17.Size = new System.Drawing.Size(21, 21);
            this.textBox9ZP17.TabIndex = 17;
            this.textBox9ZP17.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox9ZP17.TextChanged += new System.EventHandler(this.textBox9ZP17_TextChanged);
            this.textBox9ZP17.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox11ZP9
            // 
            this.textBox11ZP9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox11ZP9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox11ZP9.Enabled = false;
            this.textBox11ZP9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox11ZP9.Location = new System.Drawing.Point(699, 306);
            this.textBox11ZP9.Margin = new System.Windows.Forms.Padding(0);
            this.textBox11ZP9.Name = "textBox11ZP9";
            this.textBox11ZP9.Size = new System.Drawing.Size(21, 21);
            this.textBox11ZP9.TabIndex = 785;
            this.textBox11ZP9.TabStop = false;
            this.textBox11ZP9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox11ZP9.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBoxdipZP9
            // 
            this.textBoxdipZP9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBoxdipZP9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxdipZP9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxdipZP9.Location = new System.Drawing.Point(1095, 306);
            this.textBoxdipZP9.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxdipZP9.Name = "textBoxdipZP9";
            this.textBoxdipZP9.ReadOnly = true;
            this.textBoxdipZP9.Size = new System.Drawing.Size(30, 21);
            this.textBoxdipZP9.TabIndex = 119;
            this.textBoxdipZP9.TabStop = false;
            this.textBoxdipZP9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBoxdipZP9.TextChanged += new System.EventHandler(this.textBoxdipZP9_TextChanged);
            this.textBoxdipZP9.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox10ZIP14
            // 
            this.textBox10ZIP14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox10ZIP14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox10ZIP14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox10ZIP14.Location = new System.Drawing.Point(600, 411);
            this.textBox10ZIP14.Margin = new System.Windows.Forms.Padding(0);
            this.textBox10ZIP14.Name = "textBox10ZIP14";
            this.textBox10ZIP14.Size = new System.Drawing.Size(21, 21);
            this.textBox10ZIP14.TabIndex = 61;
            this.textBox10ZIP14.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox10ZIP14.TextChanged += new System.EventHandler(this.textBox10ZIP14_TextChanged);
            this.textBox10ZIP14.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox12ZP9
            // 
            this.textBox12ZP9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox12ZP9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox12ZP9.Enabled = false;
            this.textBox12ZP9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox12ZP9.Location = new System.Drawing.Point(897, 306);
            this.textBox12ZP9.Margin = new System.Windows.Forms.Padding(0);
            this.textBox12ZP9.Name = "textBox12ZP9";
            this.textBox12ZP9.Size = new System.Drawing.Size(21, 21);
            this.textBox12ZP9.TabIndex = 832;
            this.textBox12ZP9.TabStop = false;
            this.textBox12ZP9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox12ZP9.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox500
            // 
            this.textBox500.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox500.Location = new System.Drawing.Point(13, 28);
            this.textBox500.Margin = new System.Windows.Forms.Padding(0);
            this.textBox500.Multiline = true;
            this.textBox500.Name = "textBox500";
            this.textBox500.Size = new System.Drawing.Size(22, 111);
            this.textBox500.TabIndex = 1079;
            this.textBox500.TabStop = false;
            this.textBox500.Text = "\r\n\r\n№";
            this.textBox500.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox11ZP18
            // 
            this.textBox11ZP18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox11ZP18.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox11ZP18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox11ZP18.Location = new System.Drawing.Point(699, 493);
            this.textBox11ZP18.Margin = new System.Windows.Forms.Padding(0);
            this.textBox11ZP18.Name = "textBox11ZP18";
            this.textBox11ZP18.Size = new System.Drawing.Size(21, 21);
            this.textBox11ZP18.TabIndex = 76;
            this.textBox11ZP18.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox11ZP18.TextChanged += new System.EventHandler(this.textBox11ZP18_TextChanged);
            this.textBox11ZP18.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBoxSrZP
            // 
            this.textBoxSrZP.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBoxSrZP.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxSrZP.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxSrZP.Location = new System.Drawing.Point(742, 674);
            this.textBoxSrZP.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxSrZP.Name = "textBoxSrZP";
            this.textBoxSrZP.ReadOnly = true;
            this.textBoxSrZP.Size = new System.Drawing.Size(56, 21);
            this.textBoxSrZP.TabIndex = 128;
            this.textBoxSrZP.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBoxSrZP.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBoxdipZP18
            // 
            this.textBoxdipZP18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBoxdipZP18.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxdipZP18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxdipZP18.Location = new System.Drawing.Point(1095, 493);
            this.textBoxdipZP18.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxdipZP18.Name = "textBoxdipZP18";
            this.textBoxdipZP18.ReadOnly = true;
            this.textBoxdipZP18.Size = new System.Drawing.Size(30, 21);
            this.textBoxdipZP18.TabIndex = 128;
            this.textBoxdipZP18.TabStop = false;
            this.textBoxdipZP18.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBoxdipZP18.TextChanged += new System.EventHandler(this.textBoxdipZP18_TextChanged);
            this.textBoxdipZP18.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox10ZP9
            // 
            this.textBox10ZP9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox10ZP9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox10ZP9.Enabled = false;
            this.textBox10ZP9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox10ZP9.Location = new System.Drawing.Point(501, 307);
            this.textBox10ZP9.Margin = new System.Windows.Forms.Padding(0);
            this.textBox10ZP9.Name = "textBox10ZP9";
            this.textBox10ZP9.Size = new System.Drawing.Size(21, 21);
            this.textBox10ZP9.TabIndex = 420;
            this.textBox10ZP9.TabStop = false;
            this.textBox10ZP9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox10ZP9.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox12ZP18
            // 
            this.textBox12ZP18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox12ZP18.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox12ZP18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox12ZP18.Location = new System.Drawing.Point(897, 493);
            this.textBox12ZP18.Margin = new System.Windows.Forms.Padding(0);
            this.textBox12ZP18.Name = "textBox12ZP18";
            this.textBox12ZP18.Size = new System.Drawing.Size(21, 21);
            this.textBox12ZP18.TabIndex = 99;
            this.textBox12ZP18.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox12ZP18.TextChanged += new System.EventHandler(this.textBox12ZP18_TextChanged);
            this.textBox12ZP18.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox9ZIP14
            // 
            this.textBox9ZIP14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox9ZIP14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox9ZIP14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox9ZIP14.Location = new System.Drawing.Point(402, 411);
            this.textBox9ZIP14.Margin = new System.Windows.Forms.Padding(0);
            this.textBox9ZIP14.Name = "textBox9ZIP14";
            this.textBox9ZIP14.Size = new System.Drawing.Size(21, 21);
            this.textBox9ZIP14.TabIndex = 28;
            this.textBox9ZIP14.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox9ZIP14.TextChanged += new System.EventHandler(this.textBox9ZIP14_TextChanged);
            this.textBox9ZIP14.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox11ZIP6
            // 
            this.textBox11ZIP6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox11ZIP6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox11ZIP6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox11ZIP6.Location = new System.Drawing.Point(798, 244);
            this.textBox11ZIP6.Margin = new System.Windows.Forms.Padding(0);
            this.textBox11ZIP6.Name = "textBox11ZIP6";
            this.textBox11ZIP6.Size = new System.Drawing.Size(21, 21);
            this.textBox11ZIP6.TabIndex = 82;
            this.textBox11ZIP6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox11ZIP6.TextChanged += new System.EventHandler(this.textBox11ZIP6_TextChanged);
            this.textBox11ZIP6.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBoxdipZIP6
            // 
            this.textBoxdipZIP6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBoxdipZIP6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxdipZIP6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxdipZIP6.Location = new System.Drawing.Point(1203, 244);
            this.textBoxdipZIP6.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxdipZIP6.Name = "textBoxdipZIP6";
            this.textBoxdipZIP6.ReadOnly = true;
            this.textBoxdipZIP6.Size = new System.Drawing.Size(30, 21);
            this.textBoxdipZIP6.TabIndex = 135;
            this.textBoxdipZIP6.TabStop = false;
            this.textBoxdipZIP6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBoxdipZIP6.TextChanged += new System.EventHandler(this.textBoxdipZIP6_TextChanged);
            this.textBoxdipZIP6.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox10ZP18
            // 
            this.textBox10ZP18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox10ZP18.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox10ZP18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox10ZP18.Location = new System.Drawing.Point(501, 494);
            this.textBox10ZP18.Margin = new System.Windows.Forms.Padding(0);
            this.textBox10ZP18.Name = "textBox10ZP18";
            this.textBox10ZP18.Size = new System.Drawing.Size(21, 21);
            this.textBox10ZP18.TabIndex = 46;
            this.textBox10ZP18.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox10ZP18.TextChanged += new System.EventHandler(this.textBox10ZP18_TextChanged);
            this.textBox10ZP18.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox12ZIP6
            // 
            this.textBox12ZIP6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox12ZIP6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox12ZIP6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox12ZIP6.Location = new System.Drawing.Point(996, 244);
            this.textBox12ZIP6.Margin = new System.Windows.Forms.Padding(0);
            this.textBox12ZIP6.Name = "textBox12ZIP6";
            this.textBox12ZIP6.Size = new System.Drawing.Size(21, 21);
            this.textBox12ZIP6.TabIndex = 106;
            this.textBox12ZIP6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox12ZIP6.TextChanged += new System.EventHandler(this.textBox12ZIP6_TextChanged);
            this.textBox12ZIP6.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox9ZP9
            // 
            this.textBox9ZP9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox9ZP9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox9ZP9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox9ZP9.Location = new System.Drawing.Point(303, 307);
            this.textBox9ZP9.Margin = new System.Windows.Forms.Padding(0);
            this.textBox9ZP9.Name = "textBox9ZP9";
            this.textBox9ZP9.Size = new System.Drawing.Size(21, 21);
            this.textBox9ZP9.TabIndex = 8;
            this.textBox9ZP9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox9ZP9.TextChanged += new System.EventHandler(this.textBox9ZP9_TextChanged);
            this.textBox9ZP9.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox11ZP13
            // 
            this.textBox11ZP13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox11ZP13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox11ZP13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox11ZP13.Location = new System.Drawing.Point(699, 389);
            this.textBox11ZP13.Margin = new System.Windows.Forms.Padding(0);
            this.textBox11ZP13.Name = "textBox11ZP13";
            this.textBox11ZP13.Size = new System.Drawing.Size(21, 21);
            this.textBox11ZP13.TabIndex = 73;
            this.textBox11ZP13.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox11ZP13.TextChanged += new System.EventHandler(this.textBox11ZP13_TextChanged);
            this.textBox11ZP13.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBoxdipZP13
            // 
            this.textBoxdipZP13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBoxdipZP13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxdipZP13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxdipZP13.Location = new System.Drawing.Point(1095, 389);
            this.textBoxdipZP13.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxdipZP13.Name = "textBoxdipZP13";
            this.textBoxdipZP13.ReadOnly = true;
            this.textBoxdipZP13.Size = new System.Drawing.Size(30, 21);
            this.textBoxdipZP13.TabIndex = 123;
            this.textBoxdipZP13.TabStop = false;
            this.textBoxdipZP13.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBoxdipZP13.TextChanged += new System.EventHandler(this.textBoxdipZP13_TextChanged);
            this.textBoxdipZP13.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox10ZIP6
            // 
            this.textBox10ZIP6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox10ZIP6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox10ZIP6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox10ZIP6.Location = new System.Drawing.Point(600, 245);
            this.textBox10ZIP6.Margin = new System.Windows.Forms.Padding(0);
            this.textBox10ZIP6.Name = "textBox10ZIP6";
            this.textBox10ZIP6.Size = new System.Drawing.Size(21, 21);
            this.textBox10ZIP6.TabIndex = 57;
            this.textBox10ZIP6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox10ZIP6.TextChanged += new System.EventHandler(this.textBox10ZIP6_TextChanged);
            this.textBox10ZIP6.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox12ZP13
            // 
            this.textBox12ZP13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox12ZP13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox12ZP13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox12ZP13.Location = new System.Drawing.Point(897, 389);
            this.textBox12ZP13.Margin = new System.Windows.Forms.Padding(0);
            this.textBox12ZP13.Name = "textBox12ZP13";
            this.textBox12ZP13.Size = new System.Drawing.Size(21, 21);
            this.textBox12ZP13.TabIndex = 96;
            this.textBox12ZP13.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox12ZP13.TextChanged += new System.EventHandler(this.textBox12ZP13_TextChanged);
            this.textBox12ZP13.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox9ZP18
            // 
            this.textBox9ZP18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox9ZP18.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox9ZP18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox9ZP18.Location = new System.Drawing.Point(303, 494);
            this.textBox9ZP18.Margin = new System.Windows.Forms.Padding(0);
            this.textBox9ZP18.Name = "textBox9ZP18";
            this.textBox9ZP18.Size = new System.Drawing.Size(21, 21);
            this.textBox9ZP18.TabIndex = 18;
            this.textBox9ZP18.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox9ZP18.TextChanged += new System.EventHandler(this.textBox9ZP18_TextChanged);
            this.textBox9ZP18.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox11ZP10
            // 
            this.textBox11ZP10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox11ZP10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox11ZP10.Enabled = false;
            this.textBox11ZP10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox11ZP10.Location = new System.Drawing.Point(699, 327);
            this.textBox11ZP10.Margin = new System.Windows.Forms.Padding(0);
            this.textBox11ZP10.Name = "textBox11ZP10";
            this.textBox11ZP10.Size = new System.Drawing.Size(21, 21);
            this.textBox11ZP10.TabIndex = 786;
            this.textBox11ZP10.TabStop = false;
            this.textBox11ZP10.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox11ZP10.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBoxdipZP10
            // 
            this.textBoxdipZP10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBoxdipZP10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxdipZP10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxdipZP10.Location = new System.Drawing.Point(1095, 327);
            this.textBoxdipZP10.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxdipZP10.Name = "textBoxdipZP10";
            this.textBoxdipZP10.ReadOnly = true;
            this.textBoxdipZP10.Size = new System.Drawing.Size(30, 21);
            this.textBoxdipZP10.TabIndex = 120;
            this.textBoxdipZP10.TabStop = false;
            this.textBoxdipZP10.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBoxdipZP10.TextChanged += new System.EventHandler(this.textBoxdipZP10_TextChanged);
            this.textBoxdipZP10.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox10ZP13
            // 
            this.textBox10ZP13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox10ZP13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox10ZP13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox10ZP13.Location = new System.Drawing.Point(501, 390);
            this.textBox10ZP13.Margin = new System.Windows.Forms.Padding(0);
            this.textBox10ZP13.Name = "textBox10ZP13";
            this.textBox10ZP13.Size = new System.Drawing.Size(21, 21);
            this.textBox10ZP13.TabIndex = 43;
            this.textBox10ZP13.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox10ZP13.TextChanged += new System.EventHandler(this.textBox10ZP13_TextChanged);
            this.textBox10ZP13.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox12ZP10
            // 
            this.textBox12ZP10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox12ZP10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox12ZP10.Enabled = false;
            this.textBox12ZP10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox12ZP10.Location = new System.Drawing.Point(897, 327);
            this.textBox12ZP10.Margin = new System.Windows.Forms.Padding(0);
            this.textBox12ZP10.Name = "textBox12ZP10";
            this.textBox12ZP10.Size = new System.Drawing.Size(21, 21);
            this.textBox12ZP10.TabIndex = 834;
            this.textBox12ZP10.TabStop = false;
            this.textBox12ZP10.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox12ZP10.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox9ZIP6
            // 
            this.textBox9ZIP6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox9ZIP6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox9ZIP6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox9ZIP6.Location = new System.Drawing.Point(402, 245);
            this.textBox9ZIP6.Margin = new System.Windows.Forms.Padding(0);
            this.textBox9ZIP6.Name = "textBox9ZIP6";
            this.textBox9ZIP6.Size = new System.Drawing.Size(21, 21);
            this.textBox9ZIP6.TabIndex = 25;
            this.textBox9ZIP6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox9ZIP6.TextChanged += new System.EventHandler(this.textBox9ZIP6_TextChanged);
            this.textBox9ZIP6.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox11ZIP16
            // 
            this.textBox11ZIP16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox11ZIP16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox11ZIP16.Enabled = false;
            this.textBox11ZIP16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox11ZIP16.Location = new System.Drawing.Point(798, 451);
            this.textBox11ZIP16.Margin = new System.Windows.Forms.Padding(0);
            this.textBox11ZIP16.Name = "textBox11ZIP16";
            this.textBox11ZIP16.Size = new System.Drawing.Size(21, 21);
            this.textBox11ZIP16.TabIndex = 811;
            this.textBox11ZIP16.TabStop = false;
            this.textBox11ZIP16.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox11ZIP16.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBoxdipZIP16
            // 
            this.textBoxdipZIP16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBoxdipZIP16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxdipZIP16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxdipZIP16.Location = new System.Drawing.Point(1203, 451);
            this.textBoxdipZIP16.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxdipZIP16.Name = "textBoxdipZIP16";
            this.textBoxdipZIP16.ReadOnly = true;
            this.textBoxdipZIP16.Size = new System.Drawing.Size(30, 21);
            this.textBoxdipZIP16.TabIndex = 145;
            this.textBoxdipZIP16.TabStop = false;
            this.textBoxdipZIP16.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBoxdipZIP16.TextChanged += new System.EventHandler(this.textBoxdipZIP16_TextChanged);
            this.textBoxdipZIP16.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox10ZP10
            // 
            this.textBox10ZP10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox10ZP10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox10ZP10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox10ZP10.Location = new System.Drawing.Point(501, 328);
            this.textBox10ZP10.Margin = new System.Windows.Forms.Padding(0);
            this.textBox10ZP10.Name = "textBox10ZP10";
            this.textBox10ZP10.Size = new System.Drawing.Size(21, 21);
            this.textBox10ZP10.TabIndex = 42;
            this.textBox10ZP10.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox10ZP10.TextChanged += new System.EventHandler(this.textBox10ZP10_TextChanged);
            this.textBox10ZP10.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox12ZIP16
            // 
            this.textBox12ZIP16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox12ZIP16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox12ZIP16.Enabled = false;
            this.textBox12ZIP16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox12ZIP16.Location = new System.Drawing.Point(996, 451);
            this.textBox12ZIP16.Margin = new System.Windows.Forms.Padding(0);
            this.textBox12ZIP16.Name = "textBox12ZIP16";
            this.textBox12ZIP16.Size = new System.Drawing.Size(21, 21);
            this.textBox12ZIP16.TabIndex = 883;
            this.textBox12ZIP16.TabStop = false;
            this.textBox12ZIP16.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox12ZIP16.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox9ZP13
            // 
            this.textBox9ZP13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox9ZP13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox9ZP13.Enabled = false;
            this.textBox9ZP13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox9ZP13.Location = new System.Drawing.Point(303, 390);
            this.textBox9ZP13.Margin = new System.Windows.Forms.Padding(0);
            this.textBox9ZP13.Name = "textBox9ZP13";
            this.textBox9ZP13.Size = new System.Drawing.Size(21, 21);
            this.textBox9ZP13.TabIndex = 913;
            this.textBox9ZP13.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox9ZP13.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox11ZP5
            // 
            this.textBox11ZP5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox11ZP5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox11ZP5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox11ZP5.Location = new System.Drawing.Point(699, 223);
            this.textBox11ZP5.Margin = new System.Windows.Forms.Padding(0);
            this.textBox11ZP5.Name = "textBox11ZP5";
            this.textBox11ZP5.Size = new System.Drawing.Size(21, 21);
            this.textBox11ZP5.TabIndex = 68;
            this.textBox11ZP5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox11ZP5.TextChanged += new System.EventHandler(this.textBox11ZP5_TextChanged);
            this.textBox11ZP5.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBoxdipZP5
            // 
            this.textBoxdipZP5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBoxdipZP5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxdipZP5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxdipZP5.Location = new System.Drawing.Point(1095, 223);
            this.textBoxdipZP5.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxdipZP5.Name = "textBoxdipZP5";
            this.textBoxdipZP5.ReadOnly = true;
            this.textBoxdipZP5.Size = new System.Drawing.Size(30, 21);
            this.textBoxdipZP5.TabIndex = 115;
            this.textBoxdipZP5.TabStop = false;
            this.textBoxdipZP5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBoxdipZP5.TextChanged += new System.EventHandler(this.textBoxdipZP5_TextChanged);
            this.textBoxdipZP5.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox10ZIP16
            // 
            this.textBox10ZIP16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox10ZIP16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox10ZIP16.Enabled = false;
            this.textBox10ZIP16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox10ZIP16.Location = new System.Drawing.Point(600, 452);
            this.textBox10ZIP16.Margin = new System.Windows.Forms.Padding(0);
            this.textBox10ZIP16.Name = "textBox10ZIP16";
            this.textBox10ZIP16.Size = new System.Drawing.Size(21, 21);
            this.textBox10ZIP16.TabIndex = 773;
            this.textBox10ZIP16.TabStop = false;
            this.textBox10ZIP16.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox10ZIP16.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox12ZP5
            // 
            this.textBox12ZP5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox12ZP5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox12ZP5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox12ZP5.Location = new System.Drawing.Point(897, 223);
            this.textBox12ZP5.Margin = new System.Windows.Forms.Padding(0);
            this.textBox12ZP5.Name = "textBox12ZP5";
            this.textBox12ZP5.Size = new System.Drawing.Size(21, 21);
            this.textBox12ZP5.TabIndex = 91;
            this.textBox12ZP5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox12ZP5.TextChanged += new System.EventHandler(this.textBox12ZP5_TextChanged);
            this.textBox12ZP5.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox9ZP10
            // 
            this.textBox9ZP10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox9ZP10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox9ZP10.Enabled = false;
            this.textBox9ZP10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox9ZP10.Location = new System.Drawing.Point(303, 328);
            this.textBox9ZP10.Margin = new System.Windows.Forms.Padding(0);
            this.textBox9ZP10.Name = "textBox9ZP10";
            this.textBox9ZP10.Size = new System.Drawing.Size(21, 21);
            this.textBox9ZP10.TabIndex = 900;
            this.textBox9ZP10.TabStop = false;
            this.textBox9ZP10.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox9ZP10.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox11ZP14
            // 
            this.textBox11ZP14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox11ZP14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox11ZP14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox11ZP14.Location = new System.Drawing.Point(699, 410);
            this.textBox11ZP14.Margin = new System.Windows.Forms.Padding(0);
            this.textBox11ZP14.Name = "textBox11ZP14";
            this.textBox11ZP14.Size = new System.Drawing.Size(21, 21);
            this.textBox11ZP14.TabIndex = 74;
            this.textBox11ZP14.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox11ZP14.TextChanged += new System.EventHandler(this.textBox11ZP14_TextChanged);
            this.textBox11ZP14.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBoxdipZP14
            // 
            this.textBoxdipZP14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBoxdipZP14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxdipZP14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxdipZP14.Location = new System.Drawing.Point(1095, 410);
            this.textBoxdipZP14.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxdipZP14.Name = "textBoxdipZP14";
            this.textBoxdipZP14.ReadOnly = true;
            this.textBoxdipZP14.Size = new System.Drawing.Size(30, 21);
            this.textBoxdipZP14.TabIndex = 124;
            this.textBoxdipZP14.TabStop = false;
            this.textBoxdipZP14.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBoxdipZP14.TextChanged += new System.EventHandler(this.textBoxdipZP14_TextChanged);
            this.textBoxdipZP14.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox10ZP5
            // 
            this.textBox10ZP5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox10ZP5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox10ZP5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox10ZP5.Location = new System.Drawing.Point(501, 224);
            this.textBox10ZP5.Margin = new System.Windows.Forms.Padding(0);
            this.textBox10ZP5.Name = "textBox10ZP5";
            this.textBox10ZP5.Size = new System.Drawing.Size(21, 21);
            this.textBox10ZP5.TabIndex = 38;
            this.textBox10ZP5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox10ZP5.TextChanged += new System.EventHandler(this.textBox10ZP5_TextChanged);
            this.textBox10ZP5.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox12ZP14
            // 
            this.textBox12ZP14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox12ZP14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox12ZP14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox12ZP14.Location = new System.Drawing.Point(897, 410);
            this.textBox12ZP14.Margin = new System.Windows.Forms.Padding(0);
            this.textBox12ZP14.Name = "textBox12ZP14";
            this.textBox12ZP14.Size = new System.Drawing.Size(21, 21);
            this.textBox12ZP14.TabIndex = 97;
            this.textBox12ZP14.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox12ZP14.TextChanged += new System.EventHandler(this.textBox12ZP14_TextChanged);
            this.textBox12ZP14.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox9ZIP16
            // 
            this.textBox9ZIP16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox9ZIP16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox9ZIP16.Enabled = false;
            this.textBox9ZIP16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox9ZIP16.Location = new System.Drawing.Point(402, 452);
            this.textBox9ZIP16.Margin = new System.Windows.Forms.Padding(0);
            this.textBox9ZIP16.Name = "textBox9ZIP16";
            this.textBox9ZIP16.Size = new System.Drawing.Size(21, 21);
            this.textBox9ZIP16.TabIndex = 300;
            this.textBox9ZIP16.TabStop = false;
            this.textBox9ZIP16.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox9ZIP16.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox11ZIP8
            // 
            this.textBox11ZIP8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox11ZIP8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox11ZIP8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox11ZIP8.Location = new System.Drawing.Point(798, 285);
            this.textBox11ZIP8.Margin = new System.Windows.Forms.Padding(0);
            this.textBox11ZIP8.Name = "textBox11ZIP8";
            this.textBox11ZIP8.Size = new System.Drawing.Size(21, 21);
            this.textBox11ZIP8.TabIndex = 84;
            this.textBox11ZIP8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox11ZIP8.TextChanged += new System.EventHandler(this.textBox11ZIP8_TextChanged);
            this.textBox11ZIP8.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBoxdipZIP8
            // 
            this.textBoxdipZIP8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBoxdipZIP8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxdipZIP8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxdipZIP8.Location = new System.Drawing.Point(1203, 285);
            this.textBoxdipZIP8.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxdipZIP8.Name = "textBoxdipZIP8";
            this.textBoxdipZIP8.ReadOnly = true;
            this.textBoxdipZIP8.Size = new System.Drawing.Size(30, 21);
            this.textBoxdipZIP8.TabIndex = 137;
            this.textBoxdipZIP8.TabStop = false;
            this.textBoxdipZIP8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBoxdipZIP8.TextChanged += new System.EventHandler(this.textBoxdipZIP8_TextChanged);
            this.textBoxdipZIP8.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox10ZP14
            // 
            this.textBox10ZP14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox10ZP14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox10ZP14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox10ZP14.Location = new System.Drawing.Point(501, 411);
            this.textBox10ZP14.Margin = new System.Windows.Forms.Padding(0);
            this.textBox10ZP14.Name = "textBox10ZP14";
            this.textBox10ZP14.Size = new System.Drawing.Size(21, 21);
            this.textBox10ZP14.TabIndex = 44;
            this.textBox10ZP14.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox10ZP14.TextChanged += new System.EventHandler(this.textBox10ZP14_TextChanged);
            this.textBox10ZP14.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox12ZIP8
            // 
            this.textBox12ZIP8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox12ZIP8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox12ZIP8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox12ZIP8.Location = new System.Drawing.Point(996, 285);
            this.textBox12ZIP8.Margin = new System.Windows.Forms.Padding(0);
            this.textBox12ZIP8.Name = "textBox12ZIP8";
            this.textBox12ZIP8.Size = new System.Drawing.Size(21, 21);
            this.textBox12ZIP8.TabIndex = 108;
            this.textBox12ZIP8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox12ZIP8.TextChanged += new System.EventHandler(this.textBox12ZIP8_TextChanged);
            this.textBox12ZIP8.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox9ZP5
            // 
            this.textBox9ZP5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox9ZP5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox9ZP5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox9ZP5.Location = new System.Drawing.Point(303, 224);
            this.textBox9ZP5.Margin = new System.Windows.Forms.Padding(0);
            this.textBox9ZP5.Name = "textBox9ZP5";
            this.textBox9ZP5.Size = new System.Drawing.Size(21, 21);
            this.textBox9ZP5.TabIndex = 5;
            this.textBox9ZP5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox9ZP5.TextChanged += new System.EventHandler(this.textBox9ZP5_TextChanged);
            this.textBox9ZP5.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox10ZIP8
            // 
            this.textBox10ZIP8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox10ZIP8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox10ZIP8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox10ZIP8.Location = new System.Drawing.Point(600, 286);
            this.textBox10ZIP8.Margin = new System.Windows.Forms.Padding(0);
            this.textBox10ZIP8.Name = "textBox10ZIP8";
            this.textBox10ZIP8.Size = new System.Drawing.Size(21, 21);
            this.textBox10ZIP8.TabIndex = 59;
            this.textBox10ZIP8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox10ZIP8.TextChanged += new System.EventHandler(this.textBox10ZIP8_TextChanged);
            this.textBox10ZIP8.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox9ZP14
            // 
            this.textBox9ZP14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox9ZP14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox9ZP14.Enabled = false;
            this.textBox9ZP14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox9ZP14.Location = new System.Drawing.Point(303, 411);
            this.textBox9ZP14.Margin = new System.Windows.Forms.Padding(0);
            this.textBox9ZP14.Name = "textBox9ZP14";
            this.textBox9ZP14.Size = new System.Drawing.Size(21, 21);
            this.textBox9ZP14.TabIndex = 914;
            this.textBox9ZP14.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox9ZP14.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox11ZP6
            // 
            this.textBox11ZP6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox11ZP6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox11ZP6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox11ZP6.Location = new System.Drawing.Point(699, 244);
            this.textBox11ZP6.Margin = new System.Windows.Forms.Padding(0);
            this.textBox11ZP6.Name = "textBox11ZP6";
            this.textBox11ZP6.Size = new System.Drawing.Size(21, 21);
            this.textBox11ZP6.TabIndex = 69;
            this.textBox11ZP6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox11ZP6.TextChanged += new System.EventHandler(this.textBox11ZP6_TextChanged);
            this.textBox11ZP6.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBoxdipZP6
            // 
            this.textBoxdipZP6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBoxdipZP6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxdipZP6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxdipZP6.Location = new System.Drawing.Point(1095, 244);
            this.textBoxdipZP6.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxdipZP6.Name = "textBoxdipZP6";
            this.textBoxdipZP6.ReadOnly = true;
            this.textBoxdipZP6.Size = new System.Drawing.Size(30, 21);
            this.textBoxdipZP6.TabIndex = 116;
            this.textBoxdipZP6.TabStop = false;
            this.textBoxdipZP6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBoxdipZP6.TextChanged += new System.EventHandler(this.textBoxdipZP6_TextChanged);
            this.textBoxdipZP6.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox12ZP6
            // 
            this.textBox12ZP6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox12ZP6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox12ZP6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox12ZP6.Location = new System.Drawing.Point(897, 244);
            this.textBox12ZP6.Margin = new System.Windows.Forms.Padding(0);
            this.textBox12ZP6.Name = "textBox12ZP6";
            this.textBox12ZP6.Size = new System.Drawing.Size(21, 21);
            this.textBox12ZP6.TabIndex = 92;
            this.textBox12ZP6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox12ZP6.TextChanged += new System.EventHandler(this.textBox12ZP6_TextChanged);
            this.textBox12ZP6.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox9ZIP8
            // 
            this.textBox9ZIP8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox9ZIP8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox9ZIP8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox9ZIP8.Location = new System.Drawing.Point(402, 286);
            this.textBox9ZIP8.Margin = new System.Windows.Forms.Padding(0);
            this.textBox9ZIP8.Name = "textBox9ZIP8";
            this.textBox9ZIP8.Size = new System.Drawing.Size(21, 21);
            this.textBox9ZIP8.TabIndex = 26;
            this.textBox9ZIP8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox9ZIP8.TextChanged += new System.EventHandler(this.textBox9ZIP8_TextChanged);
            this.textBox9ZIP8.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox11ZIP12
            // 
            this.textBox11ZIP12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox11ZIP12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox11ZIP12.Enabled = false;
            this.textBox11ZIP12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox11ZIP12.Location = new System.Drawing.Point(798, 368);
            this.textBox11ZIP12.Margin = new System.Windows.Forms.Padding(0);
            this.textBox11ZIP12.Name = "textBox11ZIP12";
            this.textBox11ZIP12.Size = new System.Drawing.Size(21, 21);
            this.textBox11ZIP12.TabIndex = 807;
            this.textBox11ZIP12.TabStop = false;
            this.textBox11ZIP12.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox11ZIP12.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBoxdipZIP12
            // 
            this.textBoxdipZIP12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBoxdipZIP12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxdipZIP12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxdipZIP12.Location = new System.Drawing.Point(1203, 368);
            this.textBoxdipZIP12.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxdipZIP12.Name = "textBoxdipZIP12";
            this.textBoxdipZIP12.ReadOnly = true;
            this.textBoxdipZIP12.Size = new System.Drawing.Size(30, 21);
            this.textBoxdipZIP12.TabIndex = 141;
            this.textBoxdipZIP12.TabStop = false;
            this.textBoxdipZIP12.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBoxdipZIP12.TextChanged += new System.EventHandler(this.textBoxdipZIP12_TextChanged);
            this.textBoxdipZIP12.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox10ZP6
            // 
            this.textBox10ZP6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox10ZP6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox10ZP6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox10ZP6.Location = new System.Drawing.Point(501, 245);
            this.textBox10ZP6.Margin = new System.Windows.Forms.Padding(0);
            this.textBox10ZP6.Name = "textBox10ZP6";
            this.textBox10ZP6.Size = new System.Drawing.Size(21, 21);
            this.textBox10ZP6.TabIndex = 39;
            this.textBox10ZP6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox10ZP6.TextChanged += new System.EventHandler(this.textBox10ZP6_TextChanged);
            this.textBox10ZP6.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox12ZIP12
            // 
            this.textBox12ZIP12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox12ZIP12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox12ZIP12.Enabled = false;
            this.textBox12ZIP12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox12ZIP12.Location = new System.Drawing.Point(996, 368);
            this.textBox12ZIP12.Margin = new System.Windows.Forms.Padding(0);
            this.textBox12ZIP12.Name = "textBox12ZIP12";
            this.textBox12ZIP12.Size = new System.Drawing.Size(21, 21);
            this.textBox12ZIP12.TabIndex = 876;
            this.textBox12ZIP12.TabStop = false;
            this.textBox12ZIP12.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox12ZIP12.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox11ZIPFil1
            // 
            this.textBox11ZIPFil1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox11ZIPFil1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox11ZIPFil1.Location = new System.Drawing.Point(720, 348);
            this.textBox11ZIPFil1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox11ZIPFil1.Name = "textBox11ZIPFil1";
            this.textBox11ZIPFil1.ReadOnly = true;
            this.textBox11ZIPFil1.Size = new System.Drawing.Size(78, 21);
            this.textBox11ZIPFil1.TabIndex = 1019;
            this.textBox11ZIPFil1.TabStop = false;
            // 
            // textBoxdipFilZIP1
            // 
            this.textBoxdipFilZIP1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxdipFilZIP1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxdipFilZIP1.Location = new System.Drawing.Point(1125, 348);
            this.textBoxdipFilZIP1.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxdipFilZIP1.Name = "textBoxdipFilZIP1";
            this.textBoxdipFilZIP1.ReadOnly = true;
            this.textBoxdipFilZIP1.Size = new System.Drawing.Size(78, 21);
            this.textBoxdipFilZIP1.TabIndex = 1018;
            this.textBoxdipFilZIP1.TabStop = false;
            // 
            // textBox10ZIP12
            // 
            this.textBox10ZIP12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox10ZIP12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox10ZIP12.Enabled = false;
            this.textBox10ZIP12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox10ZIP12.Location = new System.Drawing.Point(600, 369);
            this.textBox10ZIP12.Margin = new System.Windows.Forms.Padding(0);
            this.textBox10ZIP12.Name = "textBox10ZIP12";
            this.textBox10ZIP12.Size = new System.Drawing.Size(21, 21);
            this.textBox10ZIP12.TabIndex = 769;
            this.textBox10ZIP12.TabStop = false;
            this.textBox10ZIP12.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox10ZIP12.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox246
            // 
            this.textBox246.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox246.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox246.Location = new System.Drawing.Point(918, 348);
            this.textBox246.Margin = new System.Windows.Forms.Padding(0);
            this.textBox246.Name = "textBox246";
            this.textBox246.ReadOnly = true;
            this.textBox246.Size = new System.Drawing.Size(78, 21);
            this.textBox246.TabIndex = 1020;
            this.textBox246.TabStop = false;
            // 
            // textBox9ZP6
            // 
            this.textBox9ZP6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox9ZP6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox9ZP6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox9ZP6.Location = new System.Drawing.Point(303, 245);
            this.textBox9ZP6.Margin = new System.Windows.Forms.Padding(0);
            this.textBox9ZP6.Name = "textBox9ZP6";
            this.textBox9ZP6.Size = new System.Drawing.Size(21, 21);
            this.textBox9ZP6.TabIndex = 6;
            this.textBox9ZP6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox9ZP6.TextChanged += new System.EventHandler(this.textBox9ZP6_TextChanged);
            this.textBox9ZP6.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox11ZP16
            // 
            this.textBox11ZP16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox11ZP16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox11ZP16.Enabled = false;
            this.textBox11ZP16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox11ZP16.Location = new System.Drawing.Point(699, 451);
            this.textBox11ZP16.Margin = new System.Windows.Forms.Padding(0);
            this.textBox11ZP16.Name = "textBox11ZP16";
            this.textBox11ZP16.Size = new System.Drawing.Size(21, 21);
            this.textBox11ZP16.TabIndex = 792;
            this.textBox11ZP16.TabStop = false;
            this.textBox11ZP16.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox11ZP16.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBoxdipZP16
            // 
            this.textBoxdipZP16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBoxdipZP16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxdipZP16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxdipZP16.Location = new System.Drawing.Point(1095, 451);
            this.textBoxdipZP16.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxdipZP16.Name = "textBoxdipZP16";
            this.textBoxdipZP16.ReadOnly = true;
            this.textBoxdipZP16.Size = new System.Drawing.Size(30, 21);
            this.textBoxdipZP16.TabIndex = 126;
            this.textBoxdipZP16.TabStop = false;
            this.textBoxdipZP16.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBoxdipZP16.TextChanged += new System.EventHandler(this.textBoxdipZP16_TextChanged);
            this.textBoxdipZP16.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox166
            // 
            this.textBox166.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox166.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox166.Location = new System.Drawing.Point(522, 349);
            this.textBox166.Margin = new System.Windows.Forms.Padding(0);
            this.textBox166.Name = "textBox166";
            this.textBox166.ReadOnly = true;
            this.textBox166.Size = new System.Drawing.Size(78, 21);
            this.textBox166.TabIndex = 1022;
            this.textBox166.TabStop = false;
            // 
            // textBox12ZP16
            // 
            this.textBox12ZP16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox12ZP16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox12ZP16.Enabled = false;
            this.textBox12ZP16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox12ZP16.Location = new System.Drawing.Point(897, 451);
            this.textBox12ZP16.Margin = new System.Windows.Forms.Padding(0);
            this.textBox12ZP16.Name = "textBox12ZP16";
            this.textBox12ZP16.Size = new System.Drawing.Size(21, 21);
            this.textBox12ZP16.TabIndex = 846;
            this.textBox12ZP16.TabStop = false;
            this.textBox12ZP16.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox12ZP16.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox9ZIP12
            // 
            this.textBox9ZIP12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox9ZIP12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox9ZIP12.Enabled = false;
            this.textBox9ZIP12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox9ZIP12.Location = new System.Drawing.Point(402, 369);
            this.textBox9ZIP12.Margin = new System.Windows.Forms.Padding(0);
            this.textBox9ZIP12.Name = "textBox9ZIP12";
            this.textBox9ZIP12.Size = new System.Drawing.Size(21, 21);
            this.textBox9ZIP12.TabIndex = 731;
            this.textBox9ZIP12.TabStop = false;
            this.textBox9ZIP12.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox9ZIP12.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox11ZIP4
            // 
            this.textBox11ZIP4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox11ZIP4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox11ZIP4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox11ZIP4.Location = new System.Drawing.Point(798, 202);
            this.textBox11ZIP4.Margin = new System.Windows.Forms.Padding(0);
            this.textBox11ZIP4.Name = "textBox11ZIP4";
            this.textBox11ZIP4.Size = new System.Drawing.Size(21, 21);
            this.textBox11ZIP4.TabIndex = 80;
            this.textBox11ZIP4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox11ZIP4.TextChanged += new System.EventHandler(this.textBox11ZIP4_TextChanged);
            this.textBox11ZIP4.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBoxdipZIP4
            // 
            this.textBoxdipZIP4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBoxdipZIP4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxdipZIP4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxdipZIP4.Location = new System.Drawing.Point(1203, 202);
            this.textBoxdipZIP4.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxdipZIP4.Name = "textBoxdipZIP4";
            this.textBoxdipZIP4.ReadOnly = true;
            this.textBoxdipZIP4.Size = new System.Drawing.Size(30, 21);
            this.textBoxdipZIP4.TabIndex = 133;
            this.textBoxdipZIP4.TabStop = false;
            this.textBoxdipZIP4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBoxdipZIP4.TextChanged += new System.EventHandler(this.textBoxdipZIP4_TextChanged);
            this.textBoxdipZIP4.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox10ZP16
            // 
            this.textBox10ZP16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox10ZP16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox10ZP16.Enabled = false;
            this.textBox10ZP16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox10ZP16.Location = new System.Drawing.Point(501, 452);
            this.textBox10ZP16.Margin = new System.Windows.Forms.Padding(0);
            this.textBox10ZP16.Name = "textBox10ZP16";
            this.textBox10ZP16.Size = new System.Drawing.Size(21, 21);
            this.textBox10ZP16.TabIndex = 460;
            this.textBox10ZP16.TabStop = false;
            this.textBox10ZP16.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox10ZP16.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox12ZIP4
            // 
            this.textBox12ZIP4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox12ZIP4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox12ZIP4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox12ZIP4.Location = new System.Drawing.Point(996, 202);
            this.textBox12ZIP4.Margin = new System.Windows.Forms.Padding(0);
            this.textBox12ZIP4.Name = "textBox12ZIP4";
            this.textBox12ZIP4.Size = new System.Drawing.Size(21, 21);
            this.textBox12ZIP4.TabIndex = 104;
            this.textBox12ZIP4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox12ZIP4.TextChanged += new System.EventHandler(this.textBox12ZIP4_TextChanged);
            this.textBox12ZIP4.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox55
            // 
            this.textBox55.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox55.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox55.Location = new System.Drawing.Point(324, 349);
            this.textBox55.Margin = new System.Windows.Forms.Padding(0);
            this.textBox55.Name = "textBox55";
            this.textBox55.ReadOnly = true;
            this.textBox55.Size = new System.Drawing.Size(78, 21);
            this.textBox55.TabIndex = 1021;
            this.textBox55.TabStop = false;
            // 
            // textBox11ZIPHim1
            // 
            this.textBox11ZIPHim1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox11ZIPHim1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox11ZIPHim1.Location = new System.Drawing.Point(720, 431);
            this.textBox11ZIPHim1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox11ZIPHim1.Name = "textBox11ZIPHim1";
            this.textBox11ZIPHim1.ReadOnly = true;
            this.textBox11ZIPHim1.Size = new System.Drawing.Size(78, 21);
            this.textBox11ZIPHim1.TabIndex = 1034;
            this.textBox11ZIPHim1.TabStop = false;
            // 
            // textBoxdipHimZIP1
            // 
            this.textBoxdipHimZIP1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxdipHimZIP1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxdipHimZIP1.Location = new System.Drawing.Point(1125, 431);
            this.textBoxdipHimZIP1.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxdipHimZIP1.Name = "textBoxdipHimZIP1";
            this.textBoxdipHimZIP1.ReadOnly = true;
            this.textBoxdipHimZIP1.Size = new System.Drawing.Size(78, 21);
            this.textBoxdipHimZIP1.TabIndex = 1033;
            this.textBoxdipHimZIP1.TabStop = false;
            // 
            // textBox10ZIP4
            // 
            this.textBox10ZIP4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox10ZIP4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox10ZIP4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox10ZIP4.Location = new System.Drawing.Point(600, 203);
            this.textBox10ZIP4.Margin = new System.Windows.Forms.Padding(0);
            this.textBox10ZIP4.Name = "textBox10ZIP4";
            this.textBox10ZIP4.Size = new System.Drawing.Size(21, 21);
            this.textBox10ZIP4.TabIndex = 55;
            this.textBox10ZIP4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox10ZIP4.TextChanged += new System.EventHandler(this.textBox10ZIP4_TextChanged);
            this.textBox10ZIP4.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox12ZIPHim1
            // 
            this.textBox12ZIPHim1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox12ZIPHim1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox12ZIPHim1.Location = new System.Drawing.Point(918, 431);
            this.textBox12ZIPHim1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox12ZIPHim1.Name = "textBox12ZIPHim1";
            this.textBox12ZIPHim1.ReadOnly = true;
            this.textBox12ZIPHim1.Size = new System.Drawing.Size(78, 21);
            this.textBox12ZIPHim1.TabIndex = 1035;
            this.textBox12ZIPHim1.TabStop = false;
            // 
            // textBox9ZP16
            // 
            this.textBox9ZP16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox9ZP16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox9ZP16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox9ZP16.Location = new System.Drawing.Point(303, 452);
            this.textBox9ZP16.Margin = new System.Windows.Forms.Padding(0);
            this.textBox9ZP16.Name = "textBox9ZP16";
            this.textBox9ZP16.Size = new System.Drawing.Size(21, 21);
            this.textBox9ZP16.TabIndex = 16;
            this.textBox9ZP16.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox9ZP16.TextChanged += new System.EventHandler(this.textBox9ZP16_TextChanged);
            this.textBox9ZP16.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox11ZP8
            // 
            this.textBox11ZP8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox11ZP8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox11ZP8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox11ZP8.Location = new System.Drawing.Point(699, 285);
            this.textBox11ZP8.Margin = new System.Windows.Forms.Padding(0);
            this.textBox11ZP8.Name = "textBox11ZP8";
            this.textBox11ZP8.Size = new System.Drawing.Size(21, 21);
            this.textBox11ZP8.TabIndex = 71;
            this.textBox11ZP8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox11ZP8.TextChanged += new System.EventHandler(this.textBox11ZP8_TextChanged);
            this.textBox11ZP8.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBoxdipZP8
            // 
            this.textBoxdipZP8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBoxdipZP8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxdipZP8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxdipZP8.Location = new System.Drawing.Point(1095, 285);
            this.textBoxdipZP8.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxdipZP8.Name = "textBoxdipZP8";
            this.textBoxdipZP8.ReadOnly = true;
            this.textBoxdipZP8.Size = new System.Drawing.Size(30, 21);
            this.textBoxdipZP8.TabIndex = 118;
            this.textBoxdipZP8.TabStop = false;
            this.textBoxdipZP8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBoxdipZP8.TextChanged += new System.EventHandler(this.textBoxdipZP8_TextChanged);
            this.textBoxdipZP8.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox10ZIPHim1
            // 
            this.textBox10ZIPHim1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox10ZIPHim1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox10ZIPHim1.Location = new System.Drawing.Point(522, 432);
            this.textBox10ZIPHim1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox10ZIPHim1.Name = "textBox10ZIPHim1";
            this.textBox10ZIPHim1.ReadOnly = true;
            this.textBox10ZIPHim1.Size = new System.Drawing.Size(78, 21);
            this.textBox10ZIPHim1.TabIndex = 1037;
            this.textBox10ZIPHim1.TabStop = false;
            // 
            // textBox12ZP8
            // 
            this.textBox12ZP8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox12ZP8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox12ZP8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox12ZP8.Location = new System.Drawing.Point(897, 285);
            this.textBox12ZP8.Margin = new System.Windows.Forms.Padding(0);
            this.textBox12ZP8.Name = "textBox12ZP8";
            this.textBox12ZP8.Size = new System.Drawing.Size(21, 21);
            this.textBox12ZP8.TabIndex = 94;
            this.textBox12ZP8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox12ZP8.TextChanged += new System.EventHandler(this.textBox12ZP8_TextChanged);
            this.textBox12ZP8.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox9ZIP4
            // 
            this.textBox9ZIP4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox9ZIP4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox9ZIP4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox9ZIP4.Location = new System.Drawing.Point(402, 203);
            this.textBox9ZIP4.Margin = new System.Windows.Forms.Padding(0);
            this.textBox9ZIP4.Name = "textBox9ZIP4";
            this.textBox9ZIP4.Size = new System.Drawing.Size(21, 21);
            this.textBox9ZIP4.TabIndex = 23;
            this.textBox9ZIP4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox9ZIP4.TextChanged += new System.EventHandler(this.textBox9ZIP4_TextChanged);
            this.textBox9ZIP4.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox321
            // 
            this.textBox321.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox321.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox321.Location = new System.Drawing.Point(720, 472);
            this.textBox321.Margin = new System.Windows.Forms.Padding(0);
            this.textBox321.Name = "textBox321";
            this.textBox321.ReadOnly = true;
            this.textBox321.Size = new System.Drawing.Size(78, 21);
            this.textBox321.TabIndex = 1029;
            this.textBox321.TabStop = false;
            // 
            // textBoxdipIzobrZIP1
            // 
            this.textBoxdipIzobrZIP1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxdipIzobrZIP1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxdipIzobrZIP1.Location = new System.Drawing.Point(1125, 472);
            this.textBoxdipIzobrZIP1.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxdipIzobrZIP1.Name = "textBoxdipIzobrZIP1";
            this.textBoxdipIzobrZIP1.ReadOnly = true;
            this.textBoxdipIzobrZIP1.Size = new System.Drawing.Size(78, 21);
            this.textBoxdipIzobrZIP1.TabIndex = 1028;
            this.textBoxdipIzobrZIP1.TabStop = false;
            // 
            // textBox10ZP8
            // 
            this.textBox10ZP8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox10ZP8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox10ZP8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox10ZP8.Location = new System.Drawing.Point(501, 286);
            this.textBox10ZP8.Margin = new System.Windows.Forms.Padding(0);
            this.textBox10ZP8.Name = "textBox10ZP8";
            this.textBox10ZP8.Size = new System.Drawing.Size(21, 21);
            this.textBox10ZP8.TabIndex = 41;
            this.textBox10ZP8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox10ZP8.TextChanged += new System.EventHandler(this.textBox10ZP8_TextChanged);
            this.textBox10ZP8.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox241
            // 
            this.textBox241.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox241.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox241.Location = new System.Drawing.Point(918, 472);
            this.textBox241.Margin = new System.Windows.Forms.Padding(0);
            this.textBox241.Name = "textBox241";
            this.textBox241.ReadOnly = true;
            this.textBox241.Size = new System.Drawing.Size(78, 21);
            this.textBox241.TabIndex = 1030;
            this.textBox241.TabStop = false;
            // 
            // textBox9ZIPHim1
            // 
            this.textBox9ZIPHim1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox9ZIPHim1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox9ZIPHim1.Location = new System.Drawing.Point(324, 432);
            this.textBox9ZIPHim1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox9ZIPHim1.Name = "textBox9ZIPHim1";
            this.textBox9ZIPHim1.ReadOnly = true;
            this.textBox9ZIPHim1.Size = new System.Drawing.Size(78, 21);
            this.textBox9ZIPHim1.TabIndex = 1032;
            this.textBox9ZIPHim1.TabStop = false;
            // 
            // textBox11ZIPIst1
            // 
            this.textBox11ZIPIst1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox11ZIPIst1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox11ZIPIst1.Location = new System.Drawing.Point(720, 265);
            this.textBox11ZIPIst1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox11ZIPIst1.Name = "textBox11ZIPIst1";
            this.textBox11ZIPIst1.ReadOnly = true;
            this.textBox11ZIPIst1.Size = new System.Drawing.Size(78, 21);
            this.textBox11ZIPIst1.TabIndex = 1031;
            this.textBox11ZIPIst1.TabStop = false;
            // 
            // textBoxdipIstZIP1
            // 
            this.textBoxdipIstZIP1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxdipIstZIP1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxdipIstZIP1.Location = new System.Drawing.Point(1125, 265);
            this.textBoxdipIstZIP1.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxdipIstZIP1.Name = "textBoxdipIstZIP1";
            this.textBoxdipIstZIP1.ReadOnly = true;
            this.textBoxdipIstZIP1.Size = new System.Drawing.Size(78, 21);
            this.textBoxdipIstZIP1.TabIndex = 1017;
            this.textBoxdipIstZIP1.TabStop = false;
            // 
            // textBox161
            // 
            this.textBox161.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox161.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox161.Location = new System.Drawing.Point(522, 473);
            this.textBox161.Margin = new System.Windows.Forms.Padding(0);
            this.textBox161.Name = "textBox161";
            this.textBox161.ReadOnly = true;
            this.textBox161.Size = new System.Drawing.Size(78, 21);
            this.textBox161.TabIndex = 1003;
            this.textBox161.TabStop = false;
            // 
            // textBox12ZIPIst1
            // 
            this.textBox12ZIPIst1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox12ZIPIst1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox12ZIPIst1.Location = new System.Drawing.Point(918, 265);
            this.textBox12ZIPIst1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox12ZIPIst1.Name = "textBox12ZIPIst1";
            this.textBox12ZIPIst1.ReadOnly = true;
            this.textBox12ZIPIst1.Size = new System.Drawing.Size(78, 21);
            this.textBox12ZIPIst1.TabIndex = 1002;
            this.textBox12ZIPIst1.TabStop = false;
            // 
            // textBox9ZP8
            // 
            this.textBox9ZP8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox9ZP8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox9ZP8.Enabled = false;
            this.textBox9ZP8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox9ZP8.Location = new System.Drawing.Point(303, 286);
            this.textBox9ZP8.Margin = new System.Windows.Forms.Padding(0);
            this.textBox9ZP8.Name = "textBox9ZP8";
            this.textBox9ZP8.Size = new System.Drawing.Size(21, 21);
            this.textBox9ZP8.TabIndex = 700;
            this.textBox9ZP8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox9ZP8.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox11ZP12
            // 
            this.textBox11ZP12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox11ZP12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox11ZP12.Enabled = false;
            this.textBox11ZP12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox11ZP12.Location = new System.Drawing.Point(699, 368);
            this.textBox11ZP12.Margin = new System.Windows.Forms.Padding(0);
            this.textBox11ZP12.Name = "textBox11ZP12";
            this.textBox11ZP12.Size = new System.Drawing.Size(21, 21);
            this.textBox11ZP12.TabIndex = 788;
            this.textBox11ZP12.TabStop = false;
            this.textBox11ZP12.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox11ZP12.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBoxdipZP12
            // 
            this.textBoxdipZP12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBoxdipZP12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxdipZP12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxdipZP12.Location = new System.Drawing.Point(1095, 368);
            this.textBoxdipZP12.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxdipZP12.Name = "textBoxdipZP12";
            this.textBoxdipZP12.ReadOnly = true;
            this.textBoxdipZP12.Size = new System.Drawing.Size(30, 21);
            this.textBoxdipZP12.TabIndex = 122;
            this.textBoxdipZP12.TabStop = false;
            this.textBoxdipZP12.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBoxdipZP12.TextChanged += new System.EventHandler(this.textBoxdipZP12_TextChanged);
            this.textBoxdipZP12.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox10ZIPIst1
            // 
            this.textBox10ZIPIst1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox10ZIPIst1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox10ZIPIst1.Location = new System.Drawing.Point(522, 266);
            this.textBox10ZIPIst1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox10ZIPIst1.Name = "textBox10ZIPIst1";
            this.textBox10ZIPIst1.ReadOnly = true;
            this.textBox10ZIPIst1.Size = new System.Drawing.Size(78, 21);
            this.textBox10ZIPIst1.TabIndex = 1006;
            this.textBox10ZIPIst1.TabStop = false;
            // 
            // textBox12ZP12
            // 
            this.textBox12ZP12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox12ZP12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox12ZP12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox12ZP12.Location = new System.Drawing.Point(897, 368);
            this.textBox12ZP12.Margin = new System.Windows.Forms.Padding(0);
            this.textBox12ZP12.Name = "textBox12ZP12";
            this.textBox12ZP12.Size = new System.Drawing.Size(21, 21);
            this.textBox12ZP12.TabIndex = 95;
            this.textBox12ZP12.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox12ZP12.TextChanged += new System.EventHandler(this.textBox12ZP12_TextChanged);
            this.textBox12ZP12.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox85
            // 
            this.textBox85.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox85.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox85.Location = new System.Drawing.Point(324, 473);
            this.textBox85.Margin = new System.Windows.Forms.Padding(0);
            this.textBox85.Name = "textBox85";
            this.textBox85.ReadOnly = true;
            this.textBox85.Size = new System.Drawing.Size(78, 21);
            this.textBox85.TabIndex = 998;
            this.textBox85.TabStop = false;
            // 
            // textBox318
            // 
            this.textBox318.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox318.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox318.Location = new System.Drawing.Point(720, 306);
            this.textBox318.Margin = new System.Windows.Forms.Padding(0);
            this.textBox318.Name = "textBox318";
            this.textBox318.ReadOnly = true;
            this.textBox318.Size = new System.Drawing.Size(78, 21);
            this.textBox318.TabIndex = 997;
            this.textBox318.TabStop = false;
            // 
            // textBoxdipPsZIP1
            // 
            this.textBoxdipPsZIP1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxdipPsZIP1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxdipPsZIP1.Location = new System.Drawing.Point(1125, 306);
            this.textBoxdipPsZIP1.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxdipPsZIP1.Name = "textBoxdipPsZIP1";
            this.textBoxdipPsZIP1.ReadOnly = true;
            this.textBoxdipPsZIP1.Size = new System.Drawing.Size(78, 21);
            this.textBoxdipPsZIP1.TabIndex = 999;
            this.textBoxdipPsZIP1.TabStop = false;
            // 
            // textBox10ZP12
            // 
            this.textBox10ZP12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox10ZP12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox10ZP12.Enabled = false;
            this.textBox10ZP12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox10ZP12.Location = new System.Drawing.Point(501, 369);
            this.textBox10ZP12.Margin = new System.Windows.Forms.Padding(0);
            this.textBox10ZP12.Name = "textBox10ZP12";
            this.textBox10ZP12.Size = new System.Drawing.Size(21, 21);
            this.textBox10ZP12.TabIndex = 450;
            this.textBox10ZP12.TabStop = false;
            this.textBox10ZP12.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox10ZP12.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox238
            // 
            this.textBox238.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox238.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox238.Location = new System.Drawing.Point(918, 306);
            this.textBox238.Margin = new System.Windows.Forms.Padding(0);
            this.textBox238.Name = "textBox238";
            this.textBox238.ReadOnly = true;
            this.textBox238.Size = new System.Drawing.Size(78, 21);
            this.textBox238.TabIndex = 1001;
            this.textBox238.TabStop = false;
            // 
            // textBox9ZIPIst1
            // 
            this.textBox9ZIPIst1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox9ZIPIst1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox9ZIPIst1.Location = new System.Drawing.Point(324, 266);
            this.textBox9ZIPIst1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox9ZIPIst1.Name = "textBox9ZIPIst1";
            this.textBox9ZIPIst1.ReadOnly = true;
            this.textBox9ZIPIst1.Size = new System.Drawing.Size(78, 21);
            this.textBox9ZIPIst1.TabIndex = 1000;
            this.textBox9ZIPIst1.TabStop = false;
            // 
            // textBox10ZIPPs1
            // 
            this.textBox10ZIPPs1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox10ZIPPs1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox10ZIPPs1.Location = new System.Drawing.Point(522, 307);
            this.textBox10ZIPPs1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox10ZIPPs1.Name = "textBox10ZIPPs1";
            this.textBox10ZIPPs1.ReadOnly = true;
            this.textBox10ZIPPs1.Size = new System.Drawing.Size(78, 21);
            this.textBox10ZIPPs1.TabIndex = 1014;
            this.textBox10ZIPPs1.TabStop = false;
            // 
            // textBox9ZP12
            // 
            this.textBox9ZP12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox9ZP12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox9ZP12.Enabled = false;
            this.textBox9ZP12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox9ZP12.Location = new System.Drawing.Point(303, 369);
            this.textBox9ZP12.Margin = new System.Windows.Forms.Padding(0);
            this.textBox9ZP12.Name = "textBox9ZP12";
            this.textBox9ZP12.Size = new System.Drawing.Size(21, 21);
            this.textBox9ZP12.TabIndex = 912;
            this.textBox9ZP12.TabStop = false;
            this.textBox9ZP12.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox9ZP12.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox11ZP4
            // 
            this.textBox11ZP4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox11ZP4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox11ZP4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox11ZP4.Location = new System.Drawing.Point(699, 202);
            this.textBox11ZP4.Margin = new System.Windows.Forms.Padding(0);
            this.textBox11ZP4.Name = "textBox11ZP4";
            this.textBox11ZP4.Size = new System.Drawing.Size(21, 21);
            this.textBox11ZP4.TabIndex = 67;
            this.textBox11ZP4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox11ZP4.TextChanged += new System.EventHandler(this.textBox11ZP4_TextChanged);
            this.textBox11ZP4.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBoxdipZP4
            // 
            this.textBoxdipZP4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBoxdipZP4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxdipZP4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxdipZP4.Location = new System.Drawing.Point(1095, 202);
            this.textBoxdipZP4.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxdipZP4.Name = "textBoxdipZP4";
            this.textBoxdipZP4.ReadOnly = true;
            this.textBoxdipZP4.Size = new System.Drawing.Size(30, 21);
            this.textBoxdipZP4.TabIndex = 114;
            this.textBoxdipZP4.TabStop = false;
            this.textBoxdipZP4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBoxdipZP4.TextChanged += new System.EventHandler(this.textBoxdipZP4_TextChanged);
            this.textBoxdipZP4.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox12ZP4
            // 
            this.textBox12ZP4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox12ZP4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox12ZP4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox12ZP4.Location = new System.Drawing.Point(897, 202);
            this.textBox12ZP4.Margin = new System.Windows.Forms.Padding(0);
            this.textBox12ZP4.Name = "textBox12ZP4";
            this.textBox12ZP4.Size = new System.Drawing.Size(21, 21);
            this.textBox12ZP4.TabIndex = 90;
            this.textBox12ZP4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox12ZP4.TextChanged += new System.EventHandler(this.textBox12ZP4_TextChanged);
            this.textBox12ZP4.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox9ZIPPs1
            // 
            this.textBox9ZIPPs1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox9ZIPPs1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox9ZIPPs1.Location = new System.Drawing.Point(324, 307);
            this.textBox9ZIPPs1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox9ZIPPs1.Name = "textBox9ZIPPs1";
            this.textBox9ZIPPs1.ReadOnly = true;
            this.textBox9ZIPPs1.Size = new System.Drawing.Size(78, 21);
            this.textBox9ZIPPs1.TabIndex = 1009;
            this.textBox9ZIPPs1.TabStop = false;
            // 
            // textBox11ZIPBio1
            // 
            this.textBox11ZIPBio1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox11ZIPBio1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox11ZIPBio1.Location = new System.Drawing.Point(720, 389);
            this.textBox11ZIPBio1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox11ZIPBio1.Name = "textBox11ZIPBio1";
            this.textBox11ZIPBio1.ReadOnly = true;
            this.textBox11ZIPBio1.Size = new System.Drawing.Size(78, 21);
            this.textBox11ZIPBio1.TabIndex = 1011;
            this.textBox11ZIPBio1.TabStop = false;
            // 
            // textBoxdipBioZIP1
            // 
            this.textBoxdipBioZIP1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxdipBioZIP1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxdipBioZIP1.Location = new System.Drawing.Point(1125, 389);
            this.textBoxdipBioZIP1.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxdipBioZIP1.Name = "textBoxdipBioZIP1";
            this.textBoxdipBioZIP1.ReadOnly = true;
            this.textBoxdipBioZIP1.Size = new System.Drawing.Size(78, 21);
            this.textBoxdipBioZIP1.TabIndex = 1010;
            this.textBoxdipBioZIP1.TabStop = false;
            // 
            // textBox10ZP4
            // 
            this.textBox10ZP4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox10ZP4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox10ZP4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox10ZP4.Location = new System.Drawing.Point(501, 203);
            this.textBox10ZP4.Margin = new System.Windows.Forms.Padding(0);
            this.textBox10ZP4.Name = "textBox10ZP4";
            this.textBox10ZP4.Size = new System.Drawing.Size(21, 21);
            this.textBox10ZP4.TabIndex = 37;
            this.textBox10ZP4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox10ZP4.TextChanged += new System.EventHandler(this.textBox10ZP4_TextChanged);
            this.textBox10ZP4.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox12ZIPBio1
            // 
            this.textBox12ZIPBio1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox12ZIPBio1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox12ZIPBio1.Location = new System.Drawing.Point(918, 389);
            this.textBox12ZIPBio1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox12ZIPBio1.Name = "textBox12ZIPBio1";
            this.textBox12ZIPBio1.ReadOnly = true;
            this.textBox12ZIPBio1.Size = new System.Drawing.Size(78, 21);
            this.textBox12ZIPBio1.TabIndex = 1073;
            this.textBox12ZIPBio1.TabStop = false;
            // 
            // textBox11Fil1
            // 
            this.textBox11Fil1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox11Fil1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox11Fil1.Location = new System.Drawing.Point(621, 348);
            this.textBox11Fil1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox11Fil1.Name = "textBox11Fil1";
            this.textBox11Fil1.ReadOnly = true;
            this.textBox11Fil1.Size = new System.Drawing.Size(78, 21);
            this.textBox11Fil1.TabIndex = 1072;
            this.textBox11Fil1.TabStop = false;
            // 
            // textBoxdipFil1
            // 
            this.textBoxdipFil1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxdipFil1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxdipFil1.Location = new System.Drawing.Point(1017, 348);
            this.textBoxdipFil1.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxdipFil1.Name = "textBoxdipFil1";
            this.textBoxdipFil1.ReadOnly = true;
            this.textBoxdipFil1.Size = new System.Drawing.Size(78, 21);
            this.textBoxdipFil1.TabIndex = 1065;
            this.textBoxdipFil1.TabStop = false;
            // 
            // textBox10ZIPBio1
            // 
            this.textBox10ZIPBio1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox10ZIPBio1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox10ZIPBio1.Location = new System.Drawing.Point(522, 390);
            this.textBox10ZIPBio1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox10ZIPBio1.Name = "textBox10ZIPBio1";
            this.textBox10ZIPBio1.ReadOnly = true;
            this.textBox10ZIPBio1.Size = new System.Drawing.Size(78, 21);
            this.textBox10ZIPBio1.TabIndex = 1068;
            this.textBox10ZIPBio1.TabStop = false;
            // 
            // textBox234
            // 
            this.textBox234.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox234.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox234.Location = new System.Drawing.Point(819, 348);
            this.textBox234.Margin = new System.Windows.Forms.Padding(0);
            this.textBox234.Name = "textBox234";
            this.textBox234.ReadOnly = true;
            this.textBox234.Size = new System.Drawing.Size(78, 21);
            this.textBox234.TabIndex = 1069;
            this.textBox234.TabStop = false;
            // 
            // textBox9ZP4
            // 
            this.textBox9ZP4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox9ZP4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox9ZP4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox9ZP4.Location = new System.Drawing.Point(303, 203);
            this.textBox9ZP4.Margin = new System.Windows.Forms.Padding(0);
            this.textBox9ZP4.Name = "textBox9ZP4";
            this.textBox9ZP4.Size = new System.Drawing.Size(21, 21);
            this.textBox9ZP4.TabIndex = 4;
            this.textBox9ZP4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox9ZP4.TextChanged += new System.EventHandler(this.textBox9ZP4_TextChanged);
            this.textBox9ZP4.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox11Him1
            // 
            this.textBox11Him1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox11Him1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox11Him1.Location = new System.Drawing.Point(621, 431);
            this.textBox11Him1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox11Him1.Name = "textBox11Him1";
            this.textBox11Him1.ReadOnly = true;
            this.textBox11Him1.Size = new System.Drawing.Size(78, 21);
            this.textBox11Him1.TabIndex = 1067;
            this.textBox11Him1.TabStop = false;
            // 
            // textBoxdipHim1
            // 
            this.textBoxdipHim1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxdipHim1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxdipHim1.Location = new System.Drawing.Point(1017, 431);
            this.textBoxdipHim1.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxdipHim1.Name = "textBoxdipHim1";
            this.textBoxdipHim1.ReadOnly = true;
            this.textBoxdipHim1.Size = new System.Drawing.Size(78, 21);
            this.textBoxdipHim1.TabIndex = 1064;
            this.textBoxdipHim1.TabStop = false;
            // 
            // textBox154
            // 
            this.textBox154.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox154.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox154.Location = new System.Drawing.Point(423, 349);
            this.textBox154.Margin = new System.Windows.Forms.Padding(0);
            this.textBox154.Name = "textBox154";
            this.textBox154.ReadOnly = true;
            this.textBox154.Size = new System.Drawing.Size(78, 21);
            this.textBox154.TabIndex = 1066;
            this.textBox154.TabStop = false;
            // 
            // textBox12Him1
            // 
            this.textBox12Him1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox12Him1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox12Him1.Location = new System.Drawing.Point(819, 431);
            this.textBox12Him1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox12Him1.Name = "textBox12Him1";
            this.textBox12Him1.ReadOnly = true;
            this.textBox12Him1.Size = new System.Drawing.Size(78, 21);
            this.textBox12Him1.TabIndex = 1063;
            this.textBox12Him1.TabStop = false;
            // 
            // textBox9BioZIP1
            // 
            this.textBox9BioZIP1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox9BioZIP1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox9BioZIP1.Location = new System.Drawing.Point(324, 390);
            this.textBox9BioZIP1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox9BioZIP1.Name = "textBox9BioZIP1";
            this.textBox9BioZIP1.ReadOnly = true;
            this.textBox9BioZIP1.Size = new System.Drawing.Size(78, 21);
            this.textBox9BioZIP1.TabIndex = 1062;
            this.textBox9BioZIP1.TabStop = false;
            // 
            // textBox11ZIPInf1
            // 
            this.textBox11ZIPInf1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox11ZIPInf1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox11ZIPInf1.Location = new System.Drawing.Point(720, 223);
            this.textBox11ZIPInf1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox11ZIPInf1.Name = "textBox11ZIPInf1";
            this.textBox11ZIPInf1.ReadOnly = true;
            this.textBox11ZIPInf1.Size = new System.Drawing.Size(78, 21);
            this.textBox11ZIPInf1.TabIndex = 1074;
            this.textBox11ZIPInf1.TabStop = false;
            // 
            // textBoxdipInfZIP1
            // 
            this.textBoxdipInfZIP1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxdipInfZIP1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxdipInfZIP1.Location = new System.Drawing.Point(1125, 223);
            this.textBoxdipInfZIP1.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxdipInfZIP1.Name = "textBoxdipInfZIP1";
            this.textBoxdipInfZIP1.ReadOnly = true;
            this.textBoxdipInfZIP1.Size = new System.Drawing.Size(78, 21);
            this.textBoxdipInfZIP1.TabIndex = 1077;
            this.textBoxdipInfZIP1.TabStop = false;
            // 
            // textBox10Him1
            // 
            this.textBox10Him1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox10Him1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox10Him1.Location = new System.Drawing.Point(423, 432);
            this.textBox10Him1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox10Him1.Name = "textBox10Him1";
            this.textBox10Him1.ReadOnly = true;
            this.textBox10Him1.Size = new System.Drawing.Size(78, 21);
            this.textBox10Him1.TabIndex = 1076;
            this.textBox10Him1.TabStop = false;
            // 
            // textBox12ZIPInf1
            // 
            this.textBox12ZIPInf1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox12ZIPInf1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox12ZIPInf1.Location = new System.Drawing.Point(918, 223);
            this.textBox12ZIPInf1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox12ZIPInf1.Name = "textBox12ZIPInf1";
            this.textBox12ZIPInf1.ReadOnly = true;
            this.textBox12ZIPInf1.Size = new System.Drawing.Size(78, 21);
            this.textBox12ZIPInf1.TabIndex = 1071;
            this.textBox12ZIPInf1.TabStop = false;
            // 
            // textBox52
            // 
            this.textBox52.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox52.Enabled = false;
            this.textBox52.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox52.Location = new System.Drawing.Point(225, 349);
            this.textBox52.Margin = new System.Windows.Forms.Padding(0);
            this.textBox52.Name = "textBox52";
            this.textBox52.ReadOnly = true;
            this.textBox52.Size = new System.Drawing.Size(78, 21);
            this.textBox52.TabIndex = 1070;
            this.textBox52.TabStop = false;
            // 
            // textBoxBrOcZIP
            // 
            this.textBoxBrOcZIP.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxBrOcZIP.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxBrOcZIP.Location = new System.Drawing.Point(819, 674);
            this.textBoxBrOcZIP.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxBrOcZIP.Name = "textBoxBrOcZIP";
            this.textBoxBrOcZIP.ReadOnly = true;
            this.textBoxBrOcZIP.Size = new System.Drawing.Size(74, 21);
            this.textBoxBrOcZIP.TabIndex = 1046;
            this.textBoxBrOcZIP.TabStop = false;
            // 
            // textBox11ZIPFV1
            // 
            this.textBox11ZIPFV1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox11ZIPFV1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox11ZIPFV1.Location = new System.Drawing.Point(720, 493);
            this.textBox11ZIPFV1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox11ZIPFV1.Name = "textBox11ZIPFV1";
            this.textBox11ZIPFV1.ReadOnly = true;
            this.textBox11ZIPFV1.Size = new System.Drawing.Size(78, 21);
            this.textBox11ZIPFV1.TabIndex = 1061;
            this.textBox11ZIPFV1.TabStop = false;
            // 
            // textBox1100
            // 
            this.textBox1100.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox1100.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox1100.Location = new System.Drawing.Point(819, 639);
            this.textBox1100.Margin = new System.Windows.Forms.Padding(0);
            this.textBox1100.Multiline = true;
            this.textBox1100.Name = "textBox1100";
            this.textBox1100.ReadOnly = true;
            this.textBox1100.Size = new System.Drawing.Size(74, 35);
            this.textBox1100.TabIndex = 1046;
            this.textBox1100.TabStop = false;
            this.textBox1100.Text = "брой оценки ЗИП";
            // 
            // textBoxdipFVZIP1
            // 
            this.textBoxdipFVZIP1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxdipFVZIP1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxdipFVZIP1.Location = new System.Drawing.Point(1125, 493);
            this.textBoxdipFVZIP1.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxdipFVZIP1.Name = "textBoxdipFVZIP1";
            this.textBoxdipFVZIP1.ReadOnly = true;
            this.textBoxdipFVZIP1.Size = new System.Drawing.Size(78, 21);
            this.textBoxdipFVZIP1.TabIndex = 1046;
            this.textBoxdipFVZIP1.TabStop = false;
            // 
            // textBox10ZIPInf1
            // 
            this.textBox10ZIPInf1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox10ZIPInf1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox10ZIPInf1.Location = new System.Drawing.Point(522, 224);
            this.textBox10ZIPInf1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox10ZIPInf1.Name = "textBox10ZIPInf1";
            this.textBox10ZIPInf1.ReadOnly = true;
            this.textBox10ZIPInf1.Size = new System.Drawing.Size(78, 21);
            this.textBox10ZIPInf1.TabIndex = 1045;
            this.textBox10ZIPInf1.TabStop = false;
            // 
            // textBox231
            // 
            this.textBox231.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox231.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox231.Location = new System.Drawing.Point(918, 493);
            this.textBox231.Margin = new System.Windows.Forms.Padding(0);
            this.textBox231.Name = "textBox231";
            this.textBox231.ReadOnly = true;
            this.textBox231.Size = new System.Drawing.Size(78, 21);
            this.textBox231.TabIndex = 1047;
            this.textBox231.TabStop = false;
            // 
            // textBox9Him1
            // 
            this.textBox9Him1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox9Him1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox9Him1.Location = new System.Drawing.Point(225, 432);
            this.textBox9Him1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox9Him1.Name = "textBox9Him1";
            this.textBox9Him1.ReadOnly = true;
            this.textBox9Him1.Size = new System.Drawing.Size(78, 21);
            this.textBox9Him1.TabIndex = 1049;
            this.textBox9Him1.TabStop = false;
            // 
            // textBox11Ist1
            // 
            this.textBox11Ist1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox11Ist1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox11Ist1.Location = new System.Drawing.Point(621, 265);
            this.textBox11Ist1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox11Ist1.Name = "textBox11Ist1";
            this.textBox11Ist1.ReadOnly = true;
            this.textBox11Ist1.Size = new System.Drawing.Size(78, 21);
            this.textBox11Ist1.TabIndex = 1048;
            this.textBox11Ist1.TabStop = false;
            // 
            // textBoxdipIst1
            // 
            this.textBoxdipIst1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxdipIst1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxdipIst1.Location = new System.Drawing.Point(1017, 265);
            this.textBoxdipIst1.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxdipIst1.Name = "textBoxdipIst1";
            this.textBoxdipIst1.ReadOnly = true;
            this.textBoxdipIst1.Size = new System.Drawing.Size(78, 21);
            this.textBoxdipIst1.TabIndex = 1044;
            this.textBoxdipIst1.TabStop = false;
            // 
            // textBox10ZIPFV1
            // 
            this.textBox10ZIPFV1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox10ZIPFV1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox10ZIPFV1.Location = new System.Drawing.Point(522, 494);
            this.textBox10ZIPFV1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox10ZIPFV1.Name = "textBox10ZIPFV1";
            this.textBox10ZIPFV1.ReadOnly = true;
            this.textBox10ZIPFV1.Size = new System.Drawing.Size(78, 21);
            this.textBox10ZIPFV1.TabIndex = 1040;
            this.textBox10ZIPFV1.TabStop = false;
            // 
            // textBox12Ist1
            // 
            this.textBox12Ist1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox12Ist1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox12Ist1.Location = new System.Drawing.Point(819, 265);
            this.textBox12Ist1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox12Ist1.Name = "textBox12Ist1";
            this.textBox12Ist1.ReadOnly = true;
            this.textBox12Ist1.Size = new System.Drawing.Size(78, 21);
            this.textBox12Ist1.TabIndex = 1039;
            this.textBox12Ist1.TabStop = false;
            // 
            // textBox9ZIPInf1
            // 
            this.textBox9ZIPInf1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox9ZIPInf1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox9ZIPInf1.Location = new System.Drawing.Point(324, 224);
            this.textBox9ZIPInf1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox9ZIPInf1.Name = "textBox9ZIPInf1";
            this.textBox9ZIPInf1.ReadOnly = true;
            this.textBox9ZIPInf1.Size = new System.Drawing.Size(78, 21);
            this.textBox9ZIPInf1.TabIndex = 1041;
            this.textBox9ZIPInf1.TabStop = false;
            // 
            // textBox309
            // 
            this.textBox309.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox309.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox309.Location = new System.Drawing.Point(720, 327);
            this.textBox309.Margin = new System.Windows.Forms.Padding(0);
            this.textBox309.Name = "textBox309";
            this.textBox309.ReadOnly = true;
            this.textBox309.Size = new System.Drawing.Size(78, 21);
            this.textBox309.TabIndex = 1043;
            this.textBox309.TabStop = false;
            // 
            // textBoxdipEtZIP1
            // 
            this.textBoxdipEtZIP1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxdipEtZIP1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxdipEtZIP1.Location = new System.Drawing.Point(1125, 327);
            this.textBoxdipEtZIP1.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxdipEtZIP1.Name = "textBoxdipEtZIP1";
            this.textBoxdipEtZIP1.ReadOnly = true;
            this.textBoxdipEtZIP1.Size = new System.Drawing.Size(78, 21);
            this.textBoxdipEtZIP1.TabIndex = 1042;
            this.textBoxdipEtZIP1.TabStop = false;
            // 
            // textBox10Ist1
            // 
            this.textBox10Ist1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox10Ist1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox10Ist1.Location = new System.Drawing.Point(423, 266);
            this.textBox10Ist1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox10Ist1.Name = "textBox10Ist1";
            this.textBox10Ist1.ReadOnly = true;
            this.textBox10Ist1.Size = new System.Drawing.Size(78, 21);
            this.textBox10Ist1.TabIndex = 1057;
            this.textBox10Ist1.TabStop = false;
            // 
            // textBox229
            // 
            this.textBox229.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox229.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox229.Location = new System.Drawing.Point(918, 327);
            this.textBox229.Margin = new System.Windows.Forms.Padding(0);
            this.textBox229.Name = "textBox229";
            this.textBox229.ReadOnly = true;
            this.textBox229.Size = new System.Drawing.Size(78, 21);
            this.textBox229.TabIndex = 1056;
            this.textBox229.TabStop = false;
            // 
            // textBox9ZIPFv1
            // 
            this.textBox9ZIPFv1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox9ZIPFv1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox9ZIPFv1.Location = new System.Drawing.Point(324, 494);
            this.textBox9ZIPFv1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox9ZIPFv1.Name = "textBox9ZIPFv1";
            this.textBox9ZIPFv1.ReadOnly = true;
            this.textBox9ZIPFv1.Size = new System.Drawing.Size(78, 21);
            this.textBox9ZIPFv1.TabIndex = 1058;
            this.textBox9ZIPFv1.TabStop = false;
            // 
            // textBox308
            // 
            this.textBox308.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox308.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox308.Location = new System.Drawing.Point(621, 472);
            this.textBox308.Margin = new System.Windows.Forms.Padding(0);
            this.textBox308.Name = "textBox308";
            this.textBox308.ReadOnly = true;
            this.textBox308.Size = new System.Drawing.Size(78, 21);
            this.textBox308.TabIndex = 1060;
            this.textBox308.TabStop = false;
            // 
            // textBoxdipIzobr1
            // 
            this.textBoxdipIzobr1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxdipIzobr1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxdipIzobr1.Location = new System.Drawing.Point(1017, 472);
            this.textBoxdipIzobr1.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxdipIzobr1.Name = "textBoxdipIzobr1";
            this.textBoxdipIzobr1.ReadOnly = true;
            this.textBoxdipIzobr1.Size = new System.Drawing.Size(78, 21);
            this.textBoxdipIzobr1.TabIndex = 1059;
            this.textBoxdipIzobr1.TabStop = false;
            // 
            // textBox10ZIPEt1
            // 
            this.textBox10ZIPEt1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox10ZIPEt1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox10ZIPEt1.Location = new System.Drawing.Point(522, 328);
            this.textBox10ZIPEt1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox10ZIPEt1.Name = "textBox10ZIPEt1";
            this.textBox10ZIPEt1.ReadOnly = true;
            this.textBox10ZIPEt1.Size = new System.Drawing.Size(78, 21);
            this.textBox10ZIPEt1.TabIndex = 1055;
            this.textBox10ZIPEt1.TabStop = false;
            // 
            // textBox228
            // 
            this.textBox228.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox228.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox228.Location = new System.Drawing.Point(819, 472);
            this.textBox228.Margin = new System.Windows.Forms.Padding(0);
            this.textBox228.Name = "textBox228";
            this.textBox228.ReadOnly = true;
            this.textBox228.Size = new System.Drawing.Size(78, 21);
            this.textBox228.TabIndex = 1051;
            this.textBox228.TabStop = false;
            // 
            // textBox9Ist1
            // 
            this.textBox9Ist1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox9Ist1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox9Ist1.Location = new System.Drawing.Point(225, 266);
            this.textBox9Ist1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox9Ist1.Name = "textBox9Ist1";
            this.textBox9Ist1.ReadOnly = true;
            this.textBox9Ist1.Size = new System.Drawing.Size(78, 21);
            this.textBox9Ist1.TabIndex = 1050;
            this.textBox9Ist1.TabStop = false;
            // 
            // textBox148
            // 
            this.textBox148.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox148.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox148.Location = new System.Drawing.Point(423, 473);
            this.textBox148.Margin = new System.Windows.Forms.Padding(0);
            this.textBox148.Name = "textBox148";
            this.textBox148.ReadOnly = true;
            this.textBox148.Size = new System.Drawing.Size(78, 21);
            this.textBox148.TabIndex = 1052;
            this.textBox148.TabStop = false;
            // 
            // textBox11ZIPFz1
            // 
            this.textBox11ZIPFz1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox11ZIPFz1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox11ZIPFz1.Location = new System.Drawing.Point(720, 410);
            this.textBox11ZIPFz1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox11ZIPFz1.Name = "textBox11ZIPFz1";
            this.textBox11ZIPFz1.ReadOnly = true;
            this.textBox11ZIPFz1.Size = new System.Drawing.Size(78, 21);
            this.textBox11ZIPFz1.TabIndex = 1054;
            this.textBox11ZIPFz1.TabStop = false;
            // 
            // textBoxdipFzZIP1
            // 
            this.textBoxdipFzZIP1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxdipFzZIP1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxdipFzZIP1.Location = new System.Drawing.Point(1125, 410);
            this.textBoxdipFzZIP1.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxdipFzZIP1.Name = "textBoxdipFzZIP1";
            this.textBoxdipFzZIP1.ReadOnly = true;
            this.textBoxdipFzZIP1.Size = new System.Drawing.Size(78, 21);
            this.textBoxdipFzZIP1.TabIndex = 1053;
            this.textBoxdipFzZIP1.TabStop = false;
            // 
            // textBox9ZIPEt1
            // 
            this.textBox9ZIPEt1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox9ZIPEt1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox9ZIPEt1.Location = new System.Drawing.Point(324, 328);
            this.textBox9ZIPEt1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox9ZIPEt1.Name = "textBox9ZIPEt1";
            this.textBox9ZIPEt1.ReadOnly = true;
            this.textBox9ZIPEt1.Size = new System.Drawing.Size(78, 21);
            this.textBox9ZIPEt1.TabIndex = 927;
            this.textBox9ZIPEt1.TabStop = false;
            // 
            // textBox12ZIPFz1
            // 
            this.textBox12ZIPFz1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox12ZIPFz1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox12ZIPFz1.Location = new System.Drawing.Point(918, 410);
            this.textBox12ZIPFz1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox12ZIPFz1.Name = "textBox12ZIPFz1";
            this.textBox12ZIPFz1.ReadOnly = true;
            this.textBox12ZIPFz1.Size = new System.Drawing.Size(78, 21);
            this.textBox12ZIPFz1.TabIndex = 926;
            this.textBox12ZIPFz1.TabStop = false;
            // 
            // textBox9Izobr1
            // 
            this.textBox9Izobr1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox9Izobr1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox9Izobr1.Location = new System.Drawing.Point(225, 473);
            this.textBox9Izobr1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox9Izobr1.Name = "textBox9Izobr1";
            this.textBox9Izobr1.ReadOnly = true;
            this.textBox9Izobr1.Size = new System.Drawing.Size(78, 21);
            this.textBox9Izobr1.TabIndex = 925;
            this.textBox9Izobr1.TabStop = false;
            // 
            // textBox11Ps1
            // 
            this.textBox11Ps1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox11Ps1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox11Ps1.Location = new System.Drawing.Point(621, 306);
            this.textBox11Ps1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox11Ps1.Name = "textBox11Ps1";
            this.textBox11Ps1.ReadOnly = true;
            this.textBox11Ps1.Size = new System.Drawing.Size(78, 21);
            this.textBox11Ps1.TabIndex = 930;
            this.textBox11Ps1.TabStop = false;
            // 
            // textBoxdipPs1
            // 
            this.textBoxdipPs1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxdipPs1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxdipPs1.Location = new System.Drawing.Point(1017, 306);
            this.textBoxdipPs1.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxdipPs1.Name = "textBoxdipPs1";
            this.textBoxdipPs1.ReadOnly = true;
            this.textBoxdipPs1.Size = new System.Drawing.Size(78, 21);
            this.textBoxdipPs1.TabIndex = 929;
            this.textBoxdipPs1.TabStop = false;
            // 
            // textBox10ZIPFz1
            // 
            this.textBox10ZIPFz1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox10ZIPFz1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox10ZIPFz1.Location = new System.Drawing.Point(522, 411);
            this.textBox10ZIPFz1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox10ZIPFz1.Name = "textBox10ZIPFz1";
            this.textBox10ZIPFz1.ReadOnly = true;
            this.textBox10ZIPFz1.Size = new System.Drawing.Size(78, 21);
            this.textBox10ZIPFz1.TabIndex = 928;
            this.textBox10ZIPFz1.TabStop = false;
            // 
            // textBox226
            // 
            this.textBox226.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox226.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox226.Location = new System.Drawing.Point(819, 306);
            this.textBox226.Margin = new System.Windows.Forms.Padding(0);
            this.textBox226.Name = "textBox226";
            this.textBox226.ReadOnly = true;
            this.textBox226.Size = new System.Drawing.Size(78, 21);
            this.textBox226.TabIndex = 924;
            this.textBox226.TabStop = false;
            // 
            // textBox450
            // 
            this.textBox450.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox450.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox450.Location = new System.Drawing.Point(662, 639);
            this.textBox450.Margin = new System.Windows.Forms.Padding(0);
            this.textBox450.Multiline = true;
            this.textBox450.Name = "textBox450";
            this.textBox450.ReadOnly = true;
            this.textBox450.Size = new System.Drawing.Size(136, 35);
            this.textBox450.TabIndex = 919;
            this.textBox450.TabStop = false;
            this.textBox450.Text = "Средноаритметична \r\nоценка от ЗП";
            this.textBox450.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxSrZPW
            // 
            this.textBoxSrZPW.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxSrZPW.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxSrZPW.Location = new System.Drawing.Point(662, 674);
            this.textBoxSrZPW.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxSrZPW.Name = "textBoxSrZPW";
            this.textBoxSrZPW.ReadOnly = true;
            this.textBoxSrZPW.Size = new System.Drawing.Size(80, 21);
            this.textBoxSrZPW.TabIndex = 919;
            this.textBoxSrZPW.TabStop = false;
            // 
            // textBox11FV1
            // 
            this.textBox11FV1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox11FV1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox11FV1.Location = new System.Drawing.Point(621, 493);
            this.textBox11FV1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox11FV1.Name = "textBox11FV1";
            this.textBox11FV1.ReadOnly = true;
            this.textBox11FV1.Size = new System.Drawing.Size(78, 21);
            this.textBox11FV1.TabIndex = 920;
            this.textBox11FV1.TabStop = false;
            // 
            // textBoxdipFV1
            // 
            this.textBoxdipFV1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxdipFV1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxdipFV1.Location = new System.Drawing.Point(1017, 493);
            this.textBoxdipFV1.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxdipFV1.Name = "textBoxdipFV1";
            this.textBoxdipFV1.ReadOnly = true;
            this.textBoxdipFV1.Size = new System.Drawing.Size(78, 21);
            this.textBoxdipFV1.TabIndex = 919;
            this.textBoxdipFV1.TabStop = false;
            // 
            // textBox10Ps1
            // 
            this.textBox10Ps1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox10Ps1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox10Ps1.Location = new System.Drawing.Point(423, 307);
            this.textBox10Ps1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox10Ps1.Name = "textBox10Ps1";
            this.textBox10Ps1.ReadOnly = true;
            this.textBox10Ps1.Size = new System.Drawing.Size(78, 21);
            this.textBox10Ps1.TabIndex = 918;
            this.textBox10Ps1.TabStop = false;
            // 
            // textBox12FV1
            // 
            this.textBox12FV1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox12FV1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox12FV1.Location = new System.Drawing.Point(819, 493);
            this.textBox12FV1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox12FV1.Name = "textBox12FV1";
            this.textBox12FV1.ReadOnly = true;
            this.textBox12FV1.Size = new System.Drawing.Size(78, 21);
            this.textBox12FV1.TabIndex = 923;
            this.textBox12FV1.TabStop = false;
            // 
            // textBox9ZIPFz1
            // 
            this.textBox9ZIPFz1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox9ZIPFz1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox9ZIPFz1.Location = new System.Drawing.Point(324, 411);
            this.textBox9ZIPFz1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox9ZIPFz1.Name = "textBox9ZIPFz1";
            this.textBox9ZIPFz1.ReadOnly = true;
            this.textBox9ZIPFz1.Size = new System.Drawing.Size(78, 21);
            this.textBox9ZIPFz1.TabIndex = 922;
            this.textBox9ZIPFz1.TabStop = false;
            // 
            // textBox11ZIPIT1
            // 
            this.textBox11ZIPIT1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox11ZIPIT1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox11ZIPIT1.Location = new System.Drawing.Point(720, 244);
            this.textBox11ZIPIT1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox11ZIPIT1.Name = "textBox11ZIPIT1";
            this.textBox11ZIPIT1.ReadOnly = true;
            this.textBox11ZIPIT1.Size = new System.Drawing.Size(78, 21);
            this.textBox11ZIPIT1.TabIndex = 921;
            this.textBox11ZIPIT1.TabStop = false;
            // 
            // textBoxdipITZIP1
            // 
            this.textBoxdipITZIP1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxdipITZIP1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxdipITZIP1.Location = new System.Drawing.Point(1125, 244);
            this.textBoxdipITZIP1.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxdipITZIP1.Name = "textBoxdipITZIP1";
            this.textBoxdipITZIP1.ReadOnly = true;
            this.textBoxdipITZIP1.Size = new System.Drawing.Size(78, 21);
            this.textBoxdipITZIP1.TabIndex = 940;
            this.textBoxdipITZIP1.TabStop = false;
            // 
            // textBox10FV1
            // 
            this.textBox10FV1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox10FV1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox10FV1.Location = new System.Drawing.Point(423, 494);
            this.textBox10FV1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox10FV1.Name = "textBox10FV1";
            this.textBox10FV1.ReadOnly = true;
            this.textBox10FV1.Size = new System.Drawing.Size(78, 21);
            this.textBox10FV1.TabIndex = 939;
            this.textBox10FV1.TabStop = false;
            // 
            // textBox12ZIPIT1
            // 
            this.textBox12ZIPIT1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox12ZIPIT1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox12ZIPIT1.Location = new System.Drawing.Point(918, 244);
            this.textBox12ZIPIT1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox12ZIPIT1.Name = "textBox12ZIPIT1";
            this.textBox12ZIPIT1.ReadOnly = true;
            this.textBox12ZIPIT1.Size = new System.Drawing.Size(78, 21);
            this.textBox12ZIPIT1.TabIndex = 938;
            this.textBox12ZIPIT1.TabStop = false;
            // 
            // textBox9Ps1
            // 
            this.textBox9Ps1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox9Ps1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox9Ps1.Location = new System.Drawing.Point(225, 307);
            this.textBox9Ps1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox9Ps1.Name = "textBox9Ps1";
            this.textBox9Ps1.ReadOnly = true;
            this.textBox9Ps1.Size = new System.Drawing.Size(78, 21);
            this.textBox9Ps1.TabIndex = 943;
            this.textBox9Ps1.TabStop = false;
            // 
            // textBox11Bio1
            // 
            this.textBox11Bio1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox11Bio1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox11Bio1.Location = new System.Drawing.Point(621, 389);
            this.textBox11Bio1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox11Bio1.Name = "textBox11Bio1";
            this.textBox11Bio1.ReadOnly = true;
            this.textBox11Bio1.Size = new System.Drawing.Size(78, 21);
            this.textBox11Bio1.TabIndex = 942;
            this.textBox11Bio1.TabStop = false;
            // 
            // textBoxdipBio1
            // 
            this.textBoxdipBio1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxdipBio1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxdipBio1.Location = new System.Drawing.Point(1017, 389);
            this.textBoxdipBio1.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxdipBio1.Name = "textBoxdipBio1";
            this.textBoxdipBio1.ReadOnly = true;
            this.textBoxdipBio1.Size = new System.Drawing.Size(78, 21);
            this.textBoxdipBio1.TabIndex = 941;
            this.textBoxdipBio1.TabStop = false;
            // 
            // textBox10ZIPIT1
            // 
            this.textBox10ZIPIT1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox10ZIPIT1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox10ZIPIT1.Location = new System.Drawing.Point(522, 245);
            this.textBox10ZIPIT1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox10ZIPIT1.Name = "textBox10ZIPIT1";
            this.textBox10ZIPIT1.ReadOnly = true;
            this.textBox10ZIPIT1.Size = new System.Drawing.Size(78, 21);
            this.textBox10ZIPIT1.TabIndex = 937;
            this.textBox10ZIPIT1.TabStop = false;
            // 
            // textBox12Bio1
            // 
            this.textBox12Bio1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox12Bio1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox12Bio1.Location = new System.Drawing.Point(819, 389);
            this.textBox12Bio1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox12Bio1.Name = "textBox12Bio1";
            this.textBox12Bio1.ReadOnly = true;
            this.textBox12Bio1.Size = new System.Drawing.Size(78, 21);
            this.textBox12Bio1.TabIndex = 933;
            this.textBox12Bio1.TabStop = false;
            // 
            // textBox9FV1
            // 
            this.textBox9FV1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox9FV1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox9FV1.Location = new System.Drawing.Point(225, 494);
            this.textBox9FV1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox9FV1.Name = "textBox9FV1";
            this.textBox9FV1.ReadOnly = true;
            this.textBox9FV1.Size = new System.Drawing.Size(78, 21);
            this.textBox9FV1.TabIndex = 932;
            this.textBox9FV1.TabStop = false;
            // 
            // textBox302
            // 
            this.textBox302.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox302.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox302.Location = new System.Drawing.Point(621, 327);
            this.textBox302.Margin = new System.Windows.Forms.Padding(0);
            this.textBox302.Name = "textBox302";
            this.textBox302.ReadOnly = true;
            this.textBox302.Size = new System.Drawing.Size(78, 21);
            this.textBox302.TabIndex = 931;
            this.textBox302.TabStop = false;
            // 
            // textBoxdipEt1
            // 
            this.textBoxdipEt1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxdipEt1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxdipEt1.Location = new System.Drawing.Point(1017, 327);
            this.textBoxdipEt1.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxdipEt1.Name = "textBoxdipEt1";
            this.textBoxdipEt1.ReadOnly = true;
            this.textBoxdipEt1.Size = new System.Drawing.Size(78, 21);
            this.textBoxdipEt1.TabIndex = 936;
            this.textBoxdipEt1.TabStop = false;
            // 
            // textBox10Bio1
            // 
            this.textBox10Bio1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox10Bio1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox10Bio1.Location = new System.Drawing.Point(423, 390);
            this.textBox10Bio1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox10Bio1.Name = "textBox10Bio1";
            this.textBox10Bio1.ReadOnly = true;
            this.textBox10Bio1.Size = new System.Drawing.Size(78, 21);
            this.textBox10Bio1.TabIndex = 935;
            this.textBox10Bio1.TabStop = false;
            // 
            // textBox222
            // 
            this.textBox222.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox222.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox222.Location = new System.Drawing.Point(819, 327);
            this.textBox222.Margin = new System.Windows.Forms.Padding(0);
            this.textBox222.Name = "textBox222";
            this.textBox222.ReadOnly = true;
            this.textBox222.Size = new System.Drawing.Size(78, 21);
            this.textBox222.TabIndex = 934;
            this.textBox222.TabStop = false;
            // 
            // textBox9ZIPIT1
            // 
            this.textBox9ZIPIT1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox9ZIPIT1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox9ZIPIT1.Location = new System.Drawing.Point(324, 245);
            this.textBox9ZIPIT1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox9ZIPIT1.Name = "textBox9ZIPIT1";
            this.textBox9ZIPIT1.ReadOnly = true;
            this.textBox9ZIPIT1.Size = new System.Drawing.Size(78, 21);
            this.textBox9ZIPIT1.TabIndex = 917;
            this.textBox9ZIPIT1.TabStop = false;
            // 
            // textBox301
            // 
            this.textBox301.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox301.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox301.Location = new System.Drawing.Point(720, 451);
            this.textBox301.Margin = new System.Windows.Forms.Padding(0);
            this.textBox301.Name = "textBox301";
            this.textBox301.ReadOnly = true;
            this.textBox301.Size = new System.Drawing.Size(78, 21);
            this.textBox301.TabIndex = 891;
            this.textBox301.TabStop = false;
            // 
            // textBoxdipMzZIP1
            // 
            this.textBoxdipMzZIP1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxdipMzZIP1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxdipMzZIP1.Location = new System.Drawing.Point(1125, 451);
            this.textBoxdipMzZIP1.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxdipMzZIP1.Name = "textBoxdipMzZIP1";
            this.textBoxdipMzZIP1.ReadOnly = true;
            this.textBoxdipMzZIP1.Size = new System.Drawing.Size(78, 21);
            this.textBoxdipMzZIP1.TabIndex = 898;
            this.textBoxdipMzZIP1.TabStop = false;
            // 
            // textBox10Et1
            // 
            this.textBox10Et1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox10Et1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox10Et1.Location = new System.Drawing.Point(423, 328);
            this.textBox10Et1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox10Et1.Name = "textBox10Et1";
            this.textBox10Et1.ReadOnly = true;
            this.textBox10Et1.Size = new System.Drawing.Size(78, 21);
            this.textBox10Et1.TabIndex = 897;
            this.textBox10Et1.TabStop = false;
            // 
            // textBox221
            // 
            this.textBox221.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox221.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox221.Location = new System.Drawing.Point(918, 451);
            this.textBox221.Margin = new System.Windows.Forms.Padding(0);
            this.textBox221.Name = "textBox221";
            this.textBox221.ReadOnly = true;
            this.textBox221.Size = new System.Drawing.Size(78, 21);
            this.textBox221.TabIndex = 896;
            this.textBox221.TabStop = false;
            // 
            // textBox9Bio1
            // 
            this.textBox9Bio1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox9Bio1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox9Bio1.Location = new System.Drawing.Point(225, 390);
            this.textBox9Bio1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox9Bio1.Name = "textBox9Bio1";
            this.textBox9Bio1.ReadOnly = true;
            this.textBox9Bio1.Size = new System.Drawing.Size(78, 21);
            this.textBox9Bio1.TabIndex = 899;
            this.textBox9Bio1.TabStop = false;
            // 
            // textBox11Inf1
            // 
            this.textBox11Inf1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox11Inf1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox11Inf1.Location = new System.Drawing.Point(621, 223);
            this.textBox11Inf1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox11Inf1.Name = "textBox11Inf1";
            this.textBox11Inf1.ReadOnly = true;
            this.textBox11Inf1.Size = new System.Drawing.Size(78, 21);
            this.textBox11Inf1.TabIndex = 902;
            this.textBox11Inf1.TabStop = false;
            // 
            // textBoxdipInf1
            // 
            this.textBoxdipInf1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxdipInf1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxdipInf1.Location = new System.Drawing.Point(1017, 223);
            this.textBoxdipInf1.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxdipInf1.Name = "textBoxdipInf1";
            this.textBoxdipInf1.ReadOnly = true;
            this.textBoxdipInf1.Size = new System.Drawing.Size(78, 21);
            this.textBoxdipInf1.TabIndex = 901;
            this.textBoxdipInf1.TabStop = false;
            // 
            // textBox141
            // 
            this.textBox141.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox141.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox141.Location = new System.Drawing.Point(522, 452);
            this.textBox141.Margin = new System.Windows.Forms.Padding(0);
            this.textBox141.Name = "textBox141";
            this.textBox141.ReadOnly = true;
            this.textBox141.Size = new System.Drawing.Size(78, 21);
            this.textBox141.TabIndex = 900;
            this.textBox141.TabStop = false;
            // 
            // textBox12Inf1
            // 
            this.textBox12Inf1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox12Inf1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox12Inf1.Location = new System.Drawing.Point(819, 223);
            this.textBox12Inf1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox12Inf1.Name = "textBox12Inf1";
            this.textBox12Inf1.ReadOnly = true;
            this.textBox12Inf1.Size = new System.Drawing.Size(78, 21);
            this.textBox12Inf1.TabIndex = 893;
            this.textBox12Inf1.TabStop = false;
            // 
            // textBox9Et1
            // 
            this.textBox9Et1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox9Et1.Enabled = false;
            this.textBox9Et1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox9Et1.Location = new System.Drawing.Point(225, 328);
            this.textBox9Et1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox9Et1.Name = "textBox9Et1";
            this.textBox9Et1.ReadOnly = true;
            this.textBox9Et1.Size = new System.Drawing.Size(78, 21);
            this.textBox9Et1.TabIndex = 895;
            this.textBox9Et1.TabStop = false;
            // 
            // textBox11Fz1
            // 
            this.textBox11Fz1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox11Fz1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox11Fz1.Location = new System.Drawing.Point(621, 410);
            this.textBox11Fz1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox11Fz1.Name = "textBox11Fz1";
            this.textBox11Fz1.ReadOnly = true;
            this.textBox11Fz1.Size = new System.Drawing.Size(78, 21);
            this.textBox11Fz1.TabIndex = 892;
            this.textBox11Fz1.TabStop = false;
            // 
            // textBoxdipFz1
            // 
            this.textBoxdipFz1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxdipFz1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxdipFz1.Location = new System.Drawing.Point(1017, 410);
            this.textBoxdipFz1.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxdipFz1.Name = "textBoxdipFz1";
            this.textBoxdipFz1.ReadOnly = true;
            this.textBoxdipFz1.Size = new System.Drawing.Size(78, 21);
            this.textBoxdipFz1.TabIndex = 894;
            this.textBoxdipFz1.TabStop = false;
            // 
            // textBox10Inf1
            // 
            this.textBox10Inf1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox10Inf1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox10Inf1.Location = new System.Drawing.Point(423, 224);
            this.textBox10Inf1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox10Inf1.Name = "textBox10Inf1";
            this.textBox10Inf1.ReadOnly = true;
            this.textBox10Inf1.Size = new System.Drawing.Size(78, 21);
            this.textBox10Inf1.TabIndex = 912;
            this.textBox10Inf1.TabStop = false;
            // 
            // textBox12Fz1
            // 
            this.textBox12Fz1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox12Fz1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox12Fz1.Location = new System.Drawing.Point(819, 410);
            this.textBox12Fz1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox12Fz1.Name = "textBox12Fz1";
            this.textBox12Fz1.ReadOnly = true;
            this.textBox12Fz1.Size = new System.Drawing.Size(78, 21);
            this.textBox12Fz1.TabIndex = 911;
            this.textBox12Fz1.TabStop = false;
            // 
            // textBox75
            // 
            this.textBox75.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox75.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox75.Location = new System.Drawing.Point(324, 452);
            this.textBox75.Margin = new System.Windows.Forms.Padding(0);
            this.textBox75.Name = "textBox75";
            this.textBox75.ReadOnly = true;
            this.textBox75.Size = new System.Drawing.Size(78, 21);
            this.textBox75.TabIndex = 910;
            this.textBox75.TabStop = false;
            // 
            // textBox11ZIPG1
            // 
            this.textBox11ZIPG1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox11ZIPG1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox11ZIPG1.Location = new System.Drawing.Point(720, 285);
            this.textBox11ZIPG1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox11ZIPG1.Name = "textBox11ZIPG1";
            this.textBox11ZIPG1.ReadOnly = true;
            this.textBox11ZIPG1.Size = new System.Drawing.Size(78, 21);
            this.textBox11ZIPG1.TabIndex = 913;
            this.textBox11ZIPG1.TabStop = false;
            // 
            // textBoxdipGZIP1
            // 
            this.textBoxdipGZIP1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxdipGZIP1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxdipGZIP1.Location = new System.Drawing.Point(1125, 285);
            this.textBoxdipGZIP1.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxdipGZIP1.Name = "textBoxdipGZIP1";
            this.textBoxdipGZIP1.ReadOnly = true;
            this.textBoxdipGZIP1.Size = new System.Drawing.Size(78, 21);
            this.textBoxdipGZIP1.TabIndex = 916;
            this.textBoxdipGZIP1.TabStop = false;
            // 
            // textBox10Fz1
            // 
            this.textBox10Fz1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox10Fz1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox10Fz1.Location = new System.Drawing.Point(423, 411);
            this.textBox10Fz1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox10Fz1.Name = "textBox10Fz1";
            this.textBox10Fz1.ReadOnly = true;
            this.textBox10Fz1.Size = new System.Drawing.Size(78, 21);
            this.textBox10Fz1.TabIndex = 914;
            this.textBox10Fz1.TabStop = false;
            // 
            // textBox12ZIPG1
            // 
            this.textBox12ZIPG1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox12ZIPG1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox12ZIPG1.Location = new System.Drawing.Point(918, 285);
            this.textBox12ZIPG1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox12ZIPG1.Name = "textBox12ZIPG1";
            this.textBox12ZIPG1.ReadOnly = true;
            this.textBox12ZIPG1.Size = new System.Drawing.Size(78, 21);
            this.textBox12ZIPG1.TabIndex = 903;
            this.textBox12ZIPG1.TabStop = false;
            // 
            // textBox9Inf1
            // 
            this.textBox9Inf1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox9Inf1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox9Inf1.Location = new System.Drawing.Point(225, 224);
            this.textBox9Inf1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox9Inf1.Name = "textBox9Inf1";
            this.textBox9Inf1.ReadOnly = true;
            this.textBox9Inf1.Size = new System.Drawing.Size(78, 21);
            this.textBox9Inf1.TabIndex = 909;
            this.textBox9Inf1.TabStop = false;
            // 
            // textBox297
            // 
            this.textBox297.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox297.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox297.Location = new System.Drawing.Point(621, 451);
            this.textBox297.Margin = new System.Windows.Forms.Padding(0);
            this.textBox297.Name = "textBox297";
            this.textBox297.ReadOnly = true;
            this.textBox297.Size = new System.Drawing.Size(78, 21);
            this.textBox297.TabIndex = 907;
            this.textBox297.TabStop = false;
            // 
            // textBoxdipMz1
            // 
            this.textBoxdipMz1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxdipMz1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxdipMz1.Location = new System.Drawing.Point(1017, 451);
            this.textBoxdipMz1.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxdipMz1.Name = "textBoxdipMz1";
            this.textBoxdipMz1.ReadOnly = true;
            this.textBoxdipMz1.Size = new System.Drawing.Size(78, 21);
            this.textBoxdipMz1.TabIndex = 908;
            this.textBoxdipMz1.TabStop = false;
            // 
            // textBox10ZIPG1
            // 
            this.textBox10ZIPG1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox10ZIPG1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox10ZIPG1.Location = new System.Drawing.Point(522, 286);
            this.textBox10ZIPG1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox10ZIPG1.Name = "textBox10ZIPG1";
            this.textBox10ZIPG1.ReadOnly = true;
            this.textBox10ZIPG1.Size = new System.Drawing.Size(78, 21);
            this.textBox10ZIPG1.TabIndex = 906;
            this.textBox10ZIPG1.TabStop = false;
            // 
            // textBox217
            // 
            this.textBox217.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox217.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox217.Location = new System.Drawing.Point(819, 451);
            this.textBox217.Margin = new System.Windows.Forms.Padding(0);
            this.textBox217.Name = "textBox217";
            this.textBox217.ReadOnly = true;
            this.textBox217.Size = new System.Drawing.Size(78, 21);
            this.textBox217.TabIndex = 904;
            this.textBox217.TabStop = false;
            // 
            // textBox9Fz1
            // 
            this.textBox9Fz1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox9Fz1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox9Fz1.Location = new System.Drawing.Point(225, 411);
            this.textBox9Fz1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox9Fz1.Name = "textBox9Fz1";
            this.textBox9Fz1.ReadOnly = true;
            this.textBox9Fz1.Size = new System.Drawing.Size(78, 21);
            this.textBox9Fz1.TabIndex = 905;
            this.textBox9Fz1.TabStop = false;
            // 
            // textBox11IT1
            // 
            this.textBox11IT1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox11IT1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox11IT1.Location = new System.Drawing.Point(621, 244);
            this.textBox11IT1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox11IT1.Name = "textBox11IT1";
            this.textBox11IT1.ReadOnly = true;
            this.textBox11IT1.Size = new System.Drawing.Size(78, 21);
            this.textBox11IT1.TabIndex = 915;
            this.textBox11IT1.TabStop = false;
            // 
            // textBoxdipIT1
            // 
            this.textBoxdipIT1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxdipIT1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxdipIT1.Location = new System.Drawing.Point(1017, 244);
            this.textBoxdipIT1.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxdipIT1.Name = "textBoxdipIT1";
            this.textBoxdipIT1.ReadOnly = true;
            this.textBoxdipIT1.Size = new System.Drawing.Size(78, 21);
            this.textBoxdipIT1.TabIndex = 980;
            this.textBoxdipIT1.TabStop = false;
            // 
            // textBox137
            // 
            this.textBox137.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox137.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox137.Location = new System.Drawing.Point(423, 452);
            this.textBox137.Margin = new System.Windows.Forms.Padding(0);
            this.textBox137.Name = "textBox137";
            this.textBox137.ReadOnly = true;
            this.textBox137.Size = new System.Drawing.Size(78, 21);
            this.textBox137.TabIndex = 979;
            this.textBox137.TabStop = false;
            // 
            // textBox12IT1
            // 
            this.textBox12IT1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox12IT1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox12IT1.Location = new System.Drawing.Point(819, 244);
            this.textBox12IT1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox12IT1.Name = "textBox12IT1";
            this.textBox12IT1.ReadOnly = true;
            this.textBox12IT1.Size = new System.Drawing.Size(78, 21);
            this.textBox12IT1.TabIndex = 978;
            this.textBox12IT1.TabStop = false;
            // 
            // textBox9ZIPG1
            // 
            this.textBox9ZIPG1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox9ZIPG1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox9ZIPG1.Location = new System.Drawing.Point(324, 286);
            this.textBox9ZIPG1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox9ZIPG1.Name = "textBox9ZIPG1";
            this.textBox9ZIPG1.ReadOnly = true;
            this.textBox9ZIPG1.Size = new System.Drawing.Size(78, 21);
            this.textBox9ZIPG1.TabIndex = 983;
            this.textBox9ZIPG1.TabStop = false;
            // 
            // textBox295
            // 
            this.textBox295.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox295.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox295.Location = new System.Drawing.Point(720, 368);
            this.textBox295.Margin = new System.Windows.Forms.Padding(0);
            this.textBox295.Name = "textBox295";
            this.textBox295.ReadOnly = true;
            this.textBox295.Size = new System.Drawing.Size(78, 21);
            this.textBox295.TabIndex = 982;
            this.textBox295.TabStop = false;
            // 
            // textBoxdipSvZIP1
            // 
            this.textBoxdipSvZIP1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxdipSvZIP1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxdipSvZIP1.Location = new System.Drawing.Point(1125, 368);
            this.textBoxdipSvZIP1.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxdipSvZIP1.Name = "textBoxdipSvZIP1";
            this.textBoxdipSvZIP1.ReadOnly = true;
            this.textBoxdipSvZIP1.Size = new System.Drawing.Size(78, 21);
            this.textBoxdipSvZIP1.TabIndex = 981;
            this.textBoxdipSvZIP1.TabStop = false;
            // 
            // textBox10IT1
            // 
            this.textBox10IT1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox10IT1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox10IT1.Location = new System.Drawing.Point(423, 245);
            this.textBox10IT1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox10IT1.Name = "textBox10IT1";
            this.textBox10IT1.ReadOnly = true;
            this.textBox10IT1.Size = new System.Drawing.Size(78, 21);
            this.textBox10IT1.TabIndex = 977;
            this.textBox10IT1.TabStop = false;
            // 
            // textBox12ZIPSv1
            // 
            this.textBox12ZIPSv1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox12ZIPSv1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox12ZIPSv1.Location = new System.Drawing.Point(918, 368);
            this.textBox12ZIPSv1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox12ZIPSv1.Name = "textBox12ZIPSv1";
            this.textBox12ZIPSv1.ReadOnly = true;
            this.textBox12ZIPSv1.Size = new System.Drawing.Size(78, 21);
            this.textBox12ZIPSv1.TabIndex = 973;
            this.textBox12ZIPSv1.TabStop = false;
            // 
            // textBox9Mz1
            // 
            this.textBox9Mz1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox9Mz1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox9Mz1.Location = new System.Drawing.Point(225, 452);
            this.textBox9Mz1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox9Mz1.Name = "textBox9Mz1";
            this.textBox9Mz1.ReadOnly = true;
            this.textBox9Mz1.Size = new System.Drawing.Size(78, 21);
            this.textBox9Mz1.TabIndex = 972;
            this.textBox9Mz1.TabStop = false;
            // 
            // textBox11G1
            // 
            this.textBox11G1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox11G1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox11G1.Location = new System.Drawing.Point(621, 285);
            this.textBox11G1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox11G1.Name = "textBox11G1";
            this.textBox11G1.ReadOnly = true;
            this.textBox11G1.Size = new System.Drawing.Size(78, 21);
            this.textBox11G1.TabIndex = 971;
            this.textBox11G1.TabStop = false;
            // 
            // textBoxdipG1
            // 
            this.textBoxdipG1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxdipG1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxdipG1.Location = new System.Drawing.Point(1017, 285);
            this.textBoxdipG1.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxdipG1.Name = "textBoxdipG1";
            this.textBoxdipG1.ReadOnly = true;
            this.textBoxdipG1.Size = new System.Drawing.Size(78, 21);
            this.textBoxdipG1.TabIndex = 976;
            this.textBoxdipG1.TabStop = false;
            // 
            // textBox135
            // 
            this.textBox135.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox135.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox135.Location = new System.Drawing.Point(522, 369);
            this.textBox135.Margin = new System.Windows.Forms.Padding(0);
            this.textBox135.Name = "textBox135";
            this.textBox135.ReadOnly = true;
            this.textBox135.Size = new System.Drawing.Size(78, 21);
            this.textBox135.TabIndex = 975;
            this.textBox135.TabStop = false;
            // 
            // textBox12G1
            // 
            this.textBox12G1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox12G1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox12G1.Location = new System.Drawing.Point(819, 285);
            this.textBox12G1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox12G1.Name = "textBox12G1";
            this.textBox12G1.ReadOnly = true;
            this.textBox12G1.Size = new System.Drawing.Size(78, 21);
            this.textBox12G1.TabIndex = 974;
            this.textBox12G1.TabStop = false;
            // 
            // textBox9IT1
            // 
            this.textBox9IT1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox9IT1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox9IT1.Location = new System.Drawing.Point(225, 245);
            this.textBox9IT1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox9IT1.Name = "textBox9IT1";
            this.textBox9IT1.ReadOnly = true;
            this.textBox9IT1.Size = new System.Drawing.Size(78, 21);
            this.textBox9IT1.TabIndex = 993;
            this.textBox9IT1.TabStop = false;
            // 
            // textBox293
            // 
            this.textBox293.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox293.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox293.Location = new System.Drawing.Point(621, 368);
            this.textBox293.Margin = new System.Windows.Forms.Padding(0);
            this.textBox293.Name = "textBox293";
            this.textBox293.ReadOnly = true;
            this.textBox293.Size = new System.Drawing.Size(78, 21);
            this.textBox293.TabIndex = 992;
            this.textBox293.TabStop = false;
            // 
            // textBoxdipSv1
            // 
            this.textBoxdipSv1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxdipSv1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxdipSv1.Location = new System.Drawing.Point(1017, 368);
            this.textBoxdipSv1.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxdipSv1.Name = "textBoxdipSv1";
            this.textBoxdipSv1.ReadOnly = true;
            this.textBoxdipSv1.Size = new System.Drawing.Size(78, 21);
            this.textBoxdipSv1.TabIndex = 991;
            this.textBoxdipSv1.TabStop = false;
            // 
            // textBox10G1
            // 
            this.textBox10G1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox10G1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox10G1.Location = new System.Drawing.Point(423, 286);
            this.textBox10G1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox10G1.Name = "textBox10G1";
            this.textBox10G1.ReadOnly = true;
            this.textBox10G1.Size = new System.Drawing.Size(78, 21);
            this.textBox10G1.TabIndex = 996;
            this.textBox10G1.TabStop = false;
            // 
            // textBox12Sv1
            // 
            this.textBox12Sv1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox12Sv1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox12Sv1.Location = new System.Drawing.Point(819, 368);
            this.textBox12Sv1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox12Sv1.Name = "textBox12Sv1";
            this.textBox12Sv1.ReadOnly = true;
            this.textBox12Sv1.Size = new System.Drawing.Size(78, 21);
            this.textBox12Sv1.TabIndex = 995;
            this.textBox12Sv1.TabStop = false;
            // 
            // textBox72
            // 
            this.textBox72.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox72.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox72.Location = new System.Drawing.Point(324, 369);
            this.textBox72.Margin = new System.Windows.Forms.Padding(0);
            this.textBox72.Name = "textBox72";
            this.textBox72.ReadOnly = true;
            this.textBox72.Size = new System.Drawing.Size(78, 21);
            this.textBox72.TabIndex = 994;
            this.textBox72.TabStop = false;
            // 
            // textBox11ZIPMat1
            // 
            this.textBox11ZIPMat1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox11ZIPMat1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox11ZIPMat1.Location = new System.Drawing.Point(720, 202);
            this.textBox11ZIPMat1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox11ZIPMat1.Name = "textBox11ZIPMat1";
            this.textBox11ZIPMat1.ReadOnly = true;
            this.textBox11ZIPMat1.Size = new System.Drawing.Size(78, 21);
            this.textBox11ZIPMat1.TabIndex = 990;
            this.textBox11ZIPMat1.TabStop = false;
            // 
            // textBoxdipMatZIP1
            // 
            this.textBoxdipMatZIP1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxdipMatZIP1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxdipMatZIP1.Location = new System.Drawing.Point(1125, 202);
            this.textBoxdipMatZIP1.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxdipMatZIP1.Name = "textBoxdipMatZIP1";
            this.textBoxdipMatZIP1.ReadOnly = true;
            this.textBoxdipMatZIP1.Size = new System.Drawing.Size(78, 21);
            this.textBoxdipMatZIP1.TabIndex = 986;
            this.textBoxdipMatZIP1.TabStop = false;
            // 
            // textBox133
            // 
            this.textBox133.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox133.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox133.Location = new System.Drawing.Point(423, 369);
            this.textBox133.Margin = new System.Windows.Forms.Padding(0);
            this.textBox133.Name = "textBox133";
            this.textBox133.ReadOnly = true;
            this.textBox133.Size = new System.Drawing.Size(78, 21);
            this.textBox133.TabIndex = 985;
            this.textBox133.TabStop = false;
            // 
            // textBox12ZIPMat1
            // 
            this.textBox12ZIPMat1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox12ZIPMat1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox12ZIPMat1.Location = new System.Drawing.Point(918, 202);
            this.textBox12ZIPMat1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox12ZIPMat1.Name = "textBox12ZIPMat1";
            this.textBox12ZIPMat1.ReadOnly = true;
            this.textBox12ZIPMat1.Size = new System.Drawing.Size(78, 21);
            this.textBox12ZIPMat1.TabIndex = 984;
            this.textBox12ZIPMat1.TabStop = false;
            // 
            // textBox9G1
            // 
            this.textBox9G1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox9G1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox9G1.Location = new System.Drawing.Point(225, 286);
            this.textBox9G1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox9G1.Name = "textBox9G1";
            this.textBox9G1.ReadOnly = true;
            this.textBox9G1.Size = new System.Drawing.Size(78, 21);
            this.textBox9G1.TabIndex = 989;
            this.textBox9G1.TabStop = false;
            // 
            // textBox11Mat1
            // 
            this.textBox11Mat1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox11Mat1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox11Mat1.Location = new System.Drawing.Point(621, 202);
            this.textBox11Mat1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox11Mat1.Name = "textBox11Mat1";
            this.textBox11Mat1.ReadOnly = true;
            this.textBox11Mat1.Size = new System.Drawing.Size(78, 21);
            this.textBox11Mat1.TabIndex = 988;
            this.textBox11Mat1.TabStop = false;
            // 
            // textBoxdipMat1
            // 
            this.textBoxdipMat1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxdipMat1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxdipMat1.Location = new System.Drawing.Point(1017, 202);
            this.textBoxdipMat1.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxdipMat1.Name = "textBoxdipMat1";
            this.textBoxdipMat1.ReadOnly = true;
            this.textBoxdipMat1.Size = new System.Drawing.Size(78, 21);
            this.textBoxdipMat1.TabIndex = 987;
            this.textBoxdipMat1.TabStop = false;
            // 
            // textBox10ZIPMat1
            // 
            this.textBox10ZIPMat1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox10ZIPMat1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox10ZIPMat1.Location = new System.Drawing.Point(522, 203);
            this.textBox10ZIPMat1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox10ZIPMat1.Name = "textBox10ZIPMat1";
            this.textBox10ZIPMat1.ReadOnly = true;
            this.textBox10ZIPMat1.Size = new System.Drawing.Size(78, 21);
            this.textBox10ZIPMat1.TabIndex = 970;
            this.textBox10ZIPMat1.TabStop = false;
            // 
            // textBox12Mat1
            // 
            this.textBox12Mat1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox12Mat1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox12Mat1.Location = new System.Drawing.Point(819, 202);
            this.textBox12Mat1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox12Mat1.Name = "textBox12Mat1";
            this.textBox12Mat1.ReadOnly = true;
            this.textBox12Mat1.Size = new System.Drawing.Size(78, 21);
            this.textBox12Mat1.TabIndex = 953;
            this.textBox12Mat1.TabStop = false;
            // 
            // textBox71
            // 
            this.textBox71.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox71.Enabled = false;
            this.textBox71.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox71.Location = new System.Drawing.Point(225, 369);
            this.textBox71.Margin = new System.Windows.Forms.Padding(0);
            this.textBox71.Name = "textBox71";
            this.textBox71.ReadOnly = true;
            this.textBox71.Size = new System.Drawing.Size(78, 21);
            this.textBox71.TabIndex = 952;
            this.textBox71.TabStop = false;
            // 
            // textBox11ZIP3
            // 
            this.textBox11ZIP3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox11ZIP3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox11ZIP3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox11ZIP3.Location = new System.Drawing.Point(798, 181);
            this.textBox11ZIP3.Margin = new System.Windows.Forms.Padding(0);
            this.textBox11ZIP3.Name = "textBox11ZIP3";
            this.textBox11ZIP3.Size = new System.Drawing.Size(21, 21);
            this.textBox11ZIP3.TabIndex = 80;
            this.textBox11ZIP3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox11ZIP3.TextChanged += new System.EventHandler(this.textBox11ZIP3_TextChanged);
            this.textBox11ZIP3.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBoxdipZIP3
            // 
            this.textBoxdipZIP3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBoxdipZIP3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxdipZIP3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxdipZIP3.Location = new System.Drawing.Point(1203, 182);
            this.textBoxdipZIP3.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxdipZIP3.Name = "textBoxdipZIP3";
            this.textBoxdipZIP3.ReadOnly = true;
            this.textBoxdipZIP3.Size = new System.Drawing.Size(30, 21);
            this.textBoxdipZIP3.TabIndex = 132;
            this.textBoxdipZIP3.TabStop = false;
            this.textBoxdipZIP3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBoxdipZIP3.TextChanged += new System.EventHandler(this.textBoxdipZIP3_TextChanged);
            this.textBoxdipZIP3.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox10Mat1
            // 
            this.textBox10Mat1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox10Mat1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox10Mat1.Location = new System.Drawing.Point(423, 203);
            this.textBox10Mat1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox10Mat1.Name = "textBox10Mat1";
            this.textBox10Mat1.ReadOnly = true;
            this.textBox10Mat1.Size = new System.Drawing.Size(78, 21);
            this.textBox10Mat1.TabIndex = 955;
            this.textBox10Mat1.TabStop = false;
            // 
            // textBox12ZIP3
            // 
            this.textBox12ZIP3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox12ZIP3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox12ZIP3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox12ZIP3.Location = new System.Drawing.Point(996, 182);
            this.textBox12ZIP3.Margin = new System.Windows.Forms.Padding(0);
            this.textBox12ZIP3.Name = "textBox12ZIP3";
            this.textBox12ZIP3.Size = new System.Drawing.Size(21, 21);
            this.textBox12ZIP3.TabIndex = 103;
            this.textBox12ZIP3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox12ZIP3.TextChanged += new System.EventHandler(this.textBox12ZIP3_TextChanged);
            this.textBox12ZIP3.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox9ZIPMat1
            // 
            this.textBox9ZIPMat1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox9ZIPMat1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox9ZIPMat1.Location = new System.Drawing.Point(324, 203);
            this.textBox9ZIPMat1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox9ZIPMat1.Name = "textBox9ZIPMat1";
            this.textBox9ZIPMat1.ReadOnly = true;
            this.textBox9ZIPMat1.Size = new System.Drawing.Size(78, 21);
            this.textBox9ZIPMat1.TabIndex = 954;
            this.textBox9ZIPMat1.TabStop = false;
            // 
            // textBox11ZP3
            // 
            this.textBox11ZP3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox11ZP3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox11ZP3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox11ZP3.Location = new System.Drawing.Point(699, 181);
            this.textBox11ZP3.Margin = new System.Windows.Forms.Padding(0);
            this.textBox11ZP3.Name = "textBox11ZP3";
            this.textBox11ZP3.Size = new System.Drawing.Size(21, 21);
            this.textBox11ZP3.TabIndex = 66;
            this.textBox11ZP3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox11ZP3.TextChanged += new System.EventHandler(this.textBox11ZP3_TextChanged);
            this.textBox11ZP3.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBoxdipZP3
            // 
            this.textBoxdipZP3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBoxdipZP3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxdipZP3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxdipZP3.Location = new System.Drawing.Point(1095, 182);
            this.textBoxdipZP3.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxdipZP3.Name = "textBoxdipZP3";
            this.textBoxdipZP3.ReadOnly = true;
            this.textBoxdipZP3.Size = new System.Drawing.Size(30, 21);
            this.textBoxdipZP3.TabIndex = 113;
            this.textBoxdipZP3.TabStop = false;
            this.textBoxdipZP3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBoxdipZP3.TextChanged += new System.EventHandler(this.textBoxdipZP3_TextChanged);
            this.textBoxdipZP3.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox10ZIP3
            // 
            this.textBox10ZIP3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox10ZIP3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox10ZIP3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox10ZIP3.Location = new System.Drawing.Point(600, 182);
            this.textBox10ZIP3.Margin = new System.Windows.Forms.Padding(0);
            this.textBox10ZIP3.Name = "textBox10ZIP3";
            this.textBox10ZIP3.Size = new System.Drawing.Size(21, 21);
            this.textBox10ZIP3.TabIndex = 54;
            this.textBox10ZIP3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox10ZIP3.TextChanged += new System.EventHandler(this.textBox10ZIP3_TextChanged);
            this.textBox10ZIP3.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox12ZP3
            // 
            this.textBox12ZP3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox12ZP3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox12ZP3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox12ZP3.Location = new System.Drawing.Point(897, 182);
            this.textBox12ZP3.Margin = new System.Windows.Forms.Padding(0);
            this.textBox12ZP3.Name = "textBox12ZP3";
            this.textBox12ZP3.Size = new System.Drawing.Size(21, 21);
            this.textBox12ZP3.TabIndex = 89;
            this.textBox12ZP3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox12ZP3.TextChanged += new System.EventHandler(this.textBox12ZP3_TextChanged);
            this.textBox12ZP3.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox9Mat1
            // 
            this.textBox9Mat1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox9Mat1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox9Mat1.Location = new System.Drawing.Point(225, 203);
            this.textBox9Mat1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox9Mat1.Name = "textBox9Mat1";
            this.textBox9Mat1.ReadOnly = true;
            this.textBox9Mat1.Size = new System.Drawing.Size(78, 21);
            this.textBox9Mat1.TabIndex = 949;
            this.textBox9Mat1.TabStop = false;
            // 
            // textBox11ZIP2
            // 
            this.textBox11ZIP2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox11ZIP2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox11ZIP2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox11ZIP2.Location = new System.Drawing.Point(798, 159);
            this.textBox11ZIP2.Margin = new System.Windows.Forms.Padding(0);
            this.textBox11ZIP2.Name = "textBox11ZIP2";
            this.textBox11ZIP2.Size = new System.Drawing.Size(21, 21);
            this.textBox11ZIP2.TabIndex = 79;
            this.textBox11ZIP2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox11ZIP2.TextChanged += new System.EventHandler(this.textBox11ZIP2_TextChanged);
            this.textBox11ZIP2.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBoxdipZIP2
            // 
            this.textBoxdipZIP2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBoxdipZIP2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxdipZIP2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxdipZIP2.Location = new System.Drawing.Point(1203, 160);
            this.textBoxdipZIP2.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxdipZIP2.Name = "textBoxdipZIP2";
            this.textBoxdipZIP2.ReadOnly = true;
            this.textBoxdipZIP2.Size = new System.Drawing.Size(30, 21);
            this.textBoxdipZIP2.TabIndex = 131;
            this.textBoxdipZIP2.TabStop = false;
            this.textBoxdipZIP2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBoxdipZIP2.TextChanged += new System.EventHandler(this.textBoxdipZIP2_TextChanged);
            this.textBoxdipZIP2.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox10ZP3
            // 
            this.textBox10ZP3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox10ZP3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox10ZP3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox10ZP3.Location = new System.Drawing.Point(501, 182);
            this.textBox10ZP3.Margin = new System.Windows.Forms.Padding(0);
            this.textBox10ZP3.Name = "textBox10ZP3";
            this.textBox10ZP3.Size = new System.Drawing.Size(21, 21);
            this.textBox10ZP3.TabIndex = 36;
            this.textBox10ZP3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox10ZP3.TextChanged += new System.EventHandler(this.textBox10ZP3_TextChanged);
            this.textBox10ZP3.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox12ZIP2
            // 
            this.textBox12ZIP2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox12ZIP2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox12ZIP2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox12ZIP2.Location = new System.Drawing.Point(996, 160);
            this.textBox12ZIP2.Margin = new System.Windows.Forms.Padding(0);
            this.textBox12ZIP2.Name = "textBox12ZIP2";
            this.textBox12ZIP2.Size = new System.Drawing.Size(21, 21);
            this.textBox12ZIP2.TabIndex = 102;
            this.textBox12ZIP2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox12ZIP2.TextChanged += new System.EventHandler(this.textBox12ZIP2_TextChanged);
            this.textBox12ZIP2.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox9ZIP3
            // 
            this.textBox9ZIP3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox9ZIP3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox9ZIP3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox9ZIP3.Location = new System.Drawing.Point(402, 182);
            this.textBox9ZIP3.Margin = new System.Windows.Forms.Padding(0);
            this.textBox9ZIP3.Name = "textBox9ZIP3";
            this.textBox9ZIP3.Size = new System.Drawing.Size(21, 21);
            this.textBox9ZIP3.TabIndex = 22;
            this.textBox9ZIP3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox9ZIP3.TextChanged += new System.EventHandler(this.textBox9ZIP3_TextChanged);
            this.textBox9ZIP3.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox11ZP2
            // 
            this.textBox11ZP2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox11ZP2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox11ZP2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox11ZP2.Location = new System.Drawing.Point(699, 159);
            this.textBox11ZP2.Margin = new System.Windows.Forms.Padding(0);
            this.textBox11ZP2.Name = "textBox11ZP2";
            this.textBox11ZP2.Size = new System.Drawing.Size(21, 21);
            this.textBox11ZP2.TabIndex = 65;
            this.textBox11ZP2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox11ZP2.TextChanged += new System.EventHandler(this.textBox11ZP2_TextChanged);
            this.textBox11ZP2.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBoxdipZP2
            // 
            this.textBoxdipZP2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBoxdipZP2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxdipZP2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxdipZP2.Location = new System.Drawing.Point(1095, 160);
            this.textBoxdipZP2.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxdipZP2.Name = "textBoxdipZP2";
            this.textBoxdipZP2.ReadOnly = true;
            this.textBoxdipZP2.Size = new System.Drawing.Size(30, 21);
            this.textBoxdipZP2.TabIndex = 112;
            this.textBoxdipZP2.TabStop = false;
            this.textBoxdipZP2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBoxdipZP2.TextChanged += new System.EventHandler(this.textBoxdipZP2_TextChanged);
            this.textBoxdipZP2.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox10ZIP2
            // 
            this.textBox10ZIP2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox10ZIP2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox10ZIP2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox10ZIP2.Location = new System.Drawing.Point(600, 160);
            this.textBox10ZIP2.Margin = new System.Windows.Forms.Padding(0);
            this.textBox10ZIP2.Name = "textBox10ZIP2";
            this.textBox10ZIP2.Size = new System.Drawing.Size(21, 21);
            this.textBox10ZIP2.TabIndex = 53;
            this.textBox10ZIP2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox10ZIP2.TextChanged += new System.EventHandler(this.textBox10ZIP2_TextChanged);
            this.textBox10ZIP2.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox12ZP2
            // 
            this.textBox12ZP2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox12ZP2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox12ZP2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox12ZP2.Location = new System.Drawing.Point(897, 160);
            this.textBox12ZP2.Margin = new System.Windows.Forms.Padding(0);
            this.textBox12ZP2.Name = "textBox12ZP2";
            this.textBox12ZP2.Size = new System.Drawing.Size(21, 21);
            this.textBox12ZP2.TabIndex = 88;
            this.textBox12ZP2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox12ZP2.TextChanged += new System.EventHandler(this.textBox12ZP2_TextChanged);
            this.textBox12ZP2.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox9ZP3
            // 
            this.textBox9ZP3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox9ZP3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox9ZP3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox9ZP3.Location = new System.Drawing.Point(303, 182);
            this.textBox9ZP3.Margin = new System.Windows.Forms.Padding(0);
            this.textBox9ZP3.Name = "textBox9ZP3";
            this.textBox9ZP3.Size = new System.Drawing.Size(21, 21);
            this.textBox9ZP3.TabIndex = 3;
            this.textBox9ZP3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox9ZP3.TextChanged += new System.EventHandler(this.textBox9ZP3_TextChanged);
            this.textBox9ZP3.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox11ZIP1
            // 
            this.textBox11ZIP1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox11ZIP1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox11ZIP1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox11ZIP1.Location = new System.Drawing.Point(798, 139);
            this.textBox11ZIP1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox11ZIP1.Name = "textBox11ZIP1";
            this.textBox11ZIP1.Size = new System.Drawing.Size(21, 20);
            this.textBox11ZIP1.TabIndex = 78;
            this.textBox11ZIP1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox11ZIP1.TextChanged += new System.EventHandler(this.textBox11ZIP1_TextChanged);
            this.textBox11ZIP1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBoxdipZIP1
            // 
            this.textBoxdipZIP1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBoxdipZIP1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxdipZIP1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxdipZIP1.Location = new System.Drawing.Point(1203, 140);
            this.textBoxdipZIP1.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxdipZIP1.Name = "textBoxdipZIP1";
            this.textBoxdipZIP1.ReadOnly = true;
            this.textBoxdipZIP1.Size = new System.Drawing.Size(30, 20);
            this.textBoxdipZIP1.TabIndex = 130;
            this.textBoxdipZIP1.TabStop = false;
            this.textBoxdipZIP1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBoxdipZIP1.TextChanged += new System.EventHandler(this.textBoxdipZIP1_TextChanged);
            this.textBoxdipZIP1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox10ZP2
            // 
            this.textBox10ZP2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox10ZP2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox10ZP2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox10ZP2.Location = new System.Drawing.Point(501, 160);
            this.textBox10ZP2.Margin = new System.Windows.Forms.Padding(0);
            this.textBox10ZP2.Name = "textBox10ZP2";
            this.textBox10ZP2.Size = new System.Drawing.Size(21, 21);
            this.textBox10ZP2.TabIndex = 35;
            this.textBox10ZP2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox10ZP2.TextChanged += new System.EventHandler(this.textBox10ZP2_TextChanged);
            this.textBox10ZP2.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox12ZIP1
            // 
            this.textBox12ZIP1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox12ZIP1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox12ZIP1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox12ZIP1.Location = new System.Drawing.Point(996, 140);
            this.textBox12ZIP1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox12ZIP1.Name = "textBox12ZIP1";
            this.textBox12ZIP1.Size = new System.Drawing.Size(21, 20);
            this.textBox12ZIP1.TabIndex = 101;
            this.textBox12ZIP1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox12ZIP1.TextChanged += new System.EventHandler(this.textBox12ZIP1_TextChanged);
            this.textBox12ZIP1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox9ZIP2
            // 
            this.textBox9ZIP2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox9ZIP2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox9ZIP2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox9ZIP2.Location = new System.Drawing.Point(402, 160);
            this.textBox9ZIP2.Margin = new System.Windows.Forms.Padding(0);
            this.textBox9ZIP2.Name = "textBox9ZIP2";
            this.textBox9ZIP2.Size = new System.Drawing.Size(21, 21);
            this.textBox9ZIP2.TabIndex = 21;
            this.textBox9ZIP2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox9ZIP2.TextChanged += new System.EventHandler(this.textBox9ZIP2_TextChanged);
            this.textBox9ZIP2.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox11ZP1
            // 
            this.textBox11ZP1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox11ZP1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox11ZP1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox11ZP1.Location = new System.Drawing.Point(699, 139);
            this.textBox11ZP1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox11ZP1.Name = "textBox11ZP1";
            this.textBox11ZP1.Size = new System.Drawing.Size(21, 20);
            this.textBox11ZP1.TabIndex = 64;
            this.textBox11ZP1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox11ZP1.TextChanged += new System.EventHandler(this.textBox11ZP1_TextChanged);
            this.textBox11ZP1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBoxdipZP1
            // 
            this.textBoxdipZP1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBoxdipZP1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxdipZP1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxdipZP1.Location = new System.Drawing.Point(1095, 140);
            this.textBoxdipZP1.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxdipZP1.Name = "textBoxdipZP1";
            this.textBoxdipZP1.ReadOnly = true;
            this.textBoxdipZP1.Size = new System.Drawing.Size(30, 20);
            this.textBoxdipZP1.TabIndex = 111;
            this.textBoxdipZP1.TabStop = false;
            this.textBoxdipZP1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBoxdipZP1.TextChanged += new System.EventHandler(this.textBoxdipZP1_TextChanged);
            this.textBoxdipZP1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox10ZIP1
            // 
            this.textBox10ZIP1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox10ZIP1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox10ZIP1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox10ZIP1.Location = new System.Drawing.Point(600, 140);
            this.textBox10ZIP1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox10ZIP1.Name = "textBox10ZIP1";
            this.textBox10ZIP1.Size = new System.Drawing.Size(21, 20);
            this.textBox10ZIP1.TabIndex = 52;
            this.textBox10ZIP1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox10ZIP1.TextChanged += new System.EventHandler(this.textBox10ZIP1_TextChanged);
            this.textBox10ZIP1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox12ZP1
            // 
            this.textBox12ZP1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox12ZP1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox12ZP1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox12ZP1.Location = new System.Drawing.Point(897, 140);
            this.textBox12ZP1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox12ZP1.Name = "textBox12ZP1";
            this.textBox12ZP1.Size = new System.Drawing.Size(21, 20);
            this.textBox12ZP1.TabIndex = 87;
            this.textBox12ZP1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox12ZP1.TextChanged += new System.EventHandler(this.textBox12ZP1_TextChanged);
            this.textBox12ZP1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox9ZP2
            // 
            this.textBox9ZP2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox9ZP2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox9ZP2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox9ZP2.Location = new System.Drawing.Point(303, 160);
            this.textBox9ZP2.Margin = new System.Windows.Forms.Padding(0);
            this.textBox9ZP2.Name = "textBox9ZP2";
            this.textBox9ZP2.Size = new System.Drawing.Size(21, 21);
            this.textBox9ZP2.TabIndex = 2;
            this.textBox9ZP2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox9ZP2.TextChanged += new System.EventHandler(this.textBox9ZP2_TextChanged);
            this.textBox9ZP2.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox11ZIP2Lang1
            // 
            this.textBox11ZIP2Lang1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox11ZIP2Lang1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox11ZIP2Lang1.Location = new System.Drawing.Point(720, 180);
            this.textBox11ZIP2Lang1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox11ZIP2Lang1.Multiline = true;
            this.textBox11ZIP2Lang1.Name = "textBox11ZIP2Lang1";
            this.textBox11ZIP2Lang1.ReadOnly = true;
            this.textBox11ZIP2Lang1.Size = new System.Drawing.Size(78, 22);
            this.textBox11ZIP2Lang1.TabIndex = 969;
            this.textBox11ZIP2Lang1.TabStop = false;
            // 
            // textBoxdip2LangZIP1
            // 
            this.textBoxdip2LangZIP1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxdip2LangZIP1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxdip2LangZIP1.Location = new System.Drawing.Point(1125, 182);
            this.textBoxdip2LangZIP1.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxdip2LangZIP1.Multiline = true;
            this.textBoxdip2LangZIP1.Name = "textBoxdip2LangZIP1";
            this.textBoxdip2LangZIP1.ReadOnly = true;
            this.textBoxdip2LangZIP1.Size = new System.Drawing.Size(78, 21);
            this.textBoxdip2LangZIP1.TabIndex = 968;
            this.textBoxdip2LangZIP1.TabStop = false;
            // 
            // textBox10ZP1
            // 
            this.textBox10ZP1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox10ZP1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox10ZP1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox10ZP1.Location = new System.Drawing.Point(501, 140);
            this.textBox10ZP1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox10ZP1.Name = "textBox10ZP1";
            this.textBox10ZP1.Size = new System.Drawing.Size(21, 20);
            this.textBox10ZP1.TabIndex = 34;
            this.textBox10ZP1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox10ZP1.TextChanged += new System.EventHandler(this.textBox10ZP1_TextChanged);
            this.textBox10ZP1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox12ZIP2Lang1
            // 
            this.textBox12ZIP2Lang1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox12ZIP2Lang1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox12ZIP2Lang1.Location = new System.Drawing.Point(918, 182);
            this.textBox12ZIP2Lang1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox12ZIP2Lang1.Multiline = true;
            this.textBox12ZIP2Lang1.Name = "textBox12ZIP2Lang1";
            this.textBox12ZIP2Lang1.ReadOnly = true;
            this.textBox12ZIP2Lang1.Size = new System.Drawing.Size(78, 22);
            this.textBox12ZIP2Lang1.TabIndex = 967;
            this.textBox12ZIP2Lang1.TabStop = false;
            // 
            // textBox9ZIP1
            // 
            this.textBox9ZIP1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox9ZIP1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox9ZIP1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox9ZIP1.Location = new System.Drawing.Point(402, 142);
            this.textBox9ZIP1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox9ZIP1.Name = "textBox9ZIP1";
            this.textBox9ZIP1.Size = new System.Drawing.Size(21, 20);
            this.textBox9ZIP1.TabIndex = 20;
            this.textBox9ZIP1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox9ZIP1.TextChanged += new System.EventHandler(this.textBox9ZIP1_TextChanged);
            this.textBox9ZIP1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox112Lang1
            // 
            this.textBox112Lang1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox112Lang1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox112Lang1.Location = new System.Drawing.Point(621, 182);
            this.textBox112Lang1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox112Lang1.Multiline = true;
            this.textBox112Lang1.Name = "textBox112Lang1";
            this.textBox112Lang1.ReadOnly = true;
            this.textBox112Lang1.Size = new System.Drawing.Size(78, 21);
            this.textBox112Lang1.TabIndex = 959;
            this.textBox112Lang1.TabStop = false;
            // 
            // textBoxdip2Lang1
            // 
            this.textBoxdip2Lang1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxdip2Lang1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxdip2Lang1.Location = new System.Drawing.Point(1017, 182);
            this.textBoxdip2Lang1.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxdip2Lang1.Multiline = true;
            this.textBoxdip2Lang1.Name = "textBoxdip2Lang1";
            this.textBoxdip2Lang1.ReadOnly = true;
            this.textBoxdip2Lang1.Size = new System.Drawing.Size(78, 21);
            this.textBoxdip2Lang1.TabIndex = 958;
            this.textBoxdip2Lang1.TabStop = false;
            // 
            // textBox10ZIP2Lang1
            // 
            this.textBox10ZIP2Lang1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox10ZIP2Lang1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox10ZIP2Lang1.Location = new System.Drawing.Point(522, 182);
            this.textBox10ZIP2Lang1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox10ZIP2Lang1.Multiline = true;
            this.textBox10ZIP2Lang1.Name = "textBox10ZIP2Lang1";
            this.textBox10ZIP2Lang1.ReadOnly = true;
            this.textBox10ZIP2Lang1.Size = new System.Drawing.Size(78, 22);
            this.textBox10ZIP2Lang1.TabIndex = 957;
            this.textBox10ZIP2Lang1.TabStop = false;
            // 
            // textBox122Lang1
            // 
            this.textBox122Lang1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox122Lang1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox122Lang1.Location = new System.Drawing.Point(819, 182);
            this.textBox122Lang1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox122Lang1.Multiline = true;
            this.textBox122Lang1.Name = "textBox122Lang1";
            this.textBox122Lang1.ReadOnly = true;
            this.textBox122Lang1.Size = new System.Drawing.Size(78, 22);
            this.textBox122Lang1.TabIndex = 962;
            this.textBox122Lang1.TabStop = false;
            // 
            // textBox9ZP1
            // 
            this.textBox9ZP1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(232)))), ((int)(((byte)(226)))));
            this.textBox9ZP1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox9ZP1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox9ZP1.Location = new System.Drawing.Point(303, 140);
            this.textBox9ZP1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox9ZP1.Name = "textBox9ZP1";
            this.textBox9ZP1.Size = new System.Drawing.Size(21, 20);
            this.textBox9ZP1.TabIndex = 1;
            this.textBox9ZP1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox9ZP1.TextChanged += new System.EventHandler(this.textBox9ZP1_TextChanged);
            this.textBox9ZP1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.General_KeyDown);
            // 
            // textBox11ZIP1Lang1
            // 
            this.textBox11ZIP1Lang1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox11ZIP1Lang1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox11ZIP1Lang1.Location = new System.Drawing.Point(720, 158);
            this.textBox11ZIP1Lang1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox11ZIP1Lang1.Multiline = true;
            this.textBox11ZIP1Lang1.Name = "textBox11ZIP1Lang1";
            this.textBox11ZIP1Lang1.ReadOnly = true;
            this.textBox11ZIP1Lang1.Size = new System.Drawing.Size(78, 22);
            this.textBox11ZIP1Lang1.TabIndex = 960;
            this.textBox11ZIP1Lang1.TabStop = false;
            // 
            // textBoxdip1LangZIP1
            // 
            this.textBoxdip1LangZIP1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxdip1LangZIP1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxdip1LangZIP1.Location = new System.Drawing.Point(1125, 160);
            this.textBoxdip1LangZIP1.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxdip1LangZIP1.Multiline = true;
            this.textBoxdip1LangZIP1.Name = "textBoxdip1LangZIP1";
            this.textBoxdip1LangZIP1.ReadOnly = true;
            this.textBoxdip1LangZIP1.Size = new System.Drawing.Size(78, 22);
            this.textBoxdip1LangZIP1.TabIndex = 1036;
            this.textBoxdip1LangZIP1.TabStop = false;
            // 
            // textBox102Lang1
            // 
            this.textBox102Lang1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox102Lang1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox102Lang1.Location = new System.Drawing.Point(423, 182);
            this.textBox102Lang1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox102Lang1.Multiline = true;
            this.textBox102Lang1.Name = "textBox102Lang1";
            this.textBox102Lang1.ReadOnly = true;
            this.textBox102Lang1.Size = new System.Drawing.Size(78, 22);
            this.textBox102Lang1.TabIndex = 1004;
            this.textBox102Lang1.TabStop = false;
            // 
            // textBox121LangZIP1
            // 
            this.textBox121LangZIP1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox121LangZIP1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox121LangZIP1.Location = new System.Drawing.Point(918, 160);
            this.textBox121LangZIP1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox121LangZIP1.Multiline = true;
            this.textBox121LangZIP1.Name = "textBox121LangZIP1";
            this.textBox121LangZIP1.ReadOnly = true;
            this.textBox121LangZIP1.Size = new System.Drawing.Size(78, 22);
            this.textBox121LangZIP1.TabIndex = 1005;
            this.textBox121LangZIP1.TabStop = false;
            // 
            // textBox92LangZIP1
            // 
            this.textBox92LangZIP1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox92LangZIP1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox92LangZIP1.Location = new System.Drawing.Point(324, 181);
            this.textBox92LangZIP1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox92LangZIP1.Multiline = true;
            this.textBox92LangZIP1.Name = "textBox92LangZIP1";
            this.textBox92LangZIP1.ReadOnly = true;
            this.textBox92LangZIP1.Size = new System.Drawing.Size(78, 22);
            this.textBox92LangZIP1.TabIndex = 1015;
            this.textBox92LangZIP1.TabStop = false;
            // 
            // textBox111Lang1
            // 
            this.textBox111Lang1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox111Lang1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox111Lang1.Location = new System.Drawing.Point(621, 160);
            this.textBox111Lang1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox111Lang1.Multiline = true;
            this.textBox111Lang1.Name = "textBox111Lang1";
            this.textBox111Lang1.ReadOnly = true;
            this.textBox111Lang1.Size = new System.Drawing.Size(78, 22);
            this.textBox111Lang1.TabIndex = 1007;
            this.textBox111Lang1.TabStop = false;
            // 
            // textBoxdip1Lang1
            // 
            this.textBoxdip1Lang1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxdip1Lang1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxdip1Lang1.Location = new System.Drawing.Point(1017, 160);
            this.textBoxdip1Lang1.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxdip1Lang1.Multiline = true;
            this.textBoxdip1Lang1.Name = "textBoxdip1Lang1";
            this.textBoxdip1Lang1.ReadOnly = true;
            this.textBoxdip1Lang1.Size = new System.Drawing.Size(78, 22);
            this.textBoxdip1Lang1.TabIndex = 1038;
            this.textBoxdip1Lang1.TabStop = false;
            // 
            // textBox10ZIP1Lang1
            // 
            this.textBox10ZIP1Lang1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox10ZIP1Lang1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox10ZIP1Lang1.Location = new System.Drawing.Point(522, 160);
            this.textBox10ZIP1Lang1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox10ZIP1Lang1.Multiline = true;
            this.textBox10ZIP1Lang1.Name = "textBox10ZIP1Lang1";
            this.textBox10ZIP1Lang1.ReadOnly = true;
            this.textBox10ZIP1Lang1.Size = new System.Drawing.Size(78, 22);
            this.textBox10ZIP1Lang1.TabIndex = 951;
            this.textBox10ZIP1Lang1.TabStop = false;
            // 
            // textBox121Lang1
            // 
            this.textBox121Lang1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox121Lang1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox121Lang1.Location = new System.Drawing.Point(819, 160);
            this.textBox121Lang1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox121Lang1.Multiline = true;
            this.textBox121Lang1.Name = "textBox121Lang1";
            this.textBox121Lang1.ReadOnly = true;
            this.textBox121Lang1.Size = new System.Drawing.Size(78, 22);
            this.textBox121Lang1.TabIndex = 956;
            this.textBox121Lang1.TabStop = false;
            // 
            // textBox92Lang1
            // 
            this.textBox92Lang1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox92Lang1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox92Lang1.Location = new System.Drawing.Point(225, 181);
            this.textBox92Lang1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox92Lang1.Multiline = true;
            this.textBox92Lang1.Name = "textBox92Lang1";
            this.textBox92Lang1.ReadOnly = true;
            this.textBox92Lang1.Size = new System.Drawing.Size(78, 22);
            this.textBox92Lang1.TabIndex = 1141;
            this.textBox92Lang1.TabStop = false;
            // 
            // textBox11BelZIP1
            // 
            this.textBox11BelZIP1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox11BelZIP1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox11BelZIP1.Location = new System.Drawing.Point(720, 139);
            this.textBox11BelZIP1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox11BelZIP1.Name = "textBox11BelZIP1";
            this.textBox11BelZIP1.ReadOnly = true;
            this.textBox11BelZIP1.Size = new System.Drawing.Size(78, 21);
            this.textBox11BelZIP1.TabIndex = 950;
            this.textBox11BelZIP1.TabStop = false;
            // 
            // textBoxdipBELZIP1
            // 
            this.textBoxdipBELZIP1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxdipBELZIP1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxdipBELZIP1.Location = new System.Drawing.Point(1125, 140);
            this.textBoxdipBELZIP1.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxdipBELZIP1.Name = "textBoxdipBELZIP1";
            this.textBoxdipBELZIP1.ReadOnly = true;
            this.textBoxdipBELZIP1.Size = new System.Drawing.Size(78, 21);
            this.textBoxdipBELZIP1.TabIndex = 946;
            this.textBoxdipBELZIP1.TabStop = false;
            // 
            // textBox101Lang1
            // 
            this.textBox101Lang1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox101Lang1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox101Lang1.Location = new System.Drawing.Point(423, 160);
            this.textBox101Lang1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox101Lang1.Multiline = true;
            this.textBox101Lang1.Name = "textBox101Lang1";
            this.textBox101Lang1.ReadOnly = true;
            this.textBox101Lang1.Size = new System.Drawing.Size(78, 22);
            this.textBox101Lang1.TabIndex = 945;
            this.textBox101Lang1.TabStop = false;
            // 
            // textBox12BelZIP1
            // 
            this.textBox12BelZIP1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox12BelZIP1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox12BelZIP1.Location = new System.Drawing.Point(918, 140);
            this.textBox12BelZIP1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox12BelZIP1.Name = "textBox12BelZIP1";
            this.textBox12BelZIP1.ReadOnly = true;
            this.textBox12BelZIP1.Size = new System.Drawing.Size(78, 21);
            this.textBox12BelZIP1.TabIndex = 944;
            this.textBox12BelZIP1.TabStop = false;
            // 
            // textBox9ZIP1Lang1
            // 
            this.textBox9ZIP1Lang1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox9ZIP1Lang1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox9ZIP1Lang1.Location = new System.Drawing.Point(324, 160);
            this.textBox9ZIP1Lang1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox9ZIP1Lang1.Multiline = true;
            this.textBox9ZIP1Lang1.Name = "textBox9ZIP1Lang1";
            this.textBox9ZIP1Lang1.ReadOnly = true;
            this.textBox9ZIP1Lang1.Size = new System.Drawing.Size(78, 21);
            this.textBox9ZIP1Lang1.TabIndex = 948;
            this.textBox9ZIP1Lang1.TabStop = false;
            // 
            // textBox11Bel1
            // 
            this.textBox11Bel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox11Bel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox11Bel1.Location = new System.Drawing.Point(621, 140);
            this.textBox11Bel1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox11Bel1.Name = "textBox11Bel1";
            this.textBox11Bel1.ReadOnly = true;
            this.textBox11Bel1.Size = new System.Drawing.Size(78, 21);
            this.textBox11Bel1.TabIndex = 947;
            this.textBox11Bel1.TabStop = false;
            // 
            // textBoxdipBEL1
            // 
            this.textBoxdipBEL1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxdipBEL1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxdipBEL1.Location = new System.Drawing.Point(1017, 140);
            this.textBoxdipBEL1.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxdipBEL1.Name = "textBoxdipBEL1";
            this.textBoxdipBEL1.ReadOnly = true;
            this.textBoxdipBEL1.Size = new System.Drawing.Size(78, 21);
            this.textBoxdipBEL1.TabIndex = 966;
            this.textBoxdipBEL1.TabStop = false;
            // 
            // textBox10BelZIP1
            // 
            this.textBox10BelZIP1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox10BelZIP1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox10BelZIP1.Location = new System.Drawing.Point(522, 140);
            this.textBox10BelZIP1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox10BelZIP1.Name = "textBox10BelZIP1";
            this.textBox10BelZIP1.ReadOnly = true;
            this.textBox10BelZIP1.Size = new System.Drawing.Size(78, 21);
            this.textBox10BelZIP1.TabIndex = 965;
            this.textBox10BelZIP1.TabStop = false;
            // 
            // textBox12Bel1
            // 
            this.textBox12Bel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox12Bel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox12Bel1.Location = new System.Drawing.Point(819, 140);
            this.textBox12Bel1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox12Bel1.Name = "textBox12Bel1";
            this.textBox12Bel1.ReadOnly = true;
            this.textBox12Bel1.Size = new System.Drawing.Size(78, 21);
            this.textBox12Bel1.TabIndex = 964;
            this.textBox12Bel1.TabStop = false;
            // 
            // textBox91Lang1
            // 
            this.textBox91Lang1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox91Lang1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox91Lang1.Location = new System.Drawing.Point(225, 160);
            this.textBox91Lang1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox91Lang1.Multiline = true;
            this.textBox91Lang1.Name = "textBox91Lang1";
            this.textBox91Lang1.ReadOnly = true;
            this.textBox91Lang1.Size = new System.Drawing.Size(78, 21);
            this.textBox91Lang1.TabIndex = 1140;
            this.textBox91Lang1.TabStop = false;
            // 
            // textBox10Bel1
            // 
            this.textBox10Bel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox10Bel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox10Bel1.Location = new System.Drawing.Point(423, 140);
            this.textBox10Bel1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox10Bel1.Name = "textBox10Bel1";
            this.textBox10Bel1.ReadOnly = true;
            this.textBox10Bel1.Size = new System.Drawing.Size(78, 21);
            this.textBox10Bel1.TabIndex = 963;
            this.textBox10Bel1.TabStop = false;
            // 
            // textBox9BelZIP1
            // 
            this.textBox9BelZIP1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox9BelZIP1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox9BelZIP1.Location = new System.Drawing.Point(324, 140);
            this.textBox9BelZIP1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox9BelZIP1.Name = "textBox9BelZIP1";
            this.textBox9BelZIP1.ReadOnly = true;
            this.textBox9BelZIP1.Size = new System.Drawing.Size(78, 21);
            this.textBox9BelZIP1.TabIndex = 961;
            this.textBox9BelZIP1.TabStop = false;
            // 
            // textBox9Bel1
            // 
            this.textBox9Bel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox9Bel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox9Bel1.Location = new System.Drawing.Point(225, 140);
            this.textBox9Bel1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox9Bel1.Name = "textBox9Bel1";
            this.textBox9Bel1.ReadOnly = true;
            this.textBox9Bel1.Size = new System.Drawing.Size(78, 21);
            this.textBox9Bel1.TabIndex = 1139;
            this.textBox9Bel1.TabStop = false;
            // 
            // comboBox2Lang
            // 
            this.comboBox2Lang.BackColor = System.Drawing.SystemColors.Control;
            this.comboBox2Lang.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.comboBox2Lang.FormattingEnabled = true;
            this.comboBox2Lang.Location = new System.Drawing.Point(35, 182);
            this.comboBox2Lang.Margin = new System.Windows.Forms.Padding(0);
            this.comboBox2Lang.Name = "comboBox2Lang";
            this.comboBox2Lang.Size = new System.Drawing.Size(188, 21);
            this.comboBox2Lang.Sorted = true;
            this.comboBox2Lang.TabIndex = 1122;
            this.comboBox2Lang.TabStop = false;
            this.comboBox2Lang.Text = "Втори чужд език  ";
            this.comboBox2Lang.SelectedIndexChanged += new System.EventHandler(this.comboBox2Lang_SelectedIndexChanged);
            // 
            // buttonClose
            // 
            this.buttonClose.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonClose.Image = global::E_school.Properties.Resources.Button_Close_icon;
            this.buttonClose.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonClose.Location = new System.Drawing.Point(1136, 832);
            this.buttonClose.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.buttonClose.Name = "buttonClose";
            this.buttonClose.Size = new System.Drawing.Size(92, 35);
            this.buttonClose.TabIndex = 1000;
            this.buttonClose.Text = "Затвори";
            this.buttonClose.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttonClose.UseVisualStyleBackColor = true;
            this.buttonClose.Click += new System.EventHandler(this.buttonClose_Click);
            // 
            // textBoxName
            // 
            this.textBoxName.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxName.Location = new System.Drawing.Point(101, 18);
            this.textBoxName.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxName.Name = "textBoxName";
            this.textBoxName.ReadOnly = true;
            this.textBoxName.Size = new System.Drawing.Size(297, 31);
            this.textBoxName.TabIndex = 600;
            this.textBoxName.TabStop = false;
            // 
            // textBoxNumber
            // 
            this.textBoxNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxNumber.Location = new System.Drawing.Point(46, 18);
            this.textBoxNumber.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxNumber.Name = "textBoxNumber";
            this.textBoxNumber.ReadOnly = true;
            this.textBoxNumber.Size = new System.Drawing.Size(47, 31);
            this.textBoxNumber.TabIndex = 700;
            this.textBoxNumber.TabStop = false;
            // 
            // buttonShow
            // 
            this.buttonShow.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonShow.Location = new System.Drawing.Point(783, 12);
            this.buttonShow.Name = "buttonShow";
            this.buttonShow.Size = new System.Drawing.Size(177, 28);
            this.buttonShow.TabIndex = 0;
            this.buttonShow.Text = "Покaжи оценките на ученика\r\n";
            this.buttonShow.UseVisualStyleBackColor = true;
            this.buttonShow.Click += new System.EventHandler(this.buttonShow_Click);
            // 
            // textBoxSrUspeh
            // 
            this.textBoxSrUspeh.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxSrUspeh.Location = new System.Drawing.Point(717, 18);
            this.textBoxSrUspeh.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxSrUspeh.Name = "textBoxSrUspeh";
            this.textBoxSrUspeh.ReadOnly = true;
            this.textBoxSrUspeh.Size = new System.Drawing.Size(61, 29);
            this.textBoxSrUspeh.TabIndex = 700;
            this.textBoxSrUspeh.TabStop = false;
            this.textBoxSrUspeh.TextChanged += new System.EventHandler(this.textBoxSrUspeh_TextChanged);
            // 
            // textBoxSrUspehW
            // 
            this.textBoxSrUspehW.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxSrUspehW.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxSrUspehW.Location = new System.Drawing.Point(595, 25);
            this.textBoxSrUspehW.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxSrUspehW.Name = "textBoxSrUspehW";
            this.textBoxSrUspehW.ReadOnly = true;
            this.textBoxSrUspehW.Size = new System.Drawing.Size(118, 17);
            this.textBoxSrUspehW.TabIndex = 590;
            this.textBoxSrUspehW.TabStop = false;
            // 
            // buttonEdit
            // 
            this.buttonEdit.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonEdit.Image = global::E_school.Properties.Resources.Pencil_icon;
            this.buttonEdit.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonEdit.Location = new System.Drawing.Point(783, 46);
            this.buttonEdit.Name = "buttonEdit";
            this.buttonEdit.Size = new System.Drawing.Size(177, 28);
            this.buttonEdit.TabIndex = 801;
            this.buttonEdit.Text = "Промяна на оценки";
            this.buttonEdit.UseVisualStyleBackColor = true;
            this.buttonEdit.Click += new System.EventHandler(this.buttonEdit_Click);
            // 
            // tabPage1
            // 
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1242, 724);
            this.tabPage1.TabIndex = 2;
            this.tabPage1.Text = "tabPage1";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // FormStudent2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackgroundImage = global::E_school.Properties.Resources.school1;
            this.ClientSize = new System.Drawing.Size(1062, 741);
            this.Controls.Add(this.buttonEdit);
            this.Controls.Add(this.buttonSaveSuccess);
            this.Controls.Add(this.buttonShow);
            this.Controls.Add(this.textBoxSrUspeh);
            this.Controls.Add(this.textBoxNumber);
            this.Controls.Add(this.textBoxName);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBoxSrUspehW);
            this.Controls.Add(this.buttonClose);
            this.KeyPreview = true;
            this.Name = "FormStudent2";
            this.Text = "Информация за ученика:";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.FormStudent2_Load);
            this.tabPageDZI_SIP.ResumeLayout(false);
            this.tabPageDZI_SIP.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPageUspeh.ResumeLayout(false);
            this.tabPageUspeh.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TabPage tabPageDZI_SIP;
        private System.Windows.Forms.TextBox textBoxOkon3;
        private System.Windows.Forms.TextBox textBox12SIP3;
        private System.Windows.Forms.TextBox textBox11SIP3;
        private System.Windows.Forms.TextBox textBox10SIP3;
        private System.Windows.Forms.TextBox textBox9SIP3;
        private System.Windows.Forms.TextBox textBoxOkon1;
        private System.Windows.Forms.TextBox textBox12SIP1;
        private System.Windows.Forms.TextBox textBox11SIP1;
        private System.Windows.Forms.TextBox textBox10SIP1;
        private System.Windows.Forms.TextBox textBox9SIP1;
        private System.Windows.Forms.TextBox textBoxOkon2;
        private System.Windows.Forms.TextBox textBox12SIP2;
        private System.Windows.Forms.TextBox textBox11SIP2;
        private System.Windows.Forms.TextBox textBox10SIP2;
        private System.Windows.Forms.TextBox textBox9SIP2;
        private System.Windows.Forms.TextBox textBoxOkW3;
        private System.Windows.Forms.TextBox textBox12SIPw3;
        private System.Windows.Forms.TextBox textBox11SIPw3;
        private System.Windows.Forms.TextBox textBox10SIPw3;
        private System.Windows.Forms.TextBox textBoxOkW1;
        private System.Windows.Forms.TextBox textBox12SIPw1;
        private System.Windows.Forms.TextBox textBox11SIPw1;
        private System.Windows.Forms.TextBox textBox10SIPw1;
        private System.Windows.Forms.TextBox textBoxOkW2;
        private System.Windows.Forms.TextBox textBox12SIPw2;
        private System.Windows.Forms.TextBox textBox11SIPw2;
        private System.Windows.Forms.TextBox textBox10SIPw2;
        private System.Windows.Forms.TextBox textBox466;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPageUspeh;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBoxStuName;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox600;
        private System.Windows.Forms.TextBox textBox358;
        private System.Windows.Forms.TextBox textBox409;
        private System.Windows.Forms.TextBox textBox278;
        private System.Windows.Forms.TextBox textBox357;
        private System.Windows.Forms.TextBox textBox408;
        private System.Windows.Forms.TextBox textBox277;
        private System.Windows.Forms.TextBox textBox198;
        private System.Windows.Forms.TextBox textBox525;
        private System.Windows.Forms.TextBox textBox356;
        private System.Windows.Forms.TextBox textBox197;
        private System.Windows.Forms.TextBox textBox407;
        private System.Windows.Forms.TextBox textBox801;
        private System.Windows.Forms.TextBox textBox196;
        private System.Windows.Forms.TextBox textBox900;
        private System.Windows.Forms.TextBox textBox800;
        private System.Windows.Forms.TextBox textBoxFil;
        private System.Windows.Forms.TextBox textBoxIzIzk;
        private System.Windows.Forms.TextBox textBoxPsi;
        private System.Windows.Forms.TextBox textBoxHim;
        private System.Windows.Forms.TextBox textBoxIsto;
        private System.Windows.Forms.TextBox textBoxFVSp;
        private System.Windows.Forms.TextBox textBoxBiol;
        private System.Windows.Forms.TextBox textBoxEtika;
        private System.Windows.Forms.TextBox textBoxInfor;
        private System.Windows.Forms.TextBox textBoxFiz;
        private System.Windows.Forms.TextBox textBox670;
        private System.Windows.Forms.TextBox textBoxMuz;
        private System.Windows.Forms.TextBox textBoxInfT;
        private System.Windows.Forms.TextBox textBox674;
        private System.Windows.Forms.TextBox textBoxGeo;
        private System.Windows.Forms.TextBox textBox676;
        private System.Windows.Forms.TextBox textBox440;
        private System.Windows.Forms.TextBox textBoxSvL;
        private System.Windows.Forms.TextBox textBox650;
        private System.Windows.Forms.TextBox textBox677;
        private System.Windows.Forms.TextBox textBoxMath;
        private System.Windows.Forms.TextBox textBox672;
        private System.Windows.Forms.TextBox textBox640;
        private System.Windows.Forms.TextBox textBox673;
        private System.Windows.Forms.TextBox textBox255;
        private System.Windows.Forms.TextBox textBox675;
        private System.Windows.Forms.TextBox textBox430;
        private System.Windows.Forms.TextBox textBox12Year;
        private System.Windows.Forms.TextBox textBox63;
        private System.Windows.Forms.TextBox textBox11Year;
        private System.Windows.Forms.TextBox textBox671;
        private System.Windows.Forms.TextBox textBoxBel;
        private System.Windows.Forms.TextBox textBox10Year;
        private System.Windows.Forms.TextBox textBox250;
        private System.Windows.Forms.TextBox textBox11ZIP11;
        private System.Windows.Forms.TextBox textBoxdipZIP11;
        private System.Windows.Forms.TextBox textBox9Year;
        private System.Windows.Forms.TextBox textBox12ZIP11;
        private System.Windows.Forms.TextBox textBox11ZIP15;
        private System.Windows.Forms.TextBox textBoxdipZIP15;
        private System.Windows.Forms.TextBox textBox10ZIP11;
        private System.Windows.Forms.TextBox textBox12ZIP15;
        private System.Windows.Forms.TextBox textBox320;
        private System.Windows.Forms.TextBox textBox10ZIP15;
        private System.Windows.Forms.TextBox textBox11ZIP17;
        private System.Windows.Forms.TextBox textBoxdipZIP17;
        private System.Windows.Forms.TextBox textBox9ZIP11;
        private System.Windows.Forms.TextBox textBox12ZIP17;
        private System.Windows.Forms.TextBox textBox9ZIP15;
        private System.Windows.Forms.TextBox textBox11ZIP7;
        private System.Windows.Forms.TextBox textBoxdipZIP7;
        private System.Windows.Forms.TextBox textBox10ZIP17;
        private System.Windows.Forms.TextBox textBox12ZIP7;
        private System.Windows.Forms.TextBox textBox270;
        private System.Windows.Forms.TextBox textBox11ZIP9;
        private System.Windows.Forms.TextBox textBoxdipZIP9;
        private System.Windows.Forms.TextBox textBox10ZIP7;
        private System.Windows.Forms.TextBox textBox12ZIP9;
        private System.Windows.Forms.TextBox textBox9ZIP17;
        private System.Windows.Forms.TextBox textBox10ZIP9;
        private System.Windows.Forms.TextBox textBox9ZIP7;
        private System.Windows.Forms.TextBox textBox11ZIP13;
        private System.Windows.Forms.TextBox textBoxdipZIP13;
        private System.Windows.Forms.TextBox textBox9ZIP9;
        private System.Windows.Forms.TextBox textBox12ZIP13;
        private System.Windows.Forms.TextBox textBox11ZP11;
        private System.Windows.Forms.TextBox textBoxdipZP11;
        private System.Windows.Forms.TextBox textBox10ZIP13;
        private System.Windows.Forms.TextBox textBox12ZP11;
        private System.Windows.Forms.TextBox textBox230;
        private System.Windows.Forms.TextBox textBox11ZP15;
        private System.Windows.Forms.TextBox textBoxdipZP15;
        private System.Windows.Forms.TextBox textBox10ZP11;
        private System.Windows.Forms.TextBox textBox12ZP15;
        private System.Windows.Forms.TextBox textBox9ZIP13;
        private System.Windows.Forms.TextBox textBox11ZIP5;
        private System.Windows.Forms.TextBox textBoxdipZIP5;
        private System.Windows.Forms.TextBox textBox10ZP15;
        private System.Windows.Forms.TextBox textBox12ZIP5;
        private System.Windows.Forms.TextBox textBox9ZP11;
        private System.Windows.Forms.TextBox textBox11ZIP18;
        private System.Windows.Forms.TextBox textBoxdipZIP18;
        private System.Windows.Forms.TextBox textBox10ZIP5;
        private System.Windows.Forms.TextBox textBox12ZIP18;
        private System.Windows.Forms.TextBox textBox9ZP15;
        private System.Windows.Forms.TextBox textBox11ZP7;
        private System.Windows.Forms.TextBox textBoxdipZP7;
        private System.Windows.Forms.TextBox textBox10ZIP18;
        private System.Windows.Forms.TextBox textBox12ZP7;
        private System.Windows.Forms.TextBox textBox9ZIP5;
        private System.Windows.Forms.TextBox textBox11ZIP10;
        private System.Windows.Forms.TextBox textBoxdipZIP10;
        private System.Windows.Forms.TextBox textBox10ZP7;
        private System.Windows.Forms.TextBox textBox12ZIP10;
        private System.Windows.Forms.TextBox textBox9ZIP18;
        private System.Windows.Forms.TextBox textBox11ZP17;
        private System.Windows.Forms.TextBox textBoxdipZP17;
        private System.Windows.Forms.TextBox textBox10ZIP10;
        private System.Windows.Forms.TextBox textBox12ZP17;
        private System.Windows.Forms.TextBox textBox10ZP17;
        private System.Windows.Forms.TextBox textBox11ZIP14;
        private System.Windows.Forms.TextBox textBoxdipZIP14;
        private System.Windows.Forms.TextBox textBox9ZIP10;
        private System.Windows.Forms.TextBox textBox12ZIP14;
        private System.Windows.Forms.TextBox textBox9ZP17;
        private System.Windows.Forms.TextBox textBox11ZP9;
        private System.Windows.Forms.TextBox textBoxdipZP9;
        private System.Windows.Forms.TextBox textBox10ZIP14;
        private System.Windows.Forms.TextBox textBox12ZP9;
        private System.Windows.Forms.TextBox textBox500;
        private System.Windows.Forms.TextBox textBox11ZP18;
        private System.Windows.Forms.TextBox textBoxdipZP18;
        private System.Windows.Forms.TextBox textBox10ZP9;
        private System.Windows.Forms.TextBox textBox12ZP18;
        private System.Windows.Forms.TextBox textBox9ZIP14;
        private System.Windows.Forms.TextBox textBox11ZIP6;
        private System.Windows.Forms.TextBox textBoxdipZIP6;
        private System.Windows.Forms.TextBox textBox10ZP18;
        private System.Windows.Forms.TextBox textBox12ZIP6;
        private System.Windows.Forms.TextBox textBox9ZP9;
        private System.Windows.Forms.TextBox textBox11ZP13;
        private System.Windows.Forms.TextBox textBoxdipZP13;
        private System.Windows.Forms.TextBox textBox10ZIP6;
        private System.Windows.Forms.TextBox textBox12ZP13;
        private System.Windows.Forms.TextBox textBox9ZP18;
        private System.Windows.Forms.TextBox textBox11ZP10;
        private System.Windows.Forms.TextBox textBoxdipZP10;
        private System.Windows.Forms.TextBox textBox10ZP13;
        private System.Windows.Forms.TextBox textBox12ZP10;
        private System.Windows.Forms.TextBox textBox9ZIP6;
        private System.Windows.Forms.TextBox textBox11ZIP16;
        private System.Windows.Forms.TextBox textBoxdipZIP16;
        private System.Windows.Forms.TextBox textBox10ZP10;
        private System.Windows.Forms.TextBox textBox12ZIP16;
        private System.Windows.Forms.TextBox textBox9ZP13;
        private System.Windows.Forms.TextBox textBox11ZP5;
        private System.Windows.Forms.TextBox textBoxdipZP5;
        private System.Windows.Forms.TextBox textBox10ZIP16;
        private System.Windows.Forms.TextBox textBox12ZP5;
        private System.Windows.Forms.TextBox textBox9ZP10;
        private System.Windows.Forms.TextBox textBox11ZP14;
        private System.Windows.Forms.TextBox textBoxdipZP14;
        private System.Windows.Forms.TextBox textBox10ZP5;
        private System.Windows.Forms.TextBox textBox12ZP14;
        private System.Windows.Forms.TextBox textBox9ZIP16;
        private System.Windows.Forms.TextBox textBox11ZIP8;
        private System.Windows.Forms.TextBox textBoxdipZIP8;
        private System.Windows.Forms.TextBox textBox10ZP14;
        private System.Windows.Forms.TextBox textBox12ZIP8;
        private System.Windows.Forms.TextBox textBox9ZP5;
        private System.Windows.Forms.TextBox textBox10ZIP8;
        private System.Windows.Forms.TextBox textBox9ZP14;
        private System.Windows.Forms.TextBox textBox11ZP6;
        private System.Windows.Forms.TextBox textBoxdipZP6;
        private System.Windows.Forms.TextBox textBox12ZP6;
        private System.Windows.Forms.TextBox textBox9ZIP8;
        private System.Windows.Forms.TextBox textBox11ZIP12;
        private System.Windows.Forms.TextBox textBoxdipZIP12;
        private System.Windows.Forms.TextBox textBox10ZP6;
        private System.Windows.Forms.TextBox textBox12ZIP12;
        private System.Windows.Forms.TextBox textBox11ZIPFil1;
        private System.Windows.Forms.TextBox textBoxdipFilZIP1;
        private System.Windows.Forms.TextBox textBox10ZIP12;
        private System.Windows.Forms.TextBox textBox246;
        private System.Windows.Forms.TextBox textBox9ZP6;
        private System.Windows.Forms.TextBox textBox11ZP16;
        private System.Windows.Forms.TextBox textBoxdipZP16;
        private System.Windows.Forms.TextBox textBox166;
        private System.Windows.Forms.TextBox textBox12ZP16;
        private System.Windows.Forms.TextBox textBox9ZIP12;
        private System.Windows.Forms.TextBox textBox11ZIP4;
        private System.Windows.Forms.TextBox textBoxdipZIP4;
        private System.Windows.Forms.TextBox textBox10ZP16;
        private System.Windows.Forms.TextBox textBox12ZIP4;
        private System.Windows.Forms.TextBox textBox55;
        private System.Windows.Forms.TextBox textBox11ZIPHim1;
        private System.Windows.Forms.TextBox textBoxdipHimZIP1;
        private System.Windows.Forms.TextBox textBox10ZIP4;
        private System.Windows.Forms.TextBox textBox12ZIPHim1;
        private System.Windows.Forms.TextBox textBox9ZP16;
        private System.Windows.Forms.TextBox textBox11ZP8;
        private System.Windows.Forms.TextBox textBoxdipZP8;
        private System.Windows.Forms.TextBox textBox10ZIPHim1;
        private System.Windows.Forms.TextBox textBox12ZP8;
        private System.Windows.Forms.TextBox textBox9ZIP4;
        private System.Windows.Forms.TextBox textBox321;
        private System.Windows.Forms.TextBox textBoxdipIzobrZIP1;
        private System.Windows.Forms.TextBox textBox10ZP8;
        private System.Windows.Forms.TextBox textBox241;
        private System.Windows.Forms.TextBox textBox9ZIPHim1;
        private System.Windows.Forms.TextBox textBox11ZIPIst1;
        private System.Windows.Forms.TextBox textBoxdipIstZIP1;
        private System.Windows.Forms.TextBox textBox161;
        private System.Windows.Forms.TextBox textBox12ZIPIst1;
        private System.Windows.Forms.TextBox textBox9ZP8;
        private System.Windows.Forms.TextBox textBox11ZP12;
        private System.Windows.Forms.TextBox textBoxdipZP12;
        private System.Windows.Forms.TextBox textBox10ZIPIst1;
        private System.Windows.Forms.TextBox textBox12ZP12;
        private System.Windows.Forms.TextBox textBox85;
        private System.Windows.Forms.TextBox textBox318;
        private System.Windows.Forms.TextBox textBoxdipPsZIP1;
        private System.Windows.Forms.TextBox textBox10ZP12;
        private System.Windows.Forms.TextBox textBox238;
        private System.Windows.Forms.TextBox textBox9ZIPIst1;
        private System.Windows.Forms.TextBox textBox10ZIPPs1;
        private System.Windows.Forms.TextBox textBox9ZP12;
        private System.Windows.Forms.TextBox textBox11ZP4;
        private System.Windows.Forms.TextBox textBoxdipZP4;
        private System.Windows.Forms.TextBox textBox12ZP4;
        private System.Windows.Forms.TextBox textBox9ZIPPs1;
        private System.Windows.Forms.TextBox textBox11ZIPBio1;
        private System.Windows.Forms.TextBox textBoxdipBioZIP1;
        private System.Windows.Forms.TextBox textBox10ZP4;
        private System.Windows.Forms.TextBox textBox12ZIPBio1;
        private System.Windows.Forms.TextBox textBox11Fil1;
        private System.Windows.Forms.TextBox textBoxdipFil1;
        private System.Windows.Forms.TextBox textBox10ZIPBio1;
        private System.Windows.Forms.TextBox textBox234;
        private System.Windows.Forms.TextBox textBox9ZP4;
        private System.Windows.Forms.TextBox textBox11Him1;
        private System.Windows.Forms.TextBox textBoxdipHim1;
        private System.Windows.Forms.TextBox textBox154;
        private System.Windows.Forms.TextBox textBox12Him1;
        private System.Windows.Forms.TextBox textBox9BioZIP1;
        private System.Windows.Forms.TextBox textBox11ZIPInf1;
        private System.Windows.Forms.TextBox textBoxdipInfZIP1;
        private System.Windows.Forms.TextBox textBox10Him1;
        private System.Windows.Forms.TextBox textBox12ZIPInf1;
        private System.Windows.Forms.TextBox textBox52;
        private System.Windows.Forms.TextBox textBox11ZIPFV1;
        private System.Windows.Forms.TextBox textBoxdipFVZIP1;
        private System.Windows.Forms.TextBox textBox10ZIPInf1;
        private System.Windows.Forms.TextBox textBox231;
        private System.Windows.Forms.TextBox textBox9Him1;
        private System.Windows.Forms.TextBox textBox11Ist1;
        private System.Windows.Forms.TextBox textBoxdipIst1;
        private System.Windows.Forms.TextBox textBox10ZIPFV1;
        private System.Windows.Forms.TextBox textBox12Ist1;
        private System.Windows.Forms.TextBox textBox9ZIPInf1;
        private System.Windows.Forms.TextBox textBox309;
        private System.Windows.Forms.TextBox textBoxdipEtZIP1;
        private System.Windows.Forms.TextBox textBox10Ist1;
        private System.Windows.Forms.TextBox textBox229;
        private System.Windows.Forms.TextBox textBox9ZIPFv1;
        private System.Windows.Forms.TextBox textBox308;
        private System.Windows.Forms.TextBox textBoxdipIzobr1;
        private System.Windows.Forms.TextBox textBox10ZIPEt1;
        private System.Windows.Forms.TextBox textBox228;
        private System.Windows.Forms.TextBox textBox9Ist1;
        private System.Windows.Forms.TextBox textBox148;
        private System.Windows.Forms.TextBox textBox11ZIPFz1;
        private System.Windows.Forms.TextBox textBoxdipFzZIP1;
        private System.Windows.Forms.TextBox textBox9ZIPEt1;
        private System.Windows.Forms.TextBox textBox12ZIPFz1;
        private System.Windows.Forms.TextBox textBox9Izobr1;
        private System.Windows.Forms.TextBox textBox11Ps1;
        private System.Windows.Forms.TextBox textBoxdipPs1;
        private System.Windows.Forms.TextBox textBox10ZIPFz1;
        private System.Windows.Forms.TextBox textBox226;
        private System.Windows.Forms.TextBox textBox11FV1;
        private System.Windows.Forms.TextBox textBoxdipFV1;
        private System.Windows.Forms.TextBox textBox10Ps1;
        private System.Windows.Forms.TextBox textBox12FV1;
        private System.Windows.Forms.TextBox textBox9ZIPFz1;
        private System.Windows.Forms.TextBox textBox11ZIPIT1;
        private System.Windows.Forms.TextBox textBoxdipITZIP1;
        private System.Windows.Forms.TextBox textBox10FV1;
        private System.Windows.Forms.TextBox textBox12ZIPIT1;
        private System.Windows.Forms.TextBox textBox9Ps1;
        private System.Windows.Forms.TextBox textBox11Bio1;
        private System.Windows.Forms.TextBox textBoxdipBio1;
        private System.Windows.Forms.TextBox textBox10ZIPIT1;
        private System.Windows.Forms.TextBox textBox12Bio1;
        private System.Windows.Forms.TextBox textBox9FV1;
        private System.Windows.Forms.TextBox textBox302;
        private System.Windows.Forms.TextBox textBoxdipEt1;
        private System.Windows.Forms.TextBox textBox10Bio1;
        private System.Windows.Forms.TextBox textBox222;
        private System.Windows.Forms.TextBox textBox9ZIPIT1;
        private System.Windows.Forms.TextBox textBox301;
        private System.Windows.Forms.TextBox textBoxdipMzZIP1;
        private System.Windows.Forms.TextBox textBox10Et1;
        private System.Windows.Forms.TextBox textBox221;
        private System.Windows.Forms.TextBox textBox9Bio1;
        private System.Windows.Forms.TextBox textBox11Inf1;
        private System.Windows.Forms.TextBox textBoxdipInf1;
        private System.Windows.Forms.TextBox textBox141;
        private System.Windows.Forms.TextBox textBox12Inf1;
        private System.Windows.Forms.TextBox textBox9Et1;
        private System.Windows.Forms.TextBox textBox11Fz1;
        private System.Windows.Forms.TextBox textBoxdipFz1;
        private System.Windows.Forms.TextBox textBox10Inf1;
        private System.Windows.Forms.TextBox textBox12Fz1;
        private System.Windows.Forms.TextBox textBox75;
        private System.Windows.Forms.TextBox textBox11ZIPG1;
        private System.Windows.Forms.TextBox textBoxdipGZIP1;
        private System.Windows.Forms.TextBox textBox10Fz1;
        private System.Windows.Forms.TextBox textBox12ZIPG1;
        private System.Windows.Forms.TextBox textBox9Inf1;
        private System.Windows.Forms.TextBox textBox297;
        private System.Windows.Forms.TextBox textBoxdipMz1;
        private System.Windows.Forms.TextBox textBox10ZIPG1;
        private System.Windows.Forms.TextBox textBox217;
        private System.Windows.Forms.TextBox textBox9Fz1;
        private System.Windows.Forms.TextBox textBox11IT1;
        private System.Windows.Forms.TextBox textBoxdipIT1;
        private System.Windows.Forms.TextBox textBox137;
        private System.Windows.Forms.TextBox textBox12IT1;
        private System.Windows.Forms.TextBox textBox9ZIPG1;
        private System.Windows.Forms.TextBox textBox295;
        private System.Windows.Forms.TextBox textBoxdipSvZIP1;
        private System.Windows.Forms.TextBox textBox10IT1;
        private System.Windows.Forms.TextBox textBox12ZIPSv1;
        private System.Windows.Forms.TextBox textBox9Mz1;
        private System.Windows.Forms.TextBox textBox11G1;
        private System.Windows.Forms.TextBox textBoxdipG1;
        private System.Windows.Forms.TextBox textBox135;
        private System.Windows.Forms.TextBox textBox12G1;
        private System.Windows.Forms.TextBox textBox9IT1;
        private System.Windows.Forms.TextBox textBox293;
        private System.Windows.Forms.TextBox textBoxdipSv1;
        private System.Windows.Forms.TextBox textBox10G1;
        private System.Windows.Forms.TextBox textBox12Sv1;
        private System.Windows.Forms.TextBox textBox72;
        private System.Windows.Forms.TextBox textBox11ZIPMat1;
        private System.Windows.Forms.TextBox textBoxdipMatZIP1;
        private System.Windows.Forms.TextBox textBox133;
        private System.Windows.Forms.TextBox textBox12ZIPMat1;
        private System.Windows.Forms.TextBox textBox9G1;
        private System.Windows.Forms.TextBox textBox11Mat1;
        private System.Windows.Forms.TextBox textBoxdipMat1;
        private System.Windows.Forms.TextBox textBox10ZIPMat1;
        private System.Windows.Forms.TextBox textBox12Mat1;
        private System.Windows.Forms.TextBox textBox71;
        private System.Windows.Forms.TextBox textBox11ZIP3;
        private System.Windows.Forms.TextBox textBoxdipZIP3;
        private System.Windows.Forms.TextBox textBox10Mat1;
        private System.Windows.Forms.TextBox textBox12ZIP3;
        private System.Windows.Forms.TextBox textBox9ZIPMat1;
        private System.Windows.Forms.TextBox textBox11ZP3;
        private System.Windows.Forms.TextBox textBoxdipZP3;
        private System.Windows.Forms.TextBox textBox10ZIP3;
        private System.Windows.Forms.TextBox textBox12ZP3;
        private System.Windows.Forms.TextBox textBox9Mat1;
        private System.Windows.Forms.TextBox textBox11ZIP2;
        private System.Windows.Forms.TextBox textBoxdipZIP2;
        private System.Windows.Forms.TextBox textBox10ZP3;
        private System.Windows.Forms.TextBox textBox12ZIP2;
        private System.Windows.Forms.TextBox textBox9ZIP3;
        private System.Windows.Forms.TextBox textBox11ZP2;
        private System.Windows.Forms.TextBox textBoxdipZP2;
        private System.Windows.Forms.TextBox textBox10ZIP2;
        private System.Windows.Forms.TextBox textBox12ZP2;
        private System.Windows.Forms.TextBox textBox9ZP3;
        private System.Windows.Forms.TextBox textBox11ZIP1;
        private System.Windows.Forms.TextBox textBox10ZP2;
        private System.Windows.Forms.TextBox textBox12ZIP1;
        private System.Windows.Forms.TextBox textBox9ZIP2;
        private System.Windows.Forms.TextBox textBox11ZP1;
        private System.Windows.Forms.TextBox textBoxdipZP1;
        private System.Windows.Forms.TextBox textBox10ZIP1;
        private System.Windows.Forms.TextBox textBox12ZP1;
        private System.Windows.Forms.TextBox textBox9ZP2;
        private System.Windows.Forms.TextBox textBox11ZIP2Lang1;
        private System.Windows.Forms.TextBox textBoxdip2LangZIP1;
        private System.Windows.Forms.TextBox textBox10ZP1;
        private System.Windows.Forms.TextBox textBox12ZIP2Lang1;
        private System.Windows.Forms.TextBox textBox9ZIP1;
        private System.Windows.Forms.TextBox textBox112Lang1;
        private System.Windows.Forms.TextBox textBoxdip2Lang1;
        private System.Windows.Forms.TextBox textBox10ZIP2Lang1;
        private System.Windows.Forms.TextBox textBox122Lang1;
        private System.Windows.Forms.TextBox textBox9ZP1;
        private System.Windows.Forms.TextBox textBox11ZIP1Lang1;
        private System.Windows.Forms.TextBox textBoxdip1LangZIP1;
        private System.Windows.Forms.TextBox textBox102Lang1;
        private System.Windows.Forms.TextBox textBox121LangZIP1;
        private System.Windows.Forms.TextBox textBox92LangZIP1;
        private System.Windows.Forms.TextBox textBox111Lang1;
        private System.Windows.Forms.TextBox textBoxdip1Lang1;
        private System.Windows.Forms.TextBox textBox10ZIP1Lang1;
        private System.Windows.Forms.TextBox textBox121Lang1;
        private System.Windows.Forms.TextBox textBox92Lang1;
        private System.Windows.Forms.TextBox textBox11BelZIP1;
        private System.Windows.Forms.TextBox textBoxdipBELZIP1;
        private System.Windows.Forms.TextBox textBox101Lang1;
        private System.Windows.Forms.TextBox textBox12BelZIP1;
        private System.Windows.Forms.TextBox textBox9ZIP1Lang1;
        private System.Windows.Forms.TextBox textBox11Bel1;
        private System.Windows.Forms.TextBox textBoxdipBEL1;
        private System.Windows.Forms.TextBox textBox10BelZIP1;
        private System.Windows.Forms.TextBox textBox12Bel1;
        private System.Windows.Forms.TextBox textBox91Lang1;
        private System.Windows.Forms.TextBox textBox10Bel1;
        private System.Windows.Forms.TextBox textBox9BelZIP1;
        private System.Windows.Forms.TextBox textBox9Bel1;
        private System.Windows.Forms.ComboBox comboBox2Lang;
        private System.Windows.Forms.TextBox textBoxName;
        private System.Windows.Forms.TextBox textBoxNumber;
        private System.Windows.Forms.Button buttonClose;
        private System.Windows.Forms.TextBox textBox443;
        private System.Windows.Forms.TextBox textBox454;
        private System.Windows.Forms.TextBox textBox526;
        private System.Windows.Forms.TextBox textBox527;
        private System.Windows.Forms.TextBox textBox3DZI;
        private System.Windows.Forms.TextBox textBox1DZI;
        private System.Windows.Forms.TextBox textBox2DZI;
        private System.Windows.Forms.TextBox textBox4DZI;
        private System.Windows.Forms.TextBox textBox3DZIw;
        private System.Windows.Forms.TextBox textBox1DZIw;
        private System.Windows.Forms.TextBox textBox2DZIw;
        private System.Windows.Forms.TextBox textBox4DZIw;
        private System.Windows.Forms.TextBox textBox542;
        private System.Windows.Forms.TextBox textBox547;
        private System.Windows.Forms.TextBox textBox543;
        private System.Windows.Forms.TextBox textBoxYear;
        private System.Windows.Forms.TextBox textBox545;
        private System.Windows.Forms.Button buttonSave9kl;
        private System.Windows.Forms.TextBox textBox9ZP7;
        private System.Windows.Forms.ComboBox comboBox3DZI;
        private System.Windows.Forms.Button buttonSaveDZI;
        private System.Windows.Forms.Button buttonSaveSIP;
        private System.Windows.Forms.ComboBox comboBox1Lang;
        private System.Windows.Forms.ComboBox comboBox2DZI;
        private System.Windows.Forms.ComboBox comboBox1DZI;
        private System.Windows.Forms.ComboBox comboBox1SIP;
        private System.Windows.Forms.ComboBox comboBox3SIP;
        private System.Windows.Forms.ComboBox comboBox2SIP;
        private System.Windows.Forms.Button buttonSaveZPP;
        private System.Windows.Forms.ComboBox comboBox4DZI;
        private System.Windows.Forms.TextBox textBox420;
        private System.Windows.Forms.TextBox textBox421;
        private System.Windows.Forms.TextBox textBox422;
        private System.Windows.Forms.TextBox textBox9SIPw3;
        private System.Windows.Forms.TextBox textBox9SIPw1;
        private System.Windows.Forms.TextBox textBox9SIPw2;
        private System.Windows.Forms.TextBox textBox411;
        private System.Windows.Forms.TextBox textBox456;
        private System.Windows.Forms.TextBox textBox445;
        private System.Windows.Forms.TextBox textBox434;
        private System.Windows.Forms.TextBox textBox412;
        private System.Windows.Forms.TextBox textBox455;
        private System.Windows.Forms.TextBox textBox444;
        private System.Windows.Forms.TextBox textBox433;
        private System.Windows.Forms.TextBox textBox546;
        private System.Windows.Forms.TextBox textBox413;
        private System.Windows.Forms.TextBox textBox12kl;
        private System.Windows.Forms.TextBox textBox11kl;
        private System.Windows.Forms.TextBox textBox10kl;
        private System.Windows.Forms.TextBox textBox9kl;
        private System.Windows.Forms.TextBox textBox416;
        private System.Windows.Forms.TextBox textBox157;
        private System.Windows.Forms.TextBox textBox121;
        private System.Windows.Forms.TextBox textBox118;
        private System.Windows.Forms.TextBox textBoxOkZPP3;
        private System.Windows.Forms.TextBox textBox12ZPP3;
        private System.Windows.Forms.TextBox textBox11ZPP3;
        private System.Windows.Forms.TextBox textBox10ZPP3;
        private System.Windows.Forms.TextBox textBox9ZPP3;
        private System.Windows.Forms.TextBox textBoxOkZPP1;
        private System.Windows.Forms.TextBox textBox12ZPP1;
        private System.Windows.Forms.TextBox textBox11ZPP1;
        private System.Windows.Forms.TextBox textBox10ZPP1;
        private System.Windows.Forms.TextBox textBox9ZPP1;
        private System.Windows.Forms.TextBox textBoxOkZPP2;
        private System.Windows.Forms.TextBox textBox12ZPP2;
        private System.Windows.Forms.TextBox textBox11ZPP2;
        private System.Windows.Forms.TextBox textBox10ZPP2;
        private System.Windows.Forms.TextBox textBox9ZPP2;
        private System.Windows.Forms.TextBox textBoxOkZPPw3;
        private System.Windows.Forms.TextBox textBox12ZPPw3;
        private System.Windows.Forms.TextBox textBox11ZPPw3;
        private System.Windows.Forms.TextBox textBox10ZPPw3;
        private System.Windows.Forms.TextBox textBox9ZPPw3;
        private System.Windows.Forms.TextBox textBoxOkZPPw1;
        private System.Windows.Forms.TextBox textBox12ZPPw1;
        private System.Windows.Forms.TextBox textBox11ZPPw1;
        private System.Windows.Forms.TextBox textBox10ZPPw1;
        private System.Windows.Forms.TextBox textBox9ZPPw1;
        private System.Windows.Forms.TextBox textBoxOkZPPw2;
        private System.Windows.Forms.TextBox textBox12ZPPw2;
        private System.Windows.Forms.TextBox textBox11ZPPw2;
        private System.Windows.Forms.TextBox textBox10ZPPw2;
        private System.Windows.Forms.TextBox textBox9ZPPw2;
        private System.Windows.Forms.TextBox textBox41;
        private System.Windows.Forms.TextBox textBox40;
        private System.Windows.Forms.TextBox textBox39;
        private System.Windows.Forms.TextBox textBox26;
        private System.Windows.Forms.TextBox textBox22;
        private System.Windows.Forms.TextBox textBox21;
        private System.Windows.Forms.TextBox textBox19;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.TextBox textBox412kl;
        private System.Windows.Forms.TextBox textBox411kl;
        private System.Windows.Forms.TextBox textBox410kl;
        private System.Windows.Forms.TextBox textBox49kl;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBoxDZISrUsp;
        private System.Windows.Forms.TextBox textBoxZPPZIP;
        private System.Windows.Forms.TextBox textBoxDZISrUspW;
        private System.Windows.Forms.TextBox textBoxZPPZIPW;
        private System.Windows.Forms.TextBox textBox73;
        private System.Windows.Forms.TextBox textBox70;
        private System.Windows.Forms.TextBox textBoxSumOcZIP;
        private System.Windows.Forms.TextBox textBox1300;
        private System.Windows.Forms.TextBox textBoxSrZP;
        private System.Windows.Forms.TextBox textBoxBrOcZIP;
        private System.Windows.Forms.TextBox textBox1100;
        private System.Windows.Forms.TextBox textBox450;
        private System.Windows.Forms.TextBox textBoxSrZPW;
        private System.Windows.Forms.Button buttonSave11kl;
        private System.Windows.Forms.Button buttonSave10kl;
        private System.Windows.Forms.Button buttonSave12kl;
        private System.Windows.Forms.TextBox textBox3ZPP;
        private System.Windows.Forms.TextBox textBox2ZPP;
        private System.Windows.Forms.TextBox textBox1ZPP;
        private System.Windows.Forms.Button buttonFinally;
        private System.Windows.Forms.Button buttonSaveSuccess;
        private System.Windows.Forms.Button buttonShow;
        private System.Windows.Forms.TextBox textBoxSrUspeh;
        private System.Windows.Forms.ToolTip toolTipL;
        private System.Windows.Forms.TextBox textBoxdipZIP1;
        private System.Windows.Forms.TextBox textBoxSrUspehW;
        private System.Windows.Forms.TextBox textBoxSrUspZP;
        private System.Windows.Forms.Button buttonEdit9klas;
        private System.Windows.Forms.Button buttonEdit;
        private System.Windows.Forms.Button buttonEditFinaly;
        private System.Windows.Forms.Button buttonEdit12klas;
        private System.Windows.Forms.Button buttonEdit11klas;
        private System.Windows.Forms.Button buttonEdit10klas;
        private System.Windows.Forms.Button buttonEditZPP;
        private System.Windows.Forms.Button buttonEditDZI;
        private System.Windows.Forms.TabPage tabPage1;

    }
}