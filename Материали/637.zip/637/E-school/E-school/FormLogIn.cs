﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace E_school
{
    public partial class FormLogIn : Form
    {
        public FormLogIn()
        {
            InitializeComponent();
           
        }
        int teacherID;
        string schoolYear;
        //метод за действие на бутон Enter като бутон Tab
        private void General_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {

                if (this.GetNextControl(ActiveControl, true) != null)
                {
                    e.Handled = true;
                    this.GetNextControl(ActiveControl, true).Focus();
                }
            }
        }
      
        private void buttonLogIn_Click(object sender, EventArgs e)
        {
            bool flag = false, find = false;
            if (textBoxUser.Text == "" && textBoxPassword.Text == "")
            {
                FormMenu f = new FormMenu();
                Reset();
                flag = true;
                
                f.Show();
            }
            else if (!flag)
            {
                ESchoolEntities context = new ESchoolEntities();
                var account = context.Teachers;
                foreach (var item in account)
                {
                    if (textBoxUser.Text == item.UserName && textBoxPassword.Text == item.Password)
                    {
                        find = true;
                        teacherID = item.TeacherID;
                    }
                    if (find)
                    {
                        break;
                    }
                }
                if (find)
                {
                    //заявка за извеждане класа на съответния учител-класен р-л
                    var clas = from cl in context.Classes
                               join tch in context.Teachers on cl.TeacherID equals tch.TeacherID
                               where tch.TeacherID == teacherID && cl.SchoolYear == schoolYear
                               select cl;
                    int classID = clas.SingleOrDefault().ClassID;
                    FormClass f = new FormClass(teacherID, classID, schoolYear);
                    Reset();
                    f.Show();
                    
                }
            }
            if (!flag && !find)
            {
                Reset();
                MessageBox.Show("Грешка! Невалидни данни!");
            }
         }

        private void Reset()
        {
            textBoxPassword.Clear();
            textBoxUser.Clear();
            textBoxUser.Focus();
        }

        private void FormLogIn_Load(object sender, EventArgs e)
        {
            string format = "yyyy";
            string yearNow = DateTime.Now.ToString(format);
            int year = int.Parse(yearNow);
            textBoxYear.Text = (year - 1).ToString() + "/" + year.ToString();
            schoolYear = textBoxYear.Text;

            
        }

    }
}

