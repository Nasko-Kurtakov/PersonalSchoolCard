﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace E_school
{
    public partial class FormMenu : Form
    {
        public FormMenu()
        {
            InitializeComponent();
        }

        private void buttonAddClass_Click(object sender, EventArgs e)
        {
            FormClasses fKl = new FormClasses();
            fKl.Show();
        }

        private void buttonAddProfile_Click(object sender, EventArgs e)
        {
            FormProfile fPr = new FormProfile();
            fPr.Show();
        }

        private void buttonAddStudent_Click(object sender, EventArgs e)
        {
            FormAddStudent f = new FormAddStudent();
            f.Show();

        }

        private void buttonClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FormCreateAccaunts f = new FormCreateAccaunts();
            f.Show();
        }

        private void buttonAddStudents_Click(object sender, EventArgs e)
        {
            FormGetStudentsFromExcel f = new FormGetStudentsFromExcel();
            f.Show();
        }

        

      
    }
}
