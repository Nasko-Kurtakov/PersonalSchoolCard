﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace E_school
{
    public partial class FormAddStudent : Form
    {
        public FormAddStudent()
        {
            InitializeComponent();
            label1.BackColor = System.Drawing.Color.Transparent;
            label2.BackColor = System.Drawing.Color.Transparent;
            label3.BackColor = System.Drawing.Color.Transparent;
            label4.BackColor = System.Drawing.Color.Transparent;
        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
             ESchoolEntities context = new ESchoolEntities();
             if (!string.IsNullOrEmpty(textBoxFirstName.Text) && !string.IsNullOrEmpty(textBoxLastName.Text))
             {
                 //създаваме обект
                 Students newStudent = new Students();
                 newStudent.FirstName = textBoxFirstName.Text;
                 newStudent.LastName = textBoxLastName.Text;
                 if (!string.IsNullOrEmpty(textBoxSecondName.Text))
                 {
                     newStudent.SecondName = textBoxSecondName.Text;
                 }
                 else
                 {
                     newStudent.SecondName = "";
                 }
                 if (!string.IsNullOrEmpty(textBoxNumber.Text))
                 {
                     newStudent.NumberInClass = int.Parse(textBoxNumber.Text);
                 }
                 else
                 {
                     newStudent.NumberInClass =0;
                 }
                 // обработка на селектираният ред от dataGridViewClass
                 int classID;//локална променлива
                 //от текущо селектирания ред - row.Cells[0].Value
                 int i = dataGridViewClass.CurrentRow.Index;
                 classID = (int)dataGridViewClass.Rows[i].Cells[0].Value; 
                 newStudent.ClassID = classID;

                 //добавяне на ученика в базата и записване на промените
                context.Students.AddObject(newStudent);
                context.SaveChanges();
                MessageBox.Show("Ученикът е добавен!");
            }
            else
            {
                MessageBox.Show("Грешка! Не сте въвели данни.");
            }
        }

        private void FormAddStudent_Load(object sender, EventArgs e)
        {
            ESchoolEntities context = new ESchoolEntities();
            //зареждане на таблицата с класовете
            var classes = context.Classes ;
            dataGridViewClass.AutoGenerateColumns = false;
            dataGridViewClass.DataSource = classes;
        }

        private void label1_Click(object sender, EventArgs e)
        {
            
            label1.BackColor = System.Drawing.Color.Transparent;
        }

        private void label2_Click(object sender, EventArgs e)
        {
            label2.BackColor = System.Drawing.Color.Transparent;
        }

        private void label3_Click(object sender, EventArgs e)
        {
            label3.BackColor = System.Drawing.Color.Transparent;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void dataGridViewClass_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

       
    }
}
