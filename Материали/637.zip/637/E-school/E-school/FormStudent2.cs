﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace E_school
{
    public partial class FormStudent2 : Form
    {
        public FormStudent2(int studentID, string schoolYear, List<string> listZPP)
        {
            InitializeComponent();
            this.studentID = studentID;
            this.schoolYear = schoolYear;
            this.listZPP = listZPP;

           
        }
        private int studentID;
        private string schoolYear;
        private string str;
        private List<string> listZPP;
        private List<string> listSubjects = new List<string>();
        String[] masivSubjects = new String[18];
        private TextBox[] masivTBox = new TextBox[4];
        List<float> sipOkon = new List<float>(); //списък за въвеждане оценките от СИП за 9,10,11,12 квас
        //за да се определи окончателната оценка

        //метод, който връща student по неговото ID
        ESchoolEntities context = new ESchoolEntities();
        public static Students GetStudentByID(ESchoolEntities context, int studentID)
        {
            Students stu = context.Students.FirstOrDefault(
                p => p.StudentID == studentID);
            return stu;
        }

        //метод, който на съответната оценка показва оценката с думи
        private void GradeText(int grade)
        {
            switch (grade)
            {
               
                case 2: str = "Слаб"; break;
                case 3: str = "Среден"; break;
                case 4: str = "Добър"; break;
                case 5: str = "Много добър"; break;
                case 6: str = "Отличен"; break;

                default: str = "Невъзможна оценка!!!";
                    break;
            }
        }
        //метод, който на съответната оценка от тип реален показва оценката с думи
        private void GradeText2(float grade)
        {
            if (grade <= 2.99)
            {
                str = "Слаб";
            }
            else if (grade >= 3.0 && grade < 3.5)
            {
                str = "Среден";
            }
            else if (grade >= 3.5 && grade < 4.5)
            {
                str = "Добър";
            }
            else if (grade >= 4.5 && grade < 5.5)
            {
                str = "Много добър";
            }
            else if (grade >= 5.5 && grade <= 6)
            {
                str = "Отличен";
            }
            else str = "Невъзможна оценка!!!";

        }
        //метод за използване на клавишите за обхождане на тестовите кутии с оценките
        public void General_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {

                if (this.GetNextControl(ActiveControl, true) != null)
                {
                    e.Handled = true;
                    this.GetNextControl(ActiveControl, true).Focus();
                }
            }

            if (e.KeyCode == Keys.Down)
            {

                if (this.GetNextControl(ActiveControl, true) != null)
                {
                    e.Handled = true;
                    this.GetNextControl(ActiveControl, true).Focus();
                }
            }
            if (e.KeyCode == Keys.Up)
            {

                if (this.GetNextControl(ActiveControl, false) != null)
                {
                    e.Handled = true;
                    this.GetNextControl(ActiveControl, false).Focus();
                }
            }
          
        }

     
         private void tabPageUspeh_Paint(object sender, PaintEventArgs e)
        {
            
            textBox12Year.Text = schoolYear + " година";
            string stPrevios;
            stPrevios = schoolYear.Substring(0, 4);
            int yPrevios;
            yPrevios = int.Parse(stPrevios) - 1;
            textBox11Year.Text = yPrevios.ToString() + "/" + stPrevios + " година";

            stPrevios = yPrevios.ToString();
            yPrevios = yPrevios - 1;
            textBox10Year.Text = yPrevios.ToString() + "/" + stPrevios + " година";

            stPrevios = yPrevios.ToString();
            yPrevios = yPrevios - 1;
            textBox9Year.Text = yPrevios.ToString() + "/" + stPrevios + " година";
            
           
           
        }

        private void tabPageDZI_SIP_Paint(object sender, PaintEventArgs e)
        {
            textBox12kl.Text = schoolYear + " година";
            string stPrevios;
            stPrevios = schoolYear.Substring(0, 4);
            int yPrevios;
            yPrevios = int.Parse(stPrevios) - 1;
            textBox11kl.Text = yPrevios.ToString() + "/" + stPrevios + " година";

            stPrevios = yPrevios.ToString();
            yPrevios = yPrevios - 1;
            textBox10kl.Text = yPrevios.ToString() + "/" + stPrevios + " година";

            stPrevios = yPrevios.ToString();
            yPrevios = yPrevios - 1;
            textBox9kl.Text = yPrevios.ToString() + "/" + stPrevios + " година";
            textBoxYear.Text = schoolYear + " година";

            textBox412kl.Text = schoolYear + " година";
            stPrevios = schoolYear.Substring(0, 4);
            yPrevios = int.Parse(stPrevios) - 1;
            textBox411kl.Text = yPrevios.ToString() + "/" + stPrevios + " година";

            stPrevios = yPrevios.ToString();
            yPrevios = yPrevios - 1;
            textBox410kl.Text = yPrevios.ToString() + "/" + stPrevios + " година";

            stPrevios = yPrevios.ToString();
            yPrevios = yPrevios - 1;
            textBox49kl.Text = yPrevios.ToString() + "/" + stPrevios + " година";

        }

        private void FormStudent2_Load(object sender, EventArgs e)
        {
            toolTipL.SetToolTip(comboBox1Lang, "Първи чужд език");
            toolTipL.SetToolTip(comboBox2Lang, "Втори чужд език");
            buttonEdit.Enabled = false;
            buttonEdit9klas.Enabled = false;
            buttonEdit10klas.Enabled = false;
            buttonEdit11klas.Enabled = false;
            buttonEdit12klas.Enabled = false;
            buttonEditFinaly.Enabled = false;
            buttonFinally.Enabled = false;
            buttonSave12kl.Enabled = false;
            buttonSave11kl.Enabled = false;
            buttonSave10kl.Enabled = false;
           
            buttonSaveSuccess.Enabled = false;
            buttonEdit.Enabled = false;
            buttonEditDZI.Enabled = false;
            buttonEditZPP.Enabled = false;
            textBox1100.Visible = false;
            textBox1300.Visible = false;
            textBoxBrOcZIP.Visible = false;
            textBoxSumOcZIP.Visible = false;
            textBox9ZP1.Focus();
           
            ESchoolEntities context = new ESchoolEntities();
            Students stu = GetStudentByID(context, studentID);
            textBoxName.Text = stu.FirstName + "  " + stu.SecondName + "  " + stu.LastName;
            textBoxNumber.Text = stu.NumberInClass.ToString();
            if (stu.SuccessDiplom!=null )
            {
                double gr =( double)stu.SuccessDiplom;
                textBoxSrUspeh.Text = gr.ToString("F2");
                buttonSave9kl.Enabled = false;
                buttonSave10kl.Enabled = false;
                buttonSave11kl.Enabled = false;
                buttonSave12kl.Enabled = false;
                
            }

            //зарежда ЗПП ПП в текстовити кутии
            if (listZPP.Count ==3)
            {
                    textBox1ZPP.Text = listZPP[0];
                    textBox2ZPP.Text = listZPP[1];
                    textBox3ZPP.Text = listZPP[2];  
            }
            else if (MessageBox.Show("Трябва да изберете 3 профилиращи предмета", "", MessageBoxButtons.OK,MessageBoxIcon.Warning) == DialogResult.OK)
            {
                this.Close();
               
            }
            //зарежда чуждите езици в комбобоксовете
             SubjectsToList(context, "език", 4);
             foreach (var item in listSubjects)
            {
                comboBox1Lang.Items.Add(item);
                comboBox2Lang.Items.Add(item);
                
            }
            
             listSubjects.Clear();
             //зарежда ДЗИ
             SubjectsToList(context, "ДЗИ", 3);
             comboBox1DZI.Items.Clear();
             comboBox2DZI.Items.Clear(); 
             comboBox3DZI.Items.Clear(); 
             comboBox4DZI.Items.Clear(); 
             foreach (var item in listSubjects)
             {
                 comboBox1DZI.Items.Add(item);
                 comboBox2DZI.Items.Add(item);
                 comboBox3DZI.Items.Add(item);
                 comboBox4DZI.Items.Add(item);

             }
             comboBox1DZI.SelectedIndex = 1;
             
             listSubjects.Clear();
             //зарежда СИП-ове
             SubjectsToList(context, "СИП", 3);
             foreach (var item in listSubjects)
             {
                 comboBox1SIP.Items.Add(item);
                 comboBox2SIP.Items.Add(item);
                 comboBox3SIP.Items.Add(item);
                 
             }
            
             listSubjects.Clear();
        }
        //метод,който създава списък от  ЗИП, СИП или ДЗИ предмети
        //за да се заредят в съответните комбобоксове
        private void SubjectsToList(ESchoolEntities context, string str, int k)
        {
            var subjects = context.Subjects;
            foreach (var item in subjects)
            {
                string subjectName = item.SubjectName.Trim();
                int subjectNameLen = subjectName.Length;
               
                if (subjectName.Substring(subjectNameLen - k, k) == str)
                {
                    listSubjects.Add(item.SubjectName);
                }
                
            }
        }

        //метод, който връща ID по името на предмета
        private static int GetIDBySubject(ESchoolEntities context, string subjectName)
        {
            Subjects obj = context.Subjects.FirstOrDefault(
               p => p.SubjectName == subjectName);
            return obj.SubjectID;
        }

        //метод, който по ID на  предмета връща името му
        private static string GetSubjectByID(ESchoolEntities context, int subjectID)
        {
            Subjects sbj = context.Subjects.FirstOrDefault(
               p => p.SubjectID == subjectID);
            return sbj.SubjectName;
        }

       

        private void InitSubjects(String[] masivSubjects)
        {

            masivSubjects[0] = GetSubjectByID(context, 1);
            if (comboBox1Lang.SelectedItem!=null && comboBox2Lang.SelectedItem!=null )
            {
                masivSubjects[1] = comboBox1Lang.SelectedItem.ToString();
                masivSubjects[2] = comboBox2Lang.SelectedItem.ToString(); 
            }
          
            for (int i = 3; i <=17; i++)
            {
                masivSubjects[i] = GetSubjectByID(context, i+3);
            }
           
        }
        private void buttonSave9kl_Click(object sender, EventArgs e)
        {
            ESchoolEntities context = new ESchoolEntities();
            bool flZP = false;
            if (comboBox1Lang.SelectedItem == null || comboBox2Lang.SelectedItem == null)
            {
                MessageBox.Show("Не си избрал първи и втори чужд език!");
               
            }
            else
            {
                InitSubjects(masivSubjects);
                try
                {
                    //записва оценките ЗП 9 клас
                    InitGrades9klas(masivGrades);
                    int gr;
                    for (int i = 0; i < 18; i++)
                    {
                        flZP =false ;
                        if (masivGrades[i].Text != "")
                        {
                            gr = int.Parse(masivGrades[i].Text);
                            if (gr > 2 && gr <= 6)
                            {
                                AddGrade9klas(context, masivSubjects[i], gr);
                                flZP = true;
                            }
                        }
                    }
                    InitGradesZIP9klas(masivGrades);
                    //записва оценките ЗИП 9 клас
                    for (int i = 0; i < 18; i++)
                    {
                       
                        string subject = FindZIP(context, masivSubjects[i]);
                        if (masivGrades[i].Text != "" && !string.IsNullOrEmpty(subject))
                        {
                            gr = int.Parse(masivGrades[i].Text);
                            if (gr > 2 && gr <= 6)
                            {
                                AddGrade9klas(context, subject, gr);
                            }

                        }
                    }
                    //записва в базата
                    if (flZP)
                    {
                        context.SaveChanges();
                        MessageBox.Show("Оценките за 9 клас са записани!");
                        buttonSave9kl.Enabled = false;
                        buttonSave10kl.Enabled = true;
                        textBox10ZP1.Focus();

                    }
                    else
                    {
                        MessageBox.Show("Записът невъзможен. Не са въведени оценки или има грешни оценки!");
                    }

                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка при въвеждане на оценката!", "", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                
               
            }
           
               
            
           
        }
        private void buttonSave10kl_Click(object sender, EventArgs e)
        {
            ESchoolEntities context = new ESchoolEntities();
            bool flZP = false;
           
            if (comboBox1Lang.SelectedItem == null || comboBox2Lang.SelectedItem == null)
            {
                MessageBox.Show("Не си избрал първи и втори чужд език!");
            }
            else
            {
                InitSubjects(masivSubjects);
                try
                {
                    //записва оценките ЗП 10 клас
                    int gr;
                    InitGrades10klas(masivGrades);
                    for (int i = 0; i < 18; i++)
                    {
                        flZP = false;
                        if (masivGrades[i].Text != "")
                        {
                            gr = int.Parse(masivGrades[i].Text);
                            if (gr > 2 && gr <= 6)
                            {
                                AddGrade10klas(context, masivSubjects[i], gr);
                                flZP = true;
                            }
                        }

                    }
                    InitGradesZIP10klas(masivGrades);
                    //записва оценките ЗИП 10 клас
                    for (int i = 0; i < 18; i++)
                    {
                        string subject = FindZIP(context, masivSubjects[i]);
                        if (masivGrades[i].Text != "" && !string.IsNullOrEmpty(subject))
                        {
                            gr = int.Parse(masivGrades[i].Text);
                            if (gr > 2 && gr <= 6)
                            {
                                AddGrade10klas(context, subject, gr);
                            }
                        }
                    }

                    //записва в базата
                    if (flZP)
                    {
                        context.SaveChanges();
                        MessageBox.Show("Оценките за 10 клас са записани!");
                        buttonSave10kl.Enabled = false;
                        buttonSave11kl.Enabled = true;
                        textBox11ZP1.Focus();
                    }
                    else
                    {
                        MessageBox.Show("Записът невъзможен. Не са въведени оценки или има грешни оценки!");
                    }
                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка при въвеждане на оценката!", "", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
               
            }
           
        }

        private void buttonSave11kl_Click(object sender, EventArgs e)
        {
            ESchoolEntities context = new ESchoolEntities();
            try
            {
                //записва оценките ЗП 11 клас
                InitGrades11klas(masivGrades);
                bool flZP = false;
                int gr;
                for (int i = 0; i < 18; i++)
                {
                    flZP = false;
                    if (masivGrades[i].Text != "")
                    {
                        gr = int.Parse(masivGrades[i].Text);
                        if (gr > 2 && gr <= 6)
                        {
                            AddGrade11klas(context, masivSubjects[i], gr);
                            flZP = true;
                        }
                    }

                }
                
                //записва оценките ЗИП 11 клас
                InitGradesZIP11klas(masivGrades);
                for (int i = 0; i < 18; i++)
                {
                    string subject = FindZIP(context, masivSubjects[i]);
                    if (masivGrades[i].Text != "" && !string.IsNullOrEmpty(subject))
                    {
                        gr = int.Parse(masivGrades[i].Text);
                        if (gr > 2 && gr <= 6)
                        {
                            AddGrade11klas(context, subject, gr);
                           
                        }
                    }
                }
                //записва в базата
                if (flZP)
                {
                    context.SaveChanges();
                    MessageBox.Show("Оценките за 11 клас са записани!");
                    buttonSave11kl.Enabled = false;
                    buttonSave12kl.Enabled = true;
                    textBox12ZP1.Focus();
                }
                else
                {
                    MessageBox.Show("Записът невъзможен. Не са въведени оценки или има грешни оценки!");
                }

               
            }
            catch (FormatException)
            {
                MessageBox.Show("Грешка при въвеждане на оценката!", "", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            
        }


        private void buttonSave12kl_Click(object sender, EventArgs e)
        {

            ESchoolEntities context = new ESchoolEntities();
            try
            {
                //записва оценките ЗП 12 клас
                InitGrades12klas(masivGrades);
                bool flZP = false;
                int gr;
                for (int i = 0; i < 18; i++)
                {
                    if (masivGrades[i].Text != "")
                    {
                        flZP = false;
                        gr = int.Parse(masivGrades[i].Text);
                        if (gr > 2 && gr <= 6)
                        {
                            AddGrade12klas(context, masivSubjects[i], gr);
                            flZP=true;
                        }
                        
                    }

                }
                //записва оценките ЗИП 10 клас
                InitGradesZIP12klas(masivGrades);
                for (int i = 0; i < 18; i++)
                {
                    string subject = FindZIP(context, masivSubjects[i]);
                    if (masivGrades[i].Text != "" && !string.IsNullOrEmpty(subject))
                    {
                        gr = int.Parse(masivGrades[i].Text);
                        if (gr > 2 && gr <= 6)
                        {
                            AddGrade12klas(context, subject, gr);
                           
                        }
                    }
                }
                
                //записва в базата  
                if (flZP )
	            {
                    context.SaveChanges();
                    MessageBox.Show("Оценките за 12 клас са записани! Направете запис на окончателни оценки!" );
                    buttonSave12kl.Enabled = false;
                    buttonFinally.Enabled = true;
                    buttonFinally.Focus();
	            }                       
               
                else
                    {
                        MessageBox.Show("Записът невъзможен. Не са въведени оценки или има грешни оценки!");
                    }
            }
            catch (FormatException)
            {
                MessageBox.Show("Грешка при въвеждане на оценката!", "", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
           

        }

        //методът намира ЗИП предмета по името на предмета
        private string FindZIP(ESchoolEntities context, string predmet)
        {
            string str ="";
            string zip,predmetZip;
            var subjects = context.Subjects;
            bool flag = false;
            foreach (var item in subjects)
            {
                predmetZip = item.SubjectName.Trim();
                int predmetZiplenght = predmetZip.Length;
                int predmetLenght = predmet.Trim().Length;
                zip = predmetZip.Substring(predmetZiplenght - 3, 3);
                if (predmetZiplenght > predmetLenght)
                {

                    if (zip == "ЗИП" && predmet.Trim() == predmetZip.Substring(0, predmetLenght))
                    {
                        str = predmetZip;
                        flag = true;

                    }
                }
                if (flag)
                    break;
            }
            return str;
        }
       
        //метод за добавяне на оценка по един предмет в 9 клас
        private void AddGrade9klas(ESchoolEntities context,string predmet,int grade)
        {
            Grades9Class newGrades9Class = new Grades9Class();
            newGrades9Class.StudentID = studentID;
            int id = GetIDBySubject(context, predmet);
            newGrades9Class.SubjectID = id;
            newGrades9Class.Grades = grade;
            
            context.Grades9Class.AddObject(newGrades9Class);
        }
        //метод за добавяне на оценка по един предмет в 10 клас
        private void AddGrade10klas(ESchoolEntities context, string predmet, int grade)
        {
            Grades10Class newGrades10Class = new Grades10Class();
            newGrades10Class.StudentID = studentID;
            int id = GetIDBySubject(context, predmet);
            newGrades10Class.SubjectID = id;
            newGrades10Class.Grades = grade;

            context.Grades10Class.AddObject(newGrades10Class);


        }
        //метод за добавяне на оценка по един предмет в 11 клас
        private void AddGrade11klas(ESchoolEntities context, string predmet, int grade)
        {
            Grades11Class newGrades11Class = new Grades11Class();
            newGrades11Class.StudentID = studentID;
            int id = GetIDBySubject(context, predmet);
            newGrades11Class.SubjectID = id;
            newGrades11Class.Grades = grade;

            context.Grades11Class.AddObject(newGrades11Class);


        }
        //метод за добавяне на оценка по един предмет в 12 клас
        private void AddGrade12klas(ESchoolEntities context, string predmet, int grade)
        {
            Grades12Class newGrades12Class = new Grades12Class();
            newGrades12Class.StudentID = studentID;
            int id = GetIDBySubject(context, predmet);
            newGrades12Class.SubjectID = id;
            newGrades12Class.Grades = grade;

            context.Grades12Class.AddObject(newGrades12Class);


        }
        //метод за добавяне на оценки в таблицата Diploms на базата
        private void AddGradesDiplom(ESchoolEntities context, string predmet, float grade)
        {
            Diploms newGradesDZI = new Diploms();
            newGradesDZI.StudentID = studentID;
            int id = GetIDBySubject(context, predmet);
            newGradesDZI.SubjectID = id;
            newGradesDZI.Grades = grade;

            context.Diploms.AddObject(newGradesDZI);


        }
        private void buttonSaveDZI_Click(object sender, EventArgs e)
        {
            float srUspeh = 0;
            int count = 0;
            ESchoolEntities context = new ESchoolEntities();
            float grade = 0;
                if (comboBox1DZI.SelectedItem != null && comboBox2DZI.SelectedItem != null)
                {
                    if (textBox1DZI.Text != "" && textBox2DZI.Text != "")
                    {
                        try
                        {
                            grade = float.Parse(textBox1DZI.Text);
                            if (grade >= 2 && grade <= 6)
                            {
                                AddGradesDiplom(context, comboBox1DZI.SelectedItem.ToString(), grade);
                                srUspeh += grade;
                                count++;
                            }
                            else
                            {
                                MessageBox.Show("Грешно въведена оценка!");
                            }

                            grade = float.Parse(textBox2DZI.Text);
                            if (grade >= 2 && grade <= 6)
                            {
                                AddGradesDiplom(context, comboBox2DZI.SelectedItem.ToString(), grade);
                                srUspeh += grade;
                                count++;
                            }
                            else
                            {
                                MessageBox.Show("Грешно въведена оценка!");
                            }
                        }
                        catch (FormatException)
                        {
                            MessageBox.Show("Грешно въведени оценки!");
                        }

                    }
                }
                else
	            {
                       MessageBox.Show("Не сте избрали ДЗИ. Изберете!");            
	            }
                if (comboBox3DZI.SelectedItem != null)
                {

                    if (textBox3DZI.Text != "")
                    {
                        try
                        {
                            grade = float.Parse(textBox3DZI.Text);
                            if (grade >= 2 && grade <= 6)
                            {
                                AddGradesDiplom(context, comboBox3DZI.SelectedItem.ToString(), grade);
                                srUspeh += grade;
                                count++;
                            }
                        }
                        catch (FormatException)
                        {
                            MessageBox.Show("Грешно въведена оценка!");
                        }

                    }
                }
               
                if (comboBox4DZI.SelectedItem != null)
                {

                    if (textBox4DZI.Text != "")
                    {
                        try
                        {
                            grade = float.Parse(textBox4DZI.Text);
                            if (grade >= 2 && grade <= 6)
                            {
                                AddGradesDiplom(context, comboBox4DZI.SelectedItem.ToString(), grade);
                                srUspeh += grade;
                                count++;
                            }
                        }
                        catch (FormatException)
                        {
                            MessageBox.Show("Грешно въведена оценка!");
                        }
                    }
                }
                //средноаритметична оценка от ДЗИ

                if (count > 1)
                {
                    srUspeh = srUspeh / count;
                    textBoxDZISrUsp.Text = srUspeh.ToString("F2");
                    context.SaveChanges();
                    MessageBox.Show("Оценките са записани!");
                    buttonSaveDZI.Enabled = false;
                    buttonSaveSuccess.Enabled = true;
                }
                      
        }
       
        private void buttonSaveSIP_Click(object sender, EventArgs e)
        { 
            ESchoolEntities context = new ESchoolEntities();
           
            //изчислява окончателните оценки по  СИП-овете и ги записва 
            //по първи СИП
           
               sipOkon.Clear();
                masivTBox[0] = textBox9SIP1;
                masivTBox[1] = textBox10SIP1;
                masivTBox[2] = textBox11SIP1;
                masivTBox[3] = textBox12SIP1;
                float sip;
                if (comboBox1SIP.SelectedItem == null && comboBox2SIP.SelectedItem == null && comboBox3SIP.SelectedItem == null)
                {
                    MessageBox.Show("Не сте избрали СИП!");
                }
                else
                {

                    if (comboBox1SIP.SelectedItem != null)
                    {
                        AddGradeToList(masivTBox, sipOkon);

                        sip = 0;
                        if (sipOkon.Count > 0)
                        {
                            sip = sipOkon.Average();
                            if (sip > 2 && sip <= 6)
                            {
                                textBoxOkon1.Text = sip.ToString("F2");
                                if (!string.IsNullOrEmpty(textBoxOkon1.Text))
                                {
                                    //записва окончат.оценка първи СИП в табл. Diploms
                                    AddGradesDiplom(context, comboBox1SIP.SelectedItem.ToString(), sip);
                                }
                            }
                            else
                            {
                                MessageBox.Show("Грешно въведени оценки!");
                            }

                        }
                    }

                    sipOkon.Clear();
                    //по втори СИП
                    masivTBox[0] = textBox9SIP2;
                    masivTBox[1] = textBox10SIP2;
                    masivTBox[2] = textBox11SIP2;
                    masivTBox[3] = textBox12SIP2;
                    if (comboBox2SIP.SelectedItem != null)
                    {
                        AddGradeToList(masivTBox, sipOkon);

                        if (sipOkon.Count > 0)
                        {
                            sip = sipOkon.Average();
                            if (sip > 2 && sip <= 6)
                            {
                                textBoxOkon2.Text = sip.ToString("F2");
                                if (!string.IsNullOrEmpty(textBoxOkon2.Text))
                                {
                                    //записва окончат.оценка втори СИП в табл. Diploms
                                    AddGradesDiplom(context, comboBox2SIP.SelectedItem.ToString(), sip);
                                }
                            }
                        }
                    }

                    sipOkon.Clear();
                    //по трети СИП
                    masivTBox[0] = textBox9SIP3;
                    masivTBox[1] = textBox10SIP3;
                    masivTBox[2] = textBox11SIP3;
                    masivTBox[3] = textBox12SIP3;
                    if (comboBox3SIP.SelectedItem != null)
                    {
                        AddGradeToList(masivTBox, sipOkon);

                        if (sipOkon.Count > 0)
                        {
                            sip = sipOkon.Average();
                            if (sip > 2 && sip <= 6)
                            {
                                textBoxOkon3.Text = sip.ToString("F2");
                                if (!string.IsNullOrEmpty(textBoxOkon3.Text))
                                {
                                    //записва окончат.оценка трети СИПв табл. Diploms
                                    AddGradesDiplom(context, comboBox3SIP.SelectedItem.ToString(), sip);
                                }
                            }
                        }
                    }


                    ComboBox[] masivCombo = new ComboBox[] { comboBox1SIP, comboBox2SIP, comboBox3SIP };
                    //записва 9 клас СИП в таблицата Grades9Class
                    masivTBox[0] = textBox9SIP1;
                    masivTBox[1] = textBox9SIP2;
                    masivTBox[2] = textBox9SIP3;

                    for (int i = 0; i < 3; i++)
                    {
                        if (masivTBox[i].Text != "")
                        {

                            int grade = int.Parse(masivTBox[i].Text);
                            if (grade > 2 && grade <= 6)
                            {
                                AddGrade9klas(context, masivCombo[i].SelectedItem.ToString(), grade);
                            }
                        }
                    }
                    //записва 10 клас СИП в таблицата Grades10Class
                    masivTBox[0] = textBox10SIP1;
                    masivTBox[1] = textBox10SIP2;
                    masivTBox[2] = textBox10SIP3;
                    for (int i = 0; i < 3; i++)
                    {
                        if (masivTBox[i].Text != "")
                        {
                            int grade = int.Parse(masivTBox[i].Text);
                            if (grade > 2 && grade <= 6)
                            {
                                AddGrade10klas(context, masivCombo[i].SelectedItem.ToString(), grade);
                            }
                        }
                    }
                    //записва 11 клас СИП в таблицата Grades11Class
                    masivTBox[0] = textBox11SIP1;
                    masivTBox[1] = textBox11SIP2;
                    masivTBox[2] = textBox11SIP3;
                    for (int i = 0; i < 3; i++)
                    {
                        if (masivTBox[i].Text != "")
                        {
                            int grade = int.Parse(masivTBox[i].Text);
                            if (grade > 2 && grade <= 6)
                            {
                                AddGrade11klas(context, masivCombo[i].SelectedItem.ToString(), grade);
                            }
                        }
                    }
                    //записва 12 клас СИП в таблицата Grades12Class

                    masivTBox[0] = textBox12SIP1;
                    masivTBox[1] = textBox12SIP2;
                    masivTBox[2] = textBox12SIP3;
                    for (int i = 0; i < 3; i++)
                    {
                        if (masivTBox[i].Text != "")
                        {
                            int grade = int.Parse(masivTBox[i].Text);
                            if (grade > 2 && grade <= 6)
                            {
                                AddGrade12klas(context, masivCombo[i].SelectedItem.ToString(), grade);
                            }
                        }

                    }
                    if (context != null)
                    {
                        context.SaveChanges();
                        MessageBox.Show("Оценките са записани!");
                        buttonSaveSIP.Enabled = false;
                    }
                }
           
        }

        private void buttonSaveZPP_Click(object sender, EventArgs e)
        {
            ESchoolEntities context = new ESchoolEntities();
            
            masivTBox[0] = textBox9ZPP1;
            masivTBox[1] = textBox10ZPP1;
            masivTBox[2] = textBox11ZPP1;
            masivTBox[3] = textBox12ZPP1;
            sipOkon.Clear();
            //изчислява окончателните оценки по  ЗПП и ги записва 
            //по първи ЗПП
            AddGradeToList(masivTBox, sipOkon);
           
            float zpp = 0;
            float sum = 0;
            int count = 0;

            if (sipOkon.Count > 0)
            {
                zpp = sipOkon.Average();
                sum += zpp;
                count++;
                textBoxOkZPP1.Text = zpp.ToString("F2");
                if (!string.IsNullOrEmpty(textBoxOkZPP1.Text))
                {
                    //записва окончателната оценка по първи ЗПП в таблицата Diploms на базата
                    AddGradesDiplom(context, textBox1ZPP.Text, zpp);
                }
            }

            //по втори ЗПП
            sipOkon.Clear();
            masivTBox[0] = textBox9ZPP2;
            masivTBox[1] = textBox10ZPP2;
            masivTBox[2] = textBox11ZPP2;
            masivTBox[3] = textBox12ZPP2;
            AddGradeToList(masivTBox, sipOkon);
            zpp = 0;
            if (sipOkon.Count > 0)
            {
                zpp = sipOkon.Average();
                sum += zpp;
                count++;
                textBoxOkZPP2.Text = zpp.ToString("F2");
                if (!string.IsNullOrEmpty(textBoxOkZPP2.Text))
                {
                    //записва окончателната оценка по втори ЗПП в таблицата Diploms на базата
                    AddGradesDiplom(context, textBox2ZPP.Text, (float)zpp);
                }
            }
            //по трети ЗПП
            sipOkon.Clear();
            masivTBox[0] = textBox9ZPP3;
            masivTBox[1] = textBox10ZPP3;
            masivTBox[2] = textBox11ZPP3;
            masivTBox[3] = textBox12ZPP3;
            AddGradeToList(masivTBox, sipOkon);
            zpp = 0;
            if (sipOkon.Count > 0)
            {
                zpp = sipOkon.Average();
                sum += zpp;
                count++;
                textBoxOkZPP3.Text = zpp.ToString("F2");
                if (!string.IsNullOrEmpty(textBoxOkZPP3.Text))
                {
                    //записва окончателната оценка по трети ЗПП в таблицата Diploms на базата
                    AddGradesDiplom(context, textBox3ZPP.Text, (float)zpp);
                }
            }
            if (textBoxSumOcZIP.Text!="")
            {
                sum += float.Parse(textBoxSumOcZIP.Text);
                count += int.Parse(textBoxBrOcZIP.Text);
            }
            //среден успех от оценките ЗИП и ЗПП
            sum/= count;
            textBoxZPPZIP.Text = sum.ToString("F2");
            
            //записва 9 клас ЗПП в базата в таблицата Grades9Class
            masivTBox[0] = textBox9ZPP1;
            masivTBox[1] = textBox9ZPP2;
            masivTBox[2] = textBox9ZPP3;
            bool fl9 = false, fl10 = false, fl11 = false, fl12 = false;
            TextBox[] masivZPP = new TextBox[] { textBox1ZPP, textBox2ZPP, textBox3ZPP };

            for (int i = 0; i < 3; i++)
            {
                if (!string.IsNullOrEmpty(masivTBox[i].Text) && !string.IsNullOrEmpty(masivZPP[i].Text))
                {
                    
                    int grade = int.Parse(masivTBox[i].Text);
                    if (grade > 2 && grade <= 6)
                    {
                        AddGrade9klas(context, masivZPP[i].Text, grade);
                        fl9 = true;
                    }
                }
            }
            //записва 10 клас ЗПП в базата в таблицата Grades10Class
            masivTBox[0] = textBox10ZPP1;
            masivTBox[1] = textBox10ZPP2;
            masivTBox[2] = textBox10ZPP3;
            for (int i = 0; i < 3; i++)
            {
                if (!string.IsNullOrEmpty(masivTBox[i].Text) && !string.IsNullOrEmpty(masivZPP[i].Text))
                {
                    
                    int grade = int.Parse(masivTBox[i].Text);
                    if (grade > 2 && grade <= 6)
                    {
                        AddGrade10klas(context, masivZPP[i].Text, grade);
                        fl10 = true;
                    }
                }

            }
            //записва 11 клас ЗПП в базата   в таблицата Grades11Class
            masivTBox[0] = textBox11ZPP1;
            masivTBox[1] = textBox11ZPP2;
            masivTBox[2] = textBox11ZPP3;
            for (int i = 0; i < 3; i++)
            {
                if (!string.IsNullOrEmpty(masivTBox[i].Text) && !string.IsNullOrEmpty(masivZPP[i].Text))
                {

                    int grade = int.Parse(masivTBox[i].Text);
                    if (grade > 2 && grade <= 6)
                    {
                        AddGrade11klas(context, masivZPP[i].Text, grade);
                        fl11 = true;
                    }
                }

            }
            //записва 12 клас ЗПП в базата  в таблицата Grades12Class

            masivTBox[0] = textBox12ZPP1;
            masivTBox[1] = textBox12ZPP2;
            masivTBox[2] = textBox12ZPP3;
            for (int i = 0; i < 3; i++)
            {
                if (!string.IsNullOrEmpty(masivTBox[i].Text) && !string.IsNullOrEmpty(masivZPP[i].Text))
                {
                    
                    int grade = int.Parse(masivTBox[i].Text);
                    if (grade > 2 && grade <= 6)
                    {
                        AddGrade12klas(context, masivZPP[i].Text, grade );
                        fl12 = true;
                    }
                }
            }
            if (fl9 && fl10 && fl11 && fl12)
            {
                context.SaveChanges();//запис в базата
                MessageBox.Show("Оценките са записани!");
                buttonSaveZPP.Enabled = false;
                buttonSaveSuccess.Enabled = true; 
            }
            else
            {
                MessageBox.Show("Записът е невъзможен. Некоректни оценки!");
            }
            

        }
        //метод за добавяне на оцинки в списък, които се четат от масива с текстови кутии
        private void AddGradeToList(TextBox [] masivTBox,List <float> sipOkon)
        {
            float grade;
            for (int i = 0; i <= 3; i++)
            {
                if (!string.IsNullOrEmpty(masivTBox[i].Text))
                {
                    try
                    {
                        grade = float.Parse(masivTBox[i].Text);
                        if (grade >= 2 && grade <= 6)
                        {
                            sipOkon.Add(grade);
                        }
                        else
                        {
                            MessageBox.Show("Грешно въведени оценки!");
                        }

                    }
                    catch (FormatException)
                    {
                        MessageBox.Show("Грешно въведени оценки!");
                    }
                }
            }
        }

        //метод за промяна на оценка по 1 предмет в дипломата
        private void EditGradesDiplom()
        {
            ESchoolEntities context = new ESchoolEntities();
            InitGradesZPDiplom(masivGrades);
            var gradesDiplom = from grDip in context.Diploms
                               where grDip.StudentID == studentID
                               select grDip;
            float grade;
            int sbjID = 0;
            foreach (var item in gradesDiplom)
            {

                if (item.Grades != 0)
                {
                    sbjID = item.SubjectID;
                    //за БЕЛ, АЕ,НЕ
                    if (sbjID <= 3 && masivGrades[sbjID - 1].Text != "")
                    {
                        grade =float.Parse(masivGrades[sbjID - 1].Text);
                        item.Grades = grade;
                    }
                        //за РЕ
                    else if (sbjID <=4 && masivGrades[sbjID - 2].Text != "")
                    {
                        grade = float.Parse(masivGrades[sbjID - 2].Text);
                        item.Grades = grade;
                        
                    }
                        //за ФЕ
                    else if (sbjID <=5)
                    {
                        grade = float.Parse(masivGrades[sbjID - 3].Text);
                        item.Grades = grade;
                    }
                    else if (sbjID <= 20 && masivGrades[sbjID - 3].Text != "")
                    {
                        grade = float.Parse(masivGrades[sbjID - 3].Text);
                        item.Grades = grade;

                    }

                }
                if (sbjID > 20)
                    break;
            }
            context.SaveChanges();
            MessageBox.Show("Оценките са променени!");
          

        }
        //промяна на окончателните оценки, ако има промени на други оценки
        private void buttonEditFinaly_Click(object sender, EventArgs e)
        {
             ESchoolEntities context = new ESchoolEntities();
            //списък с окончателните оценки ЗП, за да се определи средноаритм. успех от ЗП
            List<float> listFinally = new List<float>();
            //окончателни оценки ЗП
            //BEL
            masivTBox[0] = textBox9ZP1;
            masivTBox[1] = textBox10ZP1;
            masivTBox[2] = textBox11ZP1;
            masivTBox[3] = textBox12ZP1;
            //намерам средноаритметичната (окончателна) оценка от 9 до 12 клас по БЕЛ
            float grade = FinallyGrade(masivTBox, 4);
            //добавям оконч.оценка в списъка listFinally, за да намеря накрая средноаритметичното от всички оценки по ЗП
            //която участва при ичлислението на успеха за дипломата
            listFinally.Add(grade);
            //показвам ок.оценка в текстовата кутия  textBoxdipBEL
            textBoxdipZP1.Text = grade.ToString("F2");
          
            //първи чужд език
            masivTBox[0] = textBox9ZP2;
            masivTBox[1] = textBox10ZP2;
            masivTBox[2] = textBox11ZP2;
            masivTBox[3] = textBox12ZP2;
            grade = FinallyGrade(masivTBox, 4);
            listFinally.Add(grade);
            textBoxdipZP2.Text = grade.ToString("F2");
          

            //втори чужд език
            masivTBox[0] = textBox9ZP3;
            masivTBox[1] = textBox10ZP3;
            masivTBox[2] = textBox11ZP3;
            masivTBox[3] = textBox12ZP3;

            grade = FinallyGrade(masivTBox, 4);
            listFinally.Add(grade);
            textBoxdipZP3.Text = grade.ToString("F2");
           

            //математика
            masivTBox[0] = textBox9ZP4;
            masivTBox[1] = textBox10ZP4;
            masivTBox[2] = textBox11ZP4;
            masivTBox[3] = textBox12ZP4;

            grade = FinallyGrade(masivTBox, 4);
            listFinally.Add(grade);
            textBoxdipZP4.Text = grade.ToString("F2");
          

            //информатика
            masivTBox[0] = textBox9ZP5;
            masivTBox[1] = textBox10ZP5;

            grade = FinallyGrade(masivTBox, 2);
            listFinally.Add(grade);
            textBoxdipZP5.Text = grade.ToString("F2");
           

            //инф.техн.
            masivTBox[0] = textBox9ZP6;
            masivTBox[1] = textBox10ZP6;

            grade = FinallyGrade(masivTBox, 2);
            listFinally.Add(grade);
            textBoxdipZP6.Text = grade.ToString("F2");
            

            //история
            masivTBox[0] = textBox10ZP7;
            masivTBox[1] = textBox11ZP7;
            masivTBox[2] = textBox12ZP7;

            grade = FinallyGrade(masivTBox, 3);
            listFinally.Add(grade);
            textBoxdipZP7.Text = grade.ToString("F2");

            //геогр.
            masivTBox[0] = textBox10ZP8;
            masivTBox[1] = textBox11ZP8;
            masivTBox[2] = textBox12ZP8;

            grade = FinallyGrade(masivTBox, 3);
            listFinally.Add(grade);
            textBoxdipZP8.Text = grade.ToString("F2");

            //психология
            
            if (textBox9ZP9.Text!="")
            {
                
                grade = float.Parse(textBox9ZP9.Text);
                listFinally.Add(grade);
                textBoxdipZP9.Text = grade.ToString("F2");
            }
            //етика
           
            if (textBoxdipZP10.Text!="")
            {
                grade = float.Parse(textBox10ZP10.Text);
                listFinally.Add(grade);
                textBoxdipZP10.Text = grade.ToString("F2");
            }
           
            //философия
           
            if (textBoxdipZP11.Text!="")
            {
                grade = float.Parse(textBox11ZP11.Text);
                listFinally.Add(grade);
                textBoxdipZP11.Text = grade.ToString("F2");
            }
           
            //свят и личност
            
            if (textBoxdipZP12.Text!="")
            {
                grade = float.Parse(textBox12ZP12.Text);
                listFinally.Add(grade);
                textBoxdipZP12.Text = grade.ToString("F2");
            }
           
            //биология
            masivTBox[0] = textBox10ZP13;
            masivTBox[1] = textBox11ZP13;
            grade = FinallyGrade(masivTBox, 2);
            listFinally.Add(grade);
            textBoxdipZP13.Text = grade.ToString("F2");

            //физика
            masivTBox[0] = textBox10ZP14;
            masivTBox[1] = textBox11ZP14;
            masivTBox[2] = textBox12ZP14;
            grade = FinallyGrade(masivTBox, 3);
            listFinally.Add(grade);
            textBoxdipZP14.Text = grade.ToString("F2");


            //химия
            masivTBox[0] = textBox10ZP15;
            masivTBox[1] = textBox11ZP15;
            grade = FinallyGrade(masivTBox, 2);
            listFinally.Add(grade);
            textBoxdipZP15.Text = grade.ToString("F2");

            //музика
            
            if (textBoxdipZP16.Text!="")
            {
                grade = float.Parse(textBox9ZP16.Text);
                listFinally.Add(grade);
                textBoxdipZP16.Text = grade.ToString("F2");
            }
           
           
            //изобраз.изк.
            
            if (textBoxdipZP17.Text!="")
            {
                grade = float.Parse(textBox9ZP17.Text);
                listFinally.Add(grade);
                textBoxdipZP17.Text = grade.ToString("F2");
            }
            
            //физическа култура
            masivTBox[0] = textBox9ZP18;
            masivTBox[1] = textBox10ZP18;
            masivTBox[2] = textBox11ZP18;
            masivTBox[3] = textBox12ZP18;
            grade = FinallyGrade(masivTBox, 4);
            listFinally.Add(grade);
            textBoxdipZP18.Text = grade.ToString("F2");
            //намирам среден успех от оценките по ЗП
            float sredenUspehZP = listFinally.Average();
            //показвам този среден успех
            textBoxSrZP.Text = sredenUspehZP.ToString("F2");
            textBoxSrUspZP.Text = sredenUspehZP.ToString("F2");
            //запис на окончателните оценки ЗП в базата данни в табл. Diploms
            EditGradesDiplom();
            buttonSaveSuccess.Text = "Преизчисли успеха за дипломата";
            buttonSaveSuccess.ForeColor = Color.Red;
            


        }
        //намиране на окончателните оценки ЗП и ЗИП и записването им в базата данни
        private void buttonFinally_Click(object sender, EventArgs e)
        {
            ESchoolEntities context = new ESchoolEntities();
            //списък с окончателните оценки ЗП, за да се определи средноаритм. успех от ЗП
            List<float> listFinally = new List<float>();
            //окончателни оценки ЗП
            //BEL
            masivTBox[0] = textBox9ZP1;
            masivTBox[1] = textBox10ZP1;
            masivTBox[2] = textBox11ZP1;
            masivTBox[3] = textBox12ZP1;
            //изчиствам списъка  listGrades 
           
            //намирам средноаритметичната (окончателна) оценка от 9 до 12 клас по БЕЛ
            float grade = FinallyGrade(masivTBox,4);
            //добавям оконч.оценка в списъка listFinally, за да намеря накрая средноаритметичното от всички оценки по ЗП
            //която участва при ичлислението на успеха за дипломата
            listFinally.Add(grade);
            //показвам ок.оценка в текстовата кутия  textBoxdipBEL
            textBoxdipZP1.Text = grade.ToString("F2");
            //добавям ок.оценка в т.Diploms на базата
            AddGradesDiplom(context, textBoxBel.Text, grade);
            //изчиствам списъка  listGrades
           
            //първи чужд език
            masivTBox[0] = textBox9ZP2;
            masivTBox[1] = textBox10ZP2;
            masivTBox[2] = textBox11ZP2;
            masivTBox[3] = textBox12ZP2;
           
            grade = FinallyGrade(masivTBox,4);
            listFinally.Add(grade);
            textBoxdipZP2.Text = grade.ToString("F2");
            AddGradesDiplom(context, comboBox1Lang.SelectedItem.ToString(), grade);
            
            //втори чужд език
            masivTBox[0] = textBox9ZP3;
            masivTBox[1] = textBox10ZP3;
            masivTBox[2] = textBox11ZP3;
            masivTBox[3] = textBox12ZP3;
           
            grade = FinallyGrade(masivTBox,4);
            listFinally.Add(grade);
            textBoxdipZP3.Text = grade.ToString("F2");
            AddGradesDiplom(context, comboBox2Lang.SelectedItem.ToString(), grade);
           
            //математика
            masivTBox[0] = textBox9ZP4;
            masivTBox[1] = textBox10ZP4;
            masivTBox[2] = textBox11ZP4;
            masivTBox[3] = textBox12ZP4;
            
            grade = FinallyGrade(masivTBox,4);
            listFinally.Add(grade);
            textBoxdipZP4.Text = grade.ToString("F2");
            AddGradesDiplom(context, textBoxMath.Text, grade);
           
            //информатика
            masivTBox[0] = textBox9ZP5;
            masivTBox[1] = textBox10ZP5;
           
            grade = FinallyGrade(masivTBox,2);
            listFinally.Add(grade);
            textBoxdipZP5.Text = grade.ToString("F2");
            AddGradesDiplom(context, textBoxInfor.Text, grade);
            
            //инф.техн.
            masivTBox[0] = textBox9ZP6;
            masivTBox[1] = textBox10ZP6;
            
            grade = FinallyGrade(masivTBox,2);
            listFinally.Add(grade);
            textBoxdipZP6.Text = grade.ToString("F2");
            AddGradesDiplom(context, textBoxInfT.Text, grade);
           
            //история
            masivTBox[0] = textBox10ZP7;
            masivTBox[1] = textBox11ZP7;
            masivTBox[2] = textBox12ZP7;
            
            grade = FinallyGrade(masivTBox,3);
            listFinally.Add(grade);
            textBoxdipZP7.Text = grade.ToString("F2");
            AddGradesDiplom(context, textBoxIsto.Text, grade);
            
            //геогр.
            masivTBox[0] = textBox10ZP8;
            masivTBox[1] = textBox11ZP8;
            masivTBox[2] = textBox12ZP8;
           
            grade = FinallyGrade(masivTBox,3);
            listFinally.Add(grade);
            textBoxdipZP8.Text = grade.ToString("F2");
            AddGradesDiplom(context, textBoxGeo.Text, grade);
            
            //психология
            grade = float.Parse(textBox9ZP9.Text);
            textBoxdipZP9.Text = grade.ToString("F2");
            listFinally.Add(grade);
            AddGradesDiplom(context, textBoxPsi.Text, grade);
            //етика
            grade = float.Parse(textBox10ZP10.Text);
            textBoxdipZP10.Text = grade.ToString("F2");
            listFinally.Add(grade);
            AddGradesDiplom(context, textBoxEtika.Text, grade);
            //философия
            grade = float.Parse(textBox11ZP11.Text);
            textBoxdipZP11.Text = grade.ToString("F2");
            listFinally.Add(grade);
            AddGradesDiplom(context, textBoxFil.Text, grade);
            //свят и личност
            grade = float.Parse(textBox12ZP12.Text);
            textBoxdipZP12.Text = grade.ToString("F2");
            listFinally.Add(grade);
            AddGradesDiplom(context, textBoxSvL.Text, grade);
            //биология
            masivTBox[0] = textBox10ZP13;
            masivTBox[1] = textBox11ZP13;
            grade = FinallyGrade(masivTBox,2);
            listFinally.Add(grade);
            textBoxdipZP13.Text = grade.ToString("F2");
            AddGradesDiplom(context, textBoxBiol.Text, grade);
           
            //физика
            masivTBox[0] = textBox10ZP14;
            masivTBox[1] = textBox11ZP14;
            masivTBox[2] = textBox12ZP14;
            grade = FinallyGrade(masivTBox,3);
            listFinally.Add(grade);
            textBoxdipZP14.Text = grade.ToString("F2");
            AddGradesDiplom(context, textBoxFiz.Text, grade);
            

            //химия
            masivTBox[0] = textBox10ZP15;
            masivTBox[1] = textBox11ZP15;
            grade = FinallyGrade(masivTBox,2);
            listFinally.Add(grade);
            textBoxdipZP15.Text = grade.ToString("F2");
            AddGradesDiplom(context, textBoxHim.Text, grade);
            
            //музика
            grade = float.Parse(textBox9ZP16.Text);
            textBoxdipZP16.Text = grade.ToString("F2");
            listFinally.Add(grade);
            AddGradesDiplom(context, textBoxMuz.Text, grade);
            //изобраз.изк.
            grade = float.Parse(textBox9ZP17.Text);
            textBoxdipZP17.Text =grade.ToString("F2");
            listFinally.Add(grade);
            AddGradesDiplom(context, textBoxIzIzk.Text, grade);
            //физическа култура
            masivTBox[0] = textBox9ZP18;
            masivTBox[1] = textBox10ZP18;
            masivTBox[2] = textBox11ZP18;
            masivTBox[3] = textBox12ZP18;
            grade = FinallyGrade(masivTBox,4);
            listFinally.Add(grade);
            textBoxdipZP18.Text = grade.ToString("F2");
            AddGradesDiplom(context, textBoxFVSp.Text, grade);
            //намирам среден успех от оценките по ЗП
            float sredenUspehZP = listFinally.Average();
            //показвам този среден успех
            textBoxSrZP.Text = sredenUspehZP.ToString("F2");
            textBoxSrUspZP.Text = sredenUspehZP.ToString("F2");
            //запис на окончателните оценки ЗП в базата данни в табл. Diploms
            context.SaveChanges();

            //окончателни оценки ЗИП
            //BEL
            listFinally.Clear();//изчистване на списъка, за да се изпалзва 
                                //за изчисление на ср.успех от ЗИП непрофилирана
            masivTBox[0] = textBox9ZIP1;
            masivTBox[1] = textBox10ZIP1;
            masivTBox[2] = textBox11ZIP1;
            masivTBox[3] = textBox12ZIP1;
            grade = FinallyGrade(masivTBox,4);
            //по името на предмета връща името със ЗИП
            string str = FindZIP(context, textBoxBel.Text);
            if (grade>0 && str!="")
            {
                listFinally.Add(grade);
                textBoxdipZIP1.Text = grade.ToString("F2");
                //добавяне на оконч.оценка ЗИП  в базата в табл.Diploms 
                AddGradesDiplom(context, str, grade);
            }

            //първи чужд език ЗИП
            masivTBox[0] = textBox9ZIP2;
            masivTBox[1] = textBox10ZIP2;
            masivTBox[2] = textBox11ZIP2;
            masivTBox[3] = textBox12ZIP2;
            grade = FinallyGrade(masivTBox, 4);
            str = FindZIP(context, comboBox1Lang.SelectedItem.ToString());
            if (grade > 0 && str != "")
            {
                listFinally.Add(grade);
                textBoxdipZIP2.Text = grade.ToString("F2");
                //добавяне на оконч.оценка ЗИП  в базата в табл.Diploms 
                AddGradesDiplom(context, str, grade);
            }
            
            //втори чужд език ЗИП
            masivTBox[0] = textBox9ZIP3;
            masivTBox[1] = textBox10ZIP3;
            masivTBox[2] = textBox11ZIP3;
            masivTBox[3] = textBox12ZIP3;
            grade = FinallyGrade(masivTBox, 4);
            str = FindZIP(context, comboBox2Lang.SelectedItem.ToString());
            if (grade > 0 && str != "")
            {
                listFinally.Add(grade);
                textBoxdipZIP3.Text = grade.ToString("F2");
                //добавяне на оконч.оценка ЗИП  в базата в табл.Diploms 
                AddGradesDiplom(context, str, grade);
            }

            
            //математика  ЗИП
            masivTBox[0] = textBox9ZIP4;
            masivTBox[1] = textBox10ZIP4;
            masivTBox[2] = textBox11ZIP4;
            masivTBox[3] = textBox12ZIP4;
            grade = FinallyGrade(masivTBox, 4);
            str = FindZIP(context, textBoxMath.Text);
            if (grade > 0 && str != "")
            {
                listFinally.Add(grade);
                textBoxdipZIP4.Text = grade.ToString("F2");
                //добавяне на оконч.оценка ЗИП  в базата в табл.Diploms 
                AddGradesDiplom(context, str, grade);
            }
            //информатика  ЗИП
            masivTBox[0] = textBox9ZIP5;
            masivTBox[1] = textBox10ZIP5;
            masivTBox[2] = textBox11ZIP5;
            masivTBox[3] = textBox12ZIP5;
            grade = FinallyGrade(masivTBox, 4);
            str = FindZIP(context, textBoxInfor.Text);
            if (grade > 0 && str != "")
            {
                listFinally.Add(grade);
                textBoxdipZIP5.Text = grade.ToString("F2");
                //добавяне на оконч.оценка ЗИП  в базата в табл.Diploms 
                AddGradesDiplom(context, str, grade);
            }


            //ИТ ЗИП
            masivTBox[0] = textBox9ZIP6;
            masivTBox[1] = textBox10ZIP6;
            masivTBox[2] = textBox11ZIP6;
            masivTBox[3] = textBox12ZIP6;

            grade = FinallyGrade(masivTBox, 4);
            str = FindZIP(context, textBoxInfT.Text);
            if (grade > 0 && str != "")
            {
                listFinally.Add(grade);
                textBoxdipZIP6.Text = grade.ToString("F2");
                //добавяне на оконч.оценка ЗИП  в базата в табл.Diploms 
                AddGradesDiplom(context, str, grade);
            }
            context.SaveChanges();//запис в базата
            //намирам и показвам сумата и броя на оценките от ЗИП
            //които ще учсват при изчисление на среден успех оценките от ЗИП и ЗПП
            float sum = 0;
            foreach (var item in listFinally)
	        {                                    
                sum += item;
	        }

            textBoxSumOcZIP.Text = sum.ToString("F2");
            textBoxBrOcZIP.Text = ((int)listFinally.Count).ToString();
           
            buttonFinally.Enabled = false;
        }
        //записване на средния успех от дипломата на ученика в таблицата Students
        private void buttonSaveSuccess_Click(object sender, EventArgs e)
        {
            ESchoolEntities context = new ESchoolEntities();
            Students stu = context.Students.FirstOrDefault(
               p => p.StudentID == studentID);
            try
            {
                float gradeZPP = float.Parse(textBoxZPPZIP.Text);
                //
                float gradeZP = float.Parse(textBoxSrZP.Text);
                float gradeDZI = float.Parse(textBoxDZISrUsp.Text);
                float successDiplom = (gradeZPP + gradeZP + gradeDZI) / 3;
                stu.SuccessDiplom = successDiplom;
                context.SaveChanges();
                textBoxSrUspeh.Text = successDiplom.ToString("F2");
                MessageBox.Show("Успех от дипломата:  " + successDiplom);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void comboBox1DZI_SelectedIndexChanged(object sender, EventArgs e)
        {
            buttonSaveDZI.Enabled = true;
        }

        private void buttonEdit_Click(object sender, EventArgs e)
        {
            buttonEdit9klas.Enabled = true;
            buttonEdit10klas.Enabled = true;
            buttonEdit11klas.Enabled = true;
            buttonEdit12klas.Enabled = true;
            buttonSaveSuccess.Enabled = true;
            buttonEditDZI.Enabled = true;
            buttonEditZPP.Enabled = true;
           

        }

        //метод за намиране на окончателна оценка по предмет като средноаритметично от годините, в които се изучава
        private float FinallyGrade(TextBox[] masivTBox, int k)
        {
            List<float> listGrades = new List<float>();
            for (int i = 0; i < k; i++)
            {
                if (!string.IsNullOrEmpty(masivTBox[i].Text))
                {
                    listGrades.Add(float.Parse(masivTBox[i].Text));
                }
            }
            float grade = 0;
            if (listGrades.Count>0)
            {
                grade = listGrades.Average();
                
            }
            return grade;
          
        }
         
        //масиви за оценките по предмети
        TextBox[] masivGrades = new TextBox[18];
         private void InitGrades9klas(TextBox[] masivGrades)
         {
             masivGrades[0] = textBox9ZP1;
             masivGrades[1] = textBox9ZP2;
             masivGrades[2] = textBox9ZP3;
             masivGrades[3] = textBox9ZP4;
             masivGrades[4] = textBox9ZP5;
             masivGrades[5] = textBox9ZP6;
             masivGrades[6] = textBox9ZP7;
             masivGrades[7] = textBox9ZP8;
             masivGrades[8] = textBox9ZP9;
             masivGrades[9] = textBox9ZP10;
             masivGrades[10] = textBox9ZP11;
             masivGrades[11] = textBox9ZP12;
             masivGrades[12] = textBox9ZP13;
             masivGrades[13] = textBox9ZP14;
             masivGrades[14] = textBox9ZP15;
             masivGrades[15] = textBox9ZP16;
             masivGrades[16] = textBox9ZP17;
             masivGrades[17] = textBox9ZP18;
          
            

         }
         private void InitGrades10klas(TextBox[] masivGrades)
         {

             masivGrades[0] = textBox10ZP1;
             masivGrades[1] = textBox10ZP2;
             masivGrades[2] = textBox10ZP3;
             masivGrades[3] = textBox10ZP4;
             masivGrades[4] = textBox10ZP5;
             masivGrades[5] = textBox10ZP6;
             masivGrades[6] = textBox10ZP7;
             masivGrades[7] = textBox10ZP8;
             masivGrades[8] = textBox10ZP9;
             masivGrades[9] = textBox10ZP10;
             masivGrades[10] = textBox10ZP11;
             masivGrades[11] = textBox10ZP12;
             masivGrades[12] = textBox10ZP13;
             masivGrades[13] = textBox10ZP14;
             masivGrades[14] = textBox10ZP15;
             masivGrades[15] = textBox10ZP16;
             masivGrades[16] = textBox10ZP17;
             masivGrades[17] = textBox10ZP18;
         }
         private void InitGrades11klas(TextBox[] masivGrades)
         {

             masivGrades[0] = textBox11ZP1;
             masivGrades[1] = textBox11ZP2;
             masivGrades[2] = textBox11ZP3;
             masivGrades[3] = textBox11ZP4;
             masivGrades[4] = textBox11ZP5;
             masivGrades[5] = textBox11ZP6;
             masivGrades[6] = textBox11ZP7;
             masivGrades[7] = textBox11ZP8;
             masivGrades[8] = textBox11ZP9;
             masivGrades[9] = textBox11ZP10;
             masivGrades[10] = textBox11ZP11;
             masivGrades[11] = textBox11ZP12;
             masivGrades[12] = textBox11ZP13;
             masivGrades[13] = textBox11ZP14;
             masivGrades[14] = textBox11ZP15;
             masivGrades[15] =  textBox11ZP16;
             masivGrades[16] = textBox11ZP17;
             masivGrades[17] = textBox11ZP18;
         }
         private void InitGrades12klas(TextBox[] masivGrades)
         {

             masivGrades[0] = textBox12ZP1;
             masivGrades[1] = textBox12ZP2;
             masivGrades[2] = textBox12ZP3;
             masivGrades[3] = textBox12ZP4;
             masivGrades[4] = textBox12ZP5;
             masivGrades[5] = textBox12ZP6;
             masivGrades[6] = textBox12ZP7;
             masivGrades[7] = textBox12ZP8;
             masivGrades[8] = textBox12ZP9;
             masivGrades[9] = textBox12ZP10;
             masivGrades[10] = textBox12ZP11;
             masivGrades[11] = textBox12ZP12;
             masivGrades[12] = textBox12ZP13;
             masivGrades[13] = textBox12ZP14;
             masivGrades[14] = textBox12ZP15;
             masivGrades[15] = textBox12ZP16;
             masivGrades[16] = textBox12ZP17;
             masivGrades[17] = textBox12ZP18;
         }
         private void InitGradesZIP9klas(TextBox[] masivGrades)
         {
             masivGrades[0] = textBox9ZIP1;
             masivGrades[1] = textBox9ZIP2;
             masivGrades[2] = textBox9ZIP3;
             masivGrades[3] = textBox9ZIP4;
             masivGrades[4] = textBox9ZIP5;
             masivGrades[5] = textBox9ZIP6;
             masivGrades[6] = textBox9ZIP7;
             masivGrades[7] = textBox9ZIP8;
             masivGrades[8] = textBox9ZIP9;
             masivGrades[9] =textBox9ZIP10;
             masivGrades[10] =textBox9ZIP11;
             masivGrades[11] = textBox9ZIP12;
             masivGrades[12] = textBox9ZIP13;
             masivGrades[13] = textBox9ZIP14;
             masivGrades[14] = textBox9ZIP15;
             masivGrades[15] =textBox9ZIP16;
             masivGrades[16] = textBox9ZIP17;
             masivGrades[17] = textBox9ZIP18;
         }
         private void InitGradesZIP10klas(TextBox[] masivGrades)
         {
             masivGrades[0] = textBox10ZIP1;
             masivGrades[1] = textBox10ZIP2;
             masivGrades[2] = textBox10ZIP3;
             masivGrades[3] = textBox10ZIP4;
             masivGrades[4] = textBox10ZIP5;
             masivGrades[5] = textBox10ZIP6;
             masivGrades[6] = textBox10ZIP7;
             masivGrades[7] = textBox10ZIP8;
             masivGrades[8] = textBox10ZIP9;
             masivGrades[9] = textBox10ZIP10;
             masivGrades[10] = textBox10ZIP11;
             masivGrades[11] = textBox10ZIP12;
             masivGrades[12] = textBox10ZIP13;
             masivGrades[13] = textBox10ZIP14;
             masivGrades[14] = textBox10ZIP15;
             masivGrades[15] = textBox10ZIP16;
             masivGrades[16] = textBox10ZIP17;
             masivGrades[17] = textBox10ZIP18;
         }
         private void InitGradesZIP11klas(TextBox[] masivGrades)
         {
             masivGrades[0] = textBox11ZIP1;
             masivGrades[1] = textBox11ZIP2;
             masivGrades[2] = textBox11ZIP3;
             masivGrades[3] = textBox11ZIP4;
             masivGrades[4] = textBox11ZIP5;
             masivGrades[5] = textBox11ZIP6;
             masivGrades[6] = textBox11ZIP7;
             masivGrades[7] = textBox11ZIP8;
             masivGrades[8] = textBox11ZIP9;
             masivGrades[9] = textBox11ZIP10;
             masivGrades[10] = textBox11ZIP11;
             masivGrades[11] = textBox11ZIP12;
             masivGrades[12] = textBox11ZIP13;
             masivGrades[13] = textBox11ZIP14;
             masivGrades[14] = textBox11ZIP15;
             masivGrades[15] = textBox11ZIP16;
             masivGrades[16] = textBox11ZIP17;
             masivGrades[17] = textBox11ZIP18;
         }
         private void InitGradesZIP12klas(TextBox[] masivGrades)
         {
             masivGrades[0] = textBox12ZIP1;
             masivGrades[1] = textBox12ZIP2;
             masivGrades[2] = textBox12ZIP3;
             masivGrades[3] = textBox12ZIP4;
             masivGrades[4] = textBox12ZIP5;
             masivGrades[5] = textBox12ZIP6;
             masivGrades[6] = textBox12ZIP7;
             masivGrades[7] = textBox12ZIP8;
             masivGrades[8] = textBox12ZIP9;
             masivGrades[9] = textBox12ZIP10;
             masivGrades[10] = textBox12ZIP11;
             masivGrades[11] = textBox12ZIP12;
             masivGrades[12] = textBox12ZIP13;
             masivGrades[13] = textBox12ZIP14;
             masivGrades[14] = textBox12ZIP15;
             masivGrades[15] = textBox12ZIP16;
             masivGrades[16] = textBox12ZIP17;
             masivGrades[17] = textBox12ZIP18;
         }
         private void InitGradesZPDiplom(TextBox[] masivGrades)
         {
             masivGrades[0] = textBoxdipZP1;
             masivGrades[1] = textBoxdipZP2;
             masivGrades[2] = textBoxdipZP3;
             masivGrades[3] = textBoxdipZP4;
             masivGrades[4] = textBoxdipZP5;
             masivGrades[5] = textBoxdipZP6;
             masivGrades[6] = textBoxdipZP7;
             masivGrades[7] = textBoxdipZP8;
             masivGrades[8] = textBoxdipZP9;
             masivGrades[9] = textBoxdipZP10;
             masivGrades[10] = textBoxdipZP11;
             masivGrades[11] = textBoxdipZP12;
             masivGrades[12] = textBoxdipZP13;
             masivGrades[13] = textBoxdipZP14;
             masivGrades[14] = textBoxdipZP15;
             masivGrades[15] = textBoxdipZP16;
             masivGrades[16] = textBoxdipZP17;
             masivGrades[17] = textBoxdipZP18;
         }

         private void InitGradesZIPDiplom(TextBox[] masivGrades)
         {
             masivGrades[0] = textBoxdipZIP1;
             masivGrades[1] = textBoxdipZIP2;
             masivGrades[2] = textBoxdipZIP3;
             masivGrades[3] = textBoxdipZIP4;
             masivGrades[4] = textBoxdipZIP5;
             masivGrades[5] = textBoxdipZIP6;
             masivGrades[6] = textBoxdipZIP7;
             masivGrades[7] = textBoxdipZIP8;
             masivGrades[8] = textBoxdipZIP9;
             masivGrades[9] = textBoxdipZIP10;
             masivGrades[10] = textBoxdipZIP11;
             masivGrades[11] = textBoxdipZIP12;
             masivGrades[12] = textBoxdipZIP13;
             masivGrades[13] = textBoxdipZIP14;
             masivGrades[14] = textBoxdipZIP15;
             masivGrades[15] = textBoxdipZIP16;
             masivGrades[16] = textBoxdipZIP17;
             masivGrades[17] = textBoxdipZIP18;
         }

         //промяна на оценките в 9 клас
         private void buttonEdit9klas_Click(object sender, EventArgs e)
         {
             ESchoolEntities context=new ESchoolEntities ();
             InitGrades9klas(masivGrades);
             bool flagError =false ;
             var grades9klas = from gr9klas in context.Grades9Class
                               where gr9klas.StudentID == studentID
                               select gr9klas;
             int grade;
             int sbjID=0;
             foreach (var item in grades9klas)
             {
                
                 if (item.Grades!=0)
                 {    sbjID = item.SubjectID;
                
                     if (sbjID <=3 && masivGrades[sbjID - 1].Text != "")
                        {
                             grade = int.Parse(masivGrades[sbjID - 1].Text);
                             if (grade>=3 && grade <=6)
                             {
                                 item.Grades = grade;  
                             }
                             else
                             {
                                 flagError = true;
                             }
                             
                         }
                     //за РЕ
                     else if (sbjID <= 4 && masivGrades[sbjID - 2].Text != "")
                     {
                         grade = int.Parse(masivGrades[sbjID - 2].Text);
                         if (grade>=3 && grade <=6)
                         {
                              item.Grades = grade;
                         }
                         else
                         {
                             flagError = true;
                         }
                        

                     }
                     //за ФЕ
                     else if (sbjID <= 5)
                     {
                         grade = int.Parse(masivGrades[sbjID - 3].Text);
                         if (grade >= 3 && grade <= 6)
                         {
                             item.Grades = grade;
                         }
                         else
                         {
                             flagError = true;
                         }
                         
                     }
                     else if (sbjID <= 20 && masivGrades[sbjID - 3].Text != "")
                     {
                         grade = int.Parse(masivGrades[sbjID - 3].Text);
                         if (grade >= 3 && grade <= 6)
                         {
                             item.Grades = grade;
                         }
                         else
                         {
                             flagError = true;
                         }
                        

                     }
                
                 }
                 if (sbjID > 20)
                     break;
             }
             if (!flagError )
             {
                 context.SaveChanges();
                 MessageBox.Show("Оценките за 9 клас са променени! Направете промяна и на окончателните оценки!");
                 buttonEditFinaly.Enabled = true;
                 buttonEditFinaly.ForeColor = Color.Red; 
             }
             else
             {
                 MessageBox.Show("Записът невъзможен. Има грешна оценка!");
             }
            

         }

         //промяна на оценките в 10 клас
         private void buttonEdit10klas_Click(object sender, EventArgs e)
         {
             ESchoolEntities context = new ESchoolEntities();
             InitGrades10klas(masivGrades);
             bool flagError = false;
             var grades10klas = from gr10klas in context.Grades10Class
                                where gr10klas.StudentID == studentID
                                select gr10klas;
             int grade;
             int sbjID = 0;
             foreach (var item in grades10klas)
             {

                 if (item.Grades != 0)
                 {
                     sbjID = item.SubjectID;

                     if (sbjID <= 3 && masivGrades[sbjID - 1].Text != "")
                     {
                         grade = int.Parse(masivGrades[sbjID - 1].Text);
                         if (grade>=3 && grade <=6)
                         {
                             item.Grades = grade; 
                         }
                         else
                         {
                             flagError = true;
                         }
                     }
                     //за РЕ
                     else if (sbjID <= 4 && masivGrades[sbjID - 2].Text != "")
                     {
                         grade = int.Parse(masivGrades[sbjID - 2].Text);
                         if (grade >= 3 && grade <= 6)
                         {
                             item.Grades = grade;
                         }
                         else
                         {
                             flagError = true;
                         }

                     }
                     //за ФЕ
                     else if (sbjID <= 5)
                     {
                         grade = int.Parse(masivGrades[sbjID - 3].Text);
                         if (grade >= 3 && grade <= 6)
                         {
                             item.Grades = grade;
                         }
                         else
                         {
                             flagError = true;
                         }
                     }
                     else if (sbjID <= 20 && masivGrades[sbjID - 3].Text != "")
                     {
                         grade = int.Parse(masivGrades[sbjID - 3].Text);
                         if (grade >= 3 && grade <= 6)
                         {
                             item.Grades = grade;
                         }
                         else
                         {
                             flagError = true;
                         }

                     }

                 }
                 if (sbjID > 20)
                     break;
             }
             if (!flagError)
             {
                 context.SaveChanges();
                 MessageBox.Show("Оценките за 10 клас са променени! Направете промяна и на окончателните оценки!");
                 buttonEditFinaly.Enabled = true;
                 buttonEditFinaly.ForeColor = Color.Red;
             }
             else
             {
                 MessageBox.Show("Записът невъзможен. Има грешна оценка!");
             }
         }

         //промяна на оценките в 11 клас
         private void buttonEdit11klas_Click(object sender, EventArgs e)
         {
             ESchoolEntities context = new ESchoolEntities();
             InitGrades11klas(masivGrades);
             bool flagError = false;
             var grades11klas = from gr11klas in context.Grades11Class
                                where gr11klas.StudentID == studentID
                                select gr11klas;
             int grade;
             int sbjID = 0;
             foreach (var item in grades11klas)
             {

                 if (item.Grades != 0)
                 {
                     sbjID = item.SubjectID;

                     if (sbjID <= 3 && masivGrades[sbjID - 1].Text != "")
                     {
                         grade = int.Parse(masivGrades[sbjID - 1].Text);
                         if (grade >= 3 && grade <= 6)
                         {
                             item.Grades = grade;
                         }
                         else
                         {
                             flagError = true;
                         }
                     }
                     //за РЕ
                     else if (sbjID <= 4 && masivGrades[sbjID - 2].Text != "")
                     {
                         grade = int.Parse(masivGrades[sbjID - 2].Text);
                         item.Grades = grade;

                     }
                     //за ФЕ
                     else if (sbjID <= 5)
                     {
                         grade = int.Parse(masivGrades[sbjID - 3].Text);
                         if (grade >= 3 && grade <= 6)
                         {
                             item.Grades = grade;
                         }
                         else
                         {
                             flagError = true;
                         }
                     }
                     else if (sbjID <= 20 && masivGrades[sbjID - 3].Text != "")
                     {
                         grade = int.Parse(masivGrades[sbjID - 3].Text);
                         if (grade >= 3 && grade <= 6)
                         {
                             item.Grades = grade;
                         }
                         else
                         {
                             flagError = true;
                         }

                     }

                 }
                 if (sbjID > 20)
                     break;
             }
             if (!flagError)
             {
                 context.SaveChanges();
                 MessageBox.Show("Оценките  за 11 клас са променени! Направете промяна и на окончателните оценки!");
                 buttonEditFinaly.Enabled = true;
                 buttonEditFinaly.ForeColor = Color.Red;
             }
             else
             {
                 MessageBox.Show("Записът невъзможен. Има грешна оценка!");
             }
         }

         //промяна на оценките в 12 клас
         private void buttonEdit12klas_Click(object sender, EventArgs e)
         {
             ESchoolEntities context = new ESchoolEntities();
             InitGrades12klas(masivGrades);
             bool flagError =false;
             var grades12klas = from gr12klas in context.Grades12Class
                                where gr12klas.StudentID == studentID
                                select gr12klas;
             int grade;
             int sbjID = 0;
             foreach (var item in grades12klas)
             {

                 if (item.Grades != 0)
                 {
                     sbjID = item.SubjectID;

                     if (sbjID <= 3 && masivGrades[sbjID - 1].Text != "")
                     {
                         grade = int.Parse(masivGrades[sbjID - 1].Text);
                         if (grade >= 3 && grade <= 6)
                         {
                             item.Grades = grade;
                         }
                         else
                         {
                             flagError = true;
                         }
                     }
                     //за РЕ
                     else if (sbjID <= 4 && masivGrades[sbjID - 2].Text != "")
                     {
                         grade = int.Parse(masivGrades[sbjID - 2].Text);
                         if (grade >= 3 && grade <= 6)
                         {
                             item.Grades = grade;
                         }
                         else
                         {
                             flagError = true;
                         }

                     }
                     //за ФЕ
                     else if (sbjID <= 5)
                     {
                         grade = int.Parse(masivGrades[sbjID - 3].Text);
                         if (grade >= 3 && grade <= 6)
                         {
                             item.Grades = grade;
                         }
                         else
                         {
                             flagError = true;
                         }
                     }
                     else if (sbjID <= 20 && masivGrades[sbjID - 3].Text != "")
                     {
                         grade = int.Parse(masivGrades[sbjID - 3].Text);
                         if (grade >= 3 && grade <= 6)
                         {
                             item.Grades = grade;
                         }
                         else
                         {
                             flagError = true;
                         }

                     }

                 }
                 if (sbjID > 20)
                     break;
             }

             if (!flagError)
             {
                 context.SaveChanges();
                 MessageBox.Show("Оценките  за 12 клас са променени! Направете промяна и на окончателните оценки!");
                 buttonEditFinaly.Enabled = true;
                 buttonEditFinaly.ForeColor = Color.Red;
             }
             else
             {
                 MessageBox.Show("Записът невъзможен. Има грешна оценка!");
             }
         }
        //извеждане и показване данните на ученика, ако са въведени в базата
        private void buttonShow_Click(object sender, EventArgs e)
        {
            ESchoolEntities context = new ESchoolEntities();
            Students stu = GetStudentByID(context, studentID);
            textBoxName.Text = stu.FirstName + "  " + stu.SecondName + "  " + stu.LastName;
            textBoxNumber.Text = stu.NumberInClass.ToString();

            if (comboBox1Lang.SelectedItem == null || comboBox2Lang.SelectedItem == null)
            {
                MessageBox.Show("Не си избрал първи и втори чужд език!");
            }
            else
            {

                InitSubjects(masivSubjects);
                //показва оценките на ученика в 9 клас по всички предмети ЗП

                InitGrades9klas(masivGrades);
                var datasorce9kl = from grades9Class in context.Grades9Class
                                   join subject in context.Subjects on grades9Class.SubjectID equals subject.SubjectID
                                   where grades9Class.StudentID == studentID
                                   select new
                                   {
                                       grades9Class.Subjects.SubjectID,
                                       grades9Class.Subjects.SubjectName,
                                       grades9Class.Grades
                                   };
                string strSubject = "";
                for (int i = 0; i <= 17; i++)
                {
                    bool flag = false;
                    strSubject = masivSubjects[i];
                    foreach (var item in datasorce9kl)
                    {

                        if (item.SubjectName.Trim() == strSubject)
                        {
                            masivGrades[i].Text = item.Grades.ToString();
                            flag = true;
                            break;
                        }

                        if (flag)
                            break;
                    }
                }
                // показва оценките на ученика в 9 клас по всички предмети ЗИП
                InitGradesZIP9klas(masivGrades);
                for (int i = 0; i < 18; i++)
                {
                    bool flag = false;
                    strSubject = masivSubjects[i] + "-ЗИП";
                    foreach (var item in datasorce9kl)
                    {

                        if (item.SubjectName.Trim() == strSubject)
                        {
                            masivGrades[i].Text = item.Grades.ToString();
                            flag = true;
                            break;
                        }
                        if (flag)
                            break;
                    }
                }
                //оценките от 9 клас ЗПП във втория таб
                masivTBox[0] = textBox9ZPP1;
                masivTBox[1] = textBox9ZPP2;
                masivTBox[2] = textBox9ZPP3;
                TextBox[] masivZPP = new TextBox[] { textBox1ZPP, textBox2ZPP, textBox3ZPP };
                for (int i = 0; i < 3; i++)
                {
                    bool flag = false;
                    strSubject = masivZPP[i].Text;
                    foreach (var item in datasorce9kl)
                    {

                        if (item.SubjectName.Trim() == strSubject)
                        {
                            masivTBox[i].Text = item.Grades.ToString();
                            flag = true;
                            break;
                        }
                        if (flag)
                            break;
                    }

                }
                //показване на  оценките от 9 клас СИП
                ComboBox[] masivCombo = new ComboBox[] { comboBox1SIP, comboBox2SIP, comboBox3SIP };
                masivTBox[0] = textBox9SIP1;
                masivTBox[1] = textBox9SIP2;
                masivTBox[2] = textBox9SIP3;
                for (int i = 0; i < 3; i++)
                {
                    bool flag = false;
                    if (masivCombo[i].SelectedItem != null)
                    {
                        strSubject = masivCombo[i].SelectedItem.ToString();
                        foreach (var item in datasorce9kl)
                        {

                            if (item.SubjectName.Trim() == strSubject)
                            {
                                masivTBox[i].Text = item.Grades.ToString();
                                flag = true;
                                break;
                            }
                            if (flag)
                                break;
                        }
                    }

                }

                // показване на оценките от 10 клас ЗП
                InitGrades10klas(masivGrades);
                var datasorce10kl = from grades10Class in context.Grades10Class
                                    join subject in context.Subjects on grades10Class.SubjectID equals subject.SubjectID
                                    where grades10Class.StudentID == studentID
                                    select new
                                    {
                                        grades10Class.Subjects.SubjectID,
                                        grades10Class.Subjects.SubjectName,
                                        grades10Class.Grades
                                    };


                for (int i = 0; i < 18; i++)
                {
                    bool flag = false;
                    strSubject = masivSubjects[i];
                    foreach (var item in datasorce10kl)
                    {

                        if (item.SubjectName.Trim() == strSubject)
                        {
                            masivGrades[i].Text = item.Grades.ToString();
                            flag = true;
                            break;
                        }
                        if (flag)
                            break;
                    }
                }
                // показва оценките на ученика в 10 клас  ЗИП
                InitGradesZIP10klas(masivGrades);
                for (int i = 0; i < 18; i++)
                {
                    bool flag = false;
                    strSubject = masivSubjects[i] + "-ЗИП";
                    foreach (var item in datasorce10kl)
                    {

                        if (item.SubjectName.Trim() == strSubject)
                        {
                            masivGrades[i].Text = item.Grades.ToString();
                            flag = true;
                            break;
                        }
                        if (flag)
                            break;
                    }
                }

                //оценките от 10 клас ЗПП
                masivTBox[0] = textBox10ZPP1;
                masivTBox[1] = textBox10ZPP2;
                masivTBox[2] = textBox10ZPP3;
                for (int i = 0; i < 3; i++)
                {
                    bool flag = false;
                    strSubject = masivZPP[i].Text;
                    foreach (var item in datasorce10kl)
                    {

                        if (item.SubjectName.Trim() == strSubject)
                        {
                            masivTBox[i].Text = item.Grades.ToString();
                            flag = true;
                            break;
                        }
                        if (flag)
                            break;
                    }

                }
                // оценките от 10 клас СИП
                masivTBox[0] = textBox10SIP1;
                masivTBox[1] = textBox10SIP2;
                masivTBox[2] = textBox10SIP3;
                for (int i = 0; i < 3; i++)
                {
                    bool flag = false;
                    if (masivCombo[i].SelectedItem != null)
                    {

                        strSubject = masivCombo[i].SelectedItem.ToString();
                        foreach (var item in datasorce10kl)
                        {

                            if (item.SubjectName.Trim() == strSubject)
                            {
                                masivTBox[i].Text = item.Grades.ToString();
                                flag = true;
                                break;
                            }
                            if (flag)
                                break;
                        }
                    }

                }
                // показване на оценките от 11 клас ЗП
                InitGrades11klas(masivGrades);
                var datasorce11kl = from grades11Class in context.Grades11Class
                                    join subject in context.Subjects on grades11Class.SubjectID equals subject.SubjectID
                                    where grades11Class.StudentID == studentID
                                    select new
                                    {
                                        grades11Class.Subjects.SubjectID,
                                        grades11Class.Subjects.SubjectName,
                                        grades11Class.Grades
                                    };


                for (int i = 0; i < 18; i++)
                {
                    bool flag = false;
                    strSubject = masivSubjects[i];
                    foreach (var item in datasorce11kl)
                    {

                        if (item.SubjectName.Trim() == strSubject)
                        {
                            masivGrades[i].Text = item.Grades.ToString();
                            flag = true;
                            break;
                        }
                        if (flag)
                            break;
                    }
                }

                // показва оценките на ученика в 11 клас  ЗИП
                InitGradesZIP11klas(masivGrades);
                for (int i = 0; i < 18; i++)
                {
                    bool flag = false;
                    strSubject = masivSubjects[i] + "-ЗИП";
                    foreach (var item in datasorce11kl)
                    {

                        if (item.SubjectName.Trim() == strSubject)
                        {
                            masivGrades[i].Text = item.Grades.ToString();
                            flag = true;
                            break;
                        }
                        if (flag)
                            break;
                    }
                }

                //оценките от 11 клас ЗПП
                masivTBox[0] = textBox11ZPP1;
                masivTBox[1] = textBox11ZPP2;
                masivTBox[2] = textBox11ZPP3;
                for (int i = 0; i < 3; i++)
                {
                    bool flag = false;
                    strSubject = masivZPP[i].Text;
                    foreach (var item in datasorce11kl)
                    {

                        if (item.SubjectName.Trim() == strSubject)
                        {
                            masivTBox[i].Text = item.Grades.ToString();
                            flag = true;
                            break;
                        }
                        if (flag)
                            break;
                    }

                }
                // оценките от 11 клас СИП
                masivTBox[0] = textBox11SIP1;
                masivTBox[1] = textBox11SIP2;
                masivTBox[2] = textBox11SIP3;
                for (int i = 0; i < 3; i++)
                {
                    bool flag = false;
                    if (masivCombo[i].SelectedItem!=null)
                    {
                        strSubject = masivCombo[i].SelectedItem.ToString();
                        foreach (var item in datasorce11kl)
                        {

                            if (item.SubjectName.Trim() == strSubject)
                            {
                                masivTBox[i].Text = item.Grades.ToString();
                                flag = true;
                                break;
                            }
                            if (flag)
                                break;
                        }
                    }

                }
                //показване на оценките от 12 клас ЗП
                InitGrades12klas(masivGrades);
                var datasorce12kl = from grades12Class in context.Grades12Class
                                    join subject in context.Subjects on grades12Class.SubjectID equals subject.SubjectID
                                    where grades12Class.StudentID == studentID
                                    select new
                                    {
                                        grades12Class.Subjects.SubjectID,
                                        grades12Class.Subjects.SubjectName,
                                        grades12Class.Grades
                                    };

                for (int i = 0; i < 18; i++)
                {
                    bool flag = false;
                    strSubject = masivSubjects[i];
                    foreach (var item in datasorce12kl)
                    {

                        if (item.SubjectName.Trim() == strSubject)
                        {
                            masivGrades[i].Text = item.Grades.ToString();
                            flag = true;
                            break;
                        }
                        if (flag)
                            break;
                    }
                }

                // показва оценките на ученика в 12 клас  ЗИП

                InitGradesZIP12klas(masivGrades);
                for (int i = 0; i < 18; i++)
                {
                    bool flag = false;
                    strSubject = masivSubjects[i].Trim() + "-ЗИП";
                    foreach (var item in datasorce12kl)
                    {

                        if (item.SubjectName.Trim() == strSubject)
                        {
                            masivGrades[i].Text = item.Grades.ToString();
                            flag = true;
                            break;
                        }
                        if (flag)
                            break;
                    }
                }
                //оценките от 12 клас ЗПП
                masivTBox[0] = textBox12ZPP1;
                masivTBox[1] = textBox12ZPP2;
                masivTBox[2] = textBox12ZPP3;
                for (int i = 0; i < 3; i++)
                {
                    bool flag = false;
                    strSubject = masivZPP[i].Text;
                    foreach (var item in datasorce12kl)
                    {

                        if (item.SubjectName.Trim() == strSubject)
                        {
                            masivTBox[i].Text = item.Grades.ToString();
                            flag = true;
                            break;
                        }
                        if (flag)
                            break;
                    }

                }
                // оценките от 12 клас СИП
                masivTBox[0] = textBox12SIP1;
                masivTBox[1] = textBox12SIP2;
                masivTBox[2] = textBox12SIP3;
                for (int i = 0; i < 3; i++)
                {
                    bool flag = false;
                    if (masivCombo[i].SelectedItem!=null)
                    {
                        strSubject = masivCombo[i].SelectedItem.ToString();
                        foreach (var item in datasorce12kl)
                        {

                            if (item.SubjectName.Trim() == strSubject)
                            {
                                masivTBox[i].Text = item.Grades.ToString();
                                flag = true;
                                break;
                            }
                            if (flag)
                                break;
                        }
                    }

                }


                //показва  оценките от  дипломата
                var datasorceDiplom = from gradesDiploms in context.Diploms
                                      join subject in context.Subjects on gradesDiploms.SubjectID equals subject.SubjectID
                                      where gradesDiploms.StudentID == studentID
                                      select new
                                      {
                                          gradesDiploms.Subjects.SubjectID,
                                          gradesDiploms.Subjects.SubjectName,
                                          gradesDiploms.Grades
                                      };

                //показва окончателните оценки от ЗП от дипломата
                double total = 0;
                int br = 0;
                InitGradesZPDiplom(masivGrades);
                for (int i = 0; i < 18; i++)
                {
                    bool flag = false;
                    strSubject = masivSubjects[i];
                    foreach (var item in datasorceDiplom)
                    {

                        if (item.SubjectName.Trim() == strSubject)
                        {
                            masivGrades[i].Text = ((double)item.Grades).ToString("F2");
                            total += (double)item.Grades;
                            br++;
                            flag = true;
                        }
                        if (flag)
                            break;
                    }
                }
                total /= br;
                textBoxSrZP.Text = total.ToString("F2");
                //показва окончателните оценки от ЗИП от дипломата
                InitGradesZIPDiplom(masivGrades);
                double totalZIP = 0;
                int brZIP = 0;
                for (int i = 0; i < 18; i++)
                {
                    bool flag = false;
                    strSubject = masivSubjects[i] + "-ЗИП";
                    foreach (var item in datasorceDiplom)
                    {

                        if (item.SubjectName.Trim() == strSubject)
                        {

                            masivGrades[i].Text = ((double)item.Grades).ToString("F2");
                            totalZIP += (double)item.Grades;
                            brZIP++;
                            flag = true;
                        }
                        if (flag)
                            break;
                    }
                }

                textBoxSumOcZIP.Text = totalZIP.ToString("F2");
                textBoxBrOcZIP.Text = brZIP.ToString();

                //показва оценките от ДЗИ
                masivTBox[0] = textBox1DZI;
                masivTBox[1] = textBox2DZI;
                masivTBox[2] = textBox3DZI;
                masivTBox[3] = textBox4DZI;
                masivCombo = new ComboBox[] { comboBox1DZI, comboBox2DZI, comboBox3DZI, comboBox4DZI };
                total = 0;
                br = 0;
                for (int i = 0; i < 4; i++)
                {
                    bool flag = false;
                    if (masivCombo[i].SelectedItem != null)
                    {
                        strSubject = masivCombo[i].SelectedItem.ToString();
                        foreach (var item in datasorceDiplom)
                        {

                            if (item.SubjectName.Trim() == strSubject)
                            {
                                masivTBox[i].Text = ((double)item.Grades).ToString("F2");
                                total += double.Parse(masivTBox[i].Text);
                                br++;
                                flag = true;
                                break;
                            }
                            if (flag)
                                break;
                        }
                    }
                }
                total /= br;
                textBoxDZISrUsp.Text = total.ToString("F2");

                //показва окончателните оценки от ЗПП
                masivTBox[0] = textBoxOkZPP1;
                masivTBox[1] = textBoxOkZPP2;
                masivTBox[2] = textBoxOkZPP3;
                total = 0;
                br = 0;
                for (int i = 0; i < 3; i++)
                {
                    bool flag = false;
                    strSubject = masivZPP[i].Text;
                    foreach (var item in datasorceDiplom)
                    {

                        if (item.SubjectName.Trim() == strSubject)
                        {
                            masivTBox[i].Text = ((double)item.Grades).ToString("F2");
                            total += double.Parse(masivTBox[i].Text);
                            br++;
                            flag = true;
                            break;
                        }
                        if (flag)
                            break;
                    }

                }
                total = total + totalZIP;//сумираме оценките от ЗИП и ЗПП
                br = br + brZIP; //сумираме броя им
                total = total / br;
                textBoxZPPZIP.Text = total.ToString("F2");

                //показва окончателните оценки от  СИП
                masivTBox[0] = textBoxOkon1;
                masivTBox[1] = textBoxOkon2;
                masivTBox[2] = textBoxOkon3;

                masivCombo = new ComboBox[] { comboBox1SIP, comboBox2SIP, comboBox3SIP };
                for (int i = 0; i < 3; i++)
                {
                    bool flag = false;
                    if (masivCombo[i].SelectedItem != null)
                    {
                        strSubject = masivCombo[i].SelectedItem.ToString();
                        foreach (var item in datasorceDiplom)
                        {

                            if (item.SubjectName.Trim() == strSubject)
                            {

                                masivTBox[i].Text = ((double)item.Grades).ToString("F2");
                                flag = true;
                                break;
                            }
                            if (flag)
                                break;
                        }
                    }
                }

                //показва успех от дипломата
                Students stud = GetStudentByID(context, studentID);
                if (stu.SuccessDiplom != null)
                {
                    textBoxSrUspeh.Text = ((double)stud.SuccessDiplom).ToString("F2");

                    buttonFinally.Enabled = false;
                    buttonSave12kl.Enabled = false;
                    buttonSave11kl.Enabled = false;
                    buttonSave10kl.Enabled = false;
                    buttonSave9kl.Enabled = false;
                    buttonSaveDZI.Enabled = false;
                    buttonSaveSIP.Enabled = false;
                    buttonSaveZPP.Enabled = false;
                    buttonEdit.Enabled = true;

                }
                else
                {
                    MessageBox.Show("Не са въведени оценки на ученика! Може да започнете въвеждане.", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    buttonSave9kl.Enabled = true;

                }
            }

            
            

        }
        //намира оценките от 9 клас на даден ученик от базата
        private static Grades9Class GetGrades9Class(ESchoolEntities context, int studentID)
        {
            Grades9Class grades9Class = context.Grades9Class.FirstOrDefault(
                 p => p.StudentID == studentID);
            return grades9Class;
        }

       
        private void buttonClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }



        //показва оценката с думи
        private void textBox1DZI_TextChanged(object sender, EventArgs e)
        {
            
            if (!string.IsNullOrEmpty(textBox1DZI.Text))
            {
                try
                {
                    float grade = float.Parse(textBox1DZI.Text);
                    GradeText2(grade);
                    textBox1DZIw.Text = str;
                    
                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте числа с десетична запетая за оценка.");
                    textBox1DZI.Clear();

                }
            }
            else
            {
                textBox1DZIw.Text = "";
            }
        }

        private void textBox2DZI_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox2DZI.Text))
            {
                try
                {
                    float grade = float.Parse(textBox2DZI.Text);
                    
                        GradeText2(grade);
                        textBox2DZIw.Text = str;
                   
                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте числа с десетична запетая за оценка.");
                    textBox2DZI.Clear();

                }
            }
            else
            {
                textBox2DZIw.Text = "";
            }
        }

        private void textBox3DZI_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox3DZI.Text))
            {
                try
                {
                    float grade = float.Parse(textBox3DZI.Text);
                   
                        GradeText2(grade);
                        textBox3DZIw.Text = str;
                    
                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте числа с десетична запетая за оценка.");
                    textBox3DZI.Clear();

                }
            }
            else
            {
                textBox3DZIw.Text = "";
            }
        }

        private void textBox4DZI_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox4DZI.Text))
            {
                try
                {
                    float grade = float.Parse(textBox4DZI.Text);
                   
                        GradeText2(grade);
                        textBox4DZIw.Text = str;
                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте числа с десетична запетая за оценка.");
                    textBox4DZI.Clear();

                }
            }
            else
            {
                textBox4DZIw.Text = "";
            }
        }

        private void textBoxDZISrUsp_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBoxDZISrUsp.Text))
            {
                try
                {
                    float grade = float.Parse(textBoxDZISrUsp.Text);
                    GradeText2(grade);
                    textBoxDZISrUspW.Text = str;
                   
                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте числа с десетична запетая за оценка.");
                    textBoxDZISrUsp.Clear();

                }
            }
            else
            {
                textBoxDZISrUspW.Text = "";
            }
        }

        private void textBoxZPPZIP_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBoxZPPZIP.Text))
            {
                try
                {
                    GradeText2(float.Parse(textBoxZPPZIP.Text));
                    textBoxZPPZIPW.Text = str;
                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте числа с десетична запетая за оценка.");
                    textBoxZPPZIP.Clear();

                }
                    
            }
            else
            {
                textBoxZPPZIPW.Text = "";
            }
          
        }

        private void textBoxOkZPP1_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBoxOkZPP1.Text))
            {
                try
                {
                    GradeText2(float.Parse(textBoxOkZPP1.Text));
                    textBoxOkZPPw1.Text = str;
                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте числа с десетична запетая за оценка.");
                    textBoxOkZPP1.Clear();

                }
            }

            else
            {
                textBoxOkZPPw1.Text = "";
            }
        }

        private void textBoxOkZPP2_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBoxOkZPP2.Text))
            {
                try
                {
                    GradeText2(float.Parse(textBoxOkZPP2.Text));
                    textBoxOkZPPw2.Text = str;
                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте числа с десетична запетая за оценка.");
                    textBoxOkZPP2.Clear();

                }
            }
            else
            {
                textBoxOkZPPw2.Text = "";
            }
        }

        private void textBoxOkZPP3_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBoxOkZPP3.Text))
            {
                try
                {
                    GradeText2(float.Parse(textBoxOkZPP3.Text));
                    textBoxOkZPPw3.Text = str;
                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте числа с десетична запетая за оценка.");
                    textBoxOkZPP3.Clear();

                }
            }
            else
            {
                textBoxOkZPPw3.Text = "";
            }
        }

       

        private void textBox9ZPP1_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox9ZPP1.Text))
            {
                try
                {
                    int grade = int.Parse(textBox9ZPP1.Text);
                   
                        GradeText(grade);
                        textBox9ZPPw1.Text = str;
                   

                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox9ZPP1.Clear();

                }
            }
            else
            {
                textBox9ZPPw1.Text = "";
            }
           

        }

        private void textBox10ZPP1_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox10ZPP1.Text))
            {
                try
                {
                    int grade = int.Parse(textBox10ZPP1.Text);
                    
                        GradeText(grade);
                        textBox10ZPPw1.Text = str;
                   

                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox10ZPP1.Clear();

                }
            }
            else
            {
                textBox10ZPPw1.Text = "";
            }
           
        }

        private void textBox11ZPP1_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox11ZPP1.Text))
            {
                try
                {
                    int grade = int.Parse(textBox11ZPP1.Text);
                    
                        GradeText(grade);
                        textBox11ZPPw1.Text = str;
                    

                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox11ZPP1.Clear();

                }
            }
            else
            {
                textBox11ZPPw1.Text = "";
            }
        }

        private void textBox12ZPP1_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox12ZPP1.Text))
            {
                try
                {
                    int grade = int.Parse(textBox12ZPP1.Text);
                    
                        GradeText(grade);
                        textBox12ZPPw1.Text = str;
                    

                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox12ZPP1.Clear();

                }
            }
            else
            {
                textBox12ZPPw1.Text = "";
            }
           
        }

        private void textBox9ZPP2_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox9ZPP2.Text))
            {
                try
                {
                    int grade = int.Parse(textBox9ZPP2.Text);
                    
                        GradeText(grade);
                        textBox9ZPPw2.Text = str;
                    

                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox9ZPP2.Clear();

                }
            }
            else
            {
                textBox9ZPPw2.Text = "";
            }
        }

        private void textBox10ZPP2_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox10ZPP2.Text))
            {
                try
                {
                    int grade = int.Parse(textBox10ZPP2.Text);
                   
                        GradeText(grade);
                        textBox10ZPPw2.Text = str;
                    

                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox10ZPP2.Clear();

                }
            }
            else
            {
                textBox10ZPPw2.Text = "";
            }
        }

        private void textBox11ZPP2_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox11ZPP2.Text))
            {
                try
                {
                    int grade = int.Parse(textBox11ZPP2.Text);
                    
                        GradeText(grade);
                        textBox11ZPPw2.Text = str;
                    

                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox11ZPP2.Clear();

                }
            }
            else
            {
                textBox11ZPPw2.Text = "";
            }
            //buttonSaveZPP.Enabled = true;
        }

        private void textBox12ZPP2_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox12ZPP2.Text))
            {
                try
                {
                    int grade = int.Parse(textBox12ZPP2.Text);
                    
                        GradeText(grade);
                        textBox12ZPPw2.Text = str;
                    
                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox12ZPP2.Clear();

                }
            }
            else
            {
                textBox12ZPPw2.Text = "";
            }
        }

        private void textBox9ZPP3_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox9ZPP3.Text))
            {
                try
                {
                    int grade = int.Parse(textBox9ZPP3.Text);
                    
                        GradeText(grade);
                        textBox9ZPPw3.Text = str;
                    

                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox9ZPP3.Clear();

                }
            }
            else
            {
                textBox9ZPPw3.Text = "";
            }
        }

        private void textBox10ZPP3_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox10ZPP3.Text))
            {
                try
                {
                    int grade = int.Parse(textBox10ZPP3.Text);
                    
                        GradeText(grade);
                        textBox10ZPPw3.Text = str;
                    

                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox10ZPP3.Clear();

                }
            }
            else
            {
                textBox10ZPPw3.Text = "";
            }
        }

        private void textBox11ZPP3_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox11ZPP3.Text))
            {
                try
                {
                    int grade = int.Parse(textBox11ZPP3.Text);
                    
                        GradeText(grade);
                        textBox11ZPPw3.Text = str;
                    

                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox11ZPP3.Clear();

                }
            }
            else
            {
                textBox11ZPPw3.Text = "";
            }
        }

        private void textBox12ZPP3_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox12ZPP3.Text))
            {
                try
                {
                    int grade = int.Parse(textBox12ZPP3.Text);
                    
                        GradeText(grade);
                        textBox12ZPPw3.Text = str;
                    

                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox12ZPP3.Clear();

                }
            }
            else
            {
                textBox12ZPPw3.Text = "";
            }
            //buttonSaveZPP.Enabled = true;
        }
      //-------
        private void textBoxOkon1_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBoxOkon1.Text))
            {
                
                    GradeText2(float.Parse(textBoxOkon1.Text));
                    textBoxOkW1.Text = str;
                
            }
            else
            {
                textBoxOkW1.Text = "";
            }
        }

        private void textBoxOkon2_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBoxOkon2.Text))
            {
               
                    GradeText2(float.Parse(textBoxOkon2.Text));
                    textBoxOkW2.Text = str;
                
            }
            else
            {
                textBoxOkW2.Text = "";
            }

        }
        private void textBoxOkon3_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBoxOkon3.Text))
            {
                    GradeText2(float.Parse(textBoxOkon3.Text));
                    textBoxOkW3.Text = str;
                
            }
            else
            {
                textBoxOkW3.Text = "";
            }
        }
        //-------
        private void textBox9SIP1_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox9SIP1.Text))
            {
                try
                {
                    GradeText(int.Parse(textBox9SIP1.Text));
                    textBox9SIPw1.Text = str;
                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox9SIP1.Clear();

                }
            }
            else
            {
                textBox9SIPw1.Text = "";
            }
            buttonSaveSIP.Enabled = true;
        }

        private void textBox10SIP1_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox10SIP1.Text))
            {
                try
                {
                    GradeText(int.Parse(textBox10SIP1.Text));
                    textBox10SIPw1.Text = str;
                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox10SIP1.Clear();

                }
            }
            else
            {
                textBox10SIPw1.Text = "";
            }
            buttonSaveSIP.Enabled = true;
        }

        private void textBox11SIP1_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox11SIP1.Text))
            {
                try
                {
                    GradeText(int.Parse(textBox11SIP1.Text));
                    textBox11SIPw1.Text = str;
                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox11SIP1.Clear();

                }
            }
            else
            {
                textBox11SIPw1.Text = "";
            }
        }

        private void textBox12SIP1_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox12SIP1.Text))
            {
                try
                {
                    GradeText(int.Parse(textBox12SIP1.Text));
                    textBox12SIPw1.Text = str;
                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox12SIP1.Clear();

                }
            }
            else
            {
                textBox12SIPw1.Text = "";
            }
        }

        private void textBox9SIP2_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox9SIP2.Text))
            {
                try
                {
                    GradeText(int.Parse(textBox9SIP2.Text));
                    textBox9SIPw2.Text = str;
                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox9SIP2.Clear();

                }
            }
            else
            {
                textBox9SIPw2.Text = "";
            }
        }

        private void textBox10SIP2_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox10SIP2.Text))
            {
                try
                {
                    GradeText(int.Parse(textBox10SIP2.Text));
                    textBox10SIPw2.Text = str;
                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox10SIP2.Clear();

                }
            }
            else
            {
                textBox10SIPw2.Text = "";
            }
        }

        private void textBox11SIP2_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox11SIP2.Text))
            {
                try
                {
                    GradeText(int.Parse(textBox11SIP2.Text));
                    textBox11SIPw2.Text = str;
                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox11SIP2.Clear();

                }
            }
            else
            {
                textBox11SIPw2.Text = "";
            }
        }

        private void textBox12SIP2_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox12SIP2.Text))
            {
                try
                {
                    GradeText(int.Parse(textBox12SIP2.Text));
                    textBox12SIPw2.Text = str;
                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox12SIP2.Clear();

                }
            }
            else
            {
                textBox12SIPw2.Text = "";
            }
        }
        private void textBox9SIP3_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox9SIP3.Text))
            {
                try
                {
                    GradeText(int.Parse(textBox9SIP3.Text));
                    textBox9SIPw3.Text = str;
                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox9SIP3.Clear();

                }
            }
            else
            {
                textBox9SIPw3.Text = "";
            }
        }

        private void textBox10SIP3_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox10SIP3.Text))
            {
                try
                {
                    GradeText(int.Parse(textBox10SIP3.Text));
                    textBox10SIPw3.Text = str;
                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox10SIP3.Clear();

                }
            }
            else
            {
                textBox10SIPw3.Text = "";
            }
        }

        private void textBox11SIP3_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox11SIP3.Text))
            {
                try
                {
                    GradeText(int.Parse(textBox11SIP3.Text));
                    textBox11SIPw3.Text = str;
                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox11SIP3.Clear();

                }
            }
            else
            {
                textBox11SIPw3.Text = "";
            }
        }

        private void textBox12SIP3_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox12SIP3.Text))
            {
                try
                {
                    GradeText(int.Parse(textBox12SIP3.Text));
                    textBox12SIPw3.Text = str;
                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox12SIP3.Clear();

                }
            }
            else
            {
                textBox12SIPw3.Text = "";
            }
        }

        //-----

        private void textBoxSrUspeh_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBoxSrUspeh.Text))
            {
                GradeText2(float.Parse(textBoxSrUspeh.Text));
                textBoxSrUspehW.Text = str;
            }
        }

        

        //-----------
        private void textBox9ZP1_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox9ZP1.Text))
            {
                try
                {
                    int grade = int.Parse(textBox9ZP1.Text);
                    
                        GradeText(grade);
                        textBox9Bel1.Text = str;  
                    
                   
                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox9ZP1.Clear();

                }
            }
            else
            {
                textBox9Bel1.Text = "";
            }
        }

        private void textBox9ZP2_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox9ZP2.Text))
            {
                try
                {
                    int grade = int.Parse(textBox9ZP2.Text);
                   
                        GradeText(grade);
                        textBox91Lang1.Text = str;
                    
                   
                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox9ZP2.Clear();

                }
            }
                 
            else
            {
                textBox91Lang1.Text = "";
            }
        }

        private void textBox9ZP3_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox9ZP3.Text))
            {
                try
                {
                    int grade = int.Parse(textBox9ZP3.Text);
                    
                        GradeText(grade);
                        textBox92Lang1.Text = str;
                   

                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox9ZP3.Clear();

                }
            }
            else
            {
                textBox92Lang1.Text = "";
            }
        }

        private void textBox9ZP4_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox9ZP4.Text))
            {
                try
                {
                    int grade = int.Parse(textBox9ZP4.Text);
                   
                        GradeText(grade);
                        textBox9Mat1.Text = str;
                   

                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox9ZP4.Clear();

                }
            }
            else
            {
                textBox9Mat1.Text = "";
            }
        }

        private void textBox9ZP5_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox9ZP5.Text))
            {
                try
                {
                    int grade = int.Parse(textBox9ZP5.Text);
                    
                        GradeText(grade);
                        textBox9Inf1.Text = str;
                  

                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox9ZP5.Clear();

                }
            }
            else
            {
                textBox9Inf1.Text = "";
            }
        }

        private void textBox9ZP6_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox9ZP6.Text))
            {
                try
                {
                    int grade = int.Parse(textBox9ZP6.Text);
                    
                        GradeText(grade);
                        textBox9IT1.Text = str;
                    

                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox9ZP6.Clear();

                }
            }
            else
            {
                textBox9IT1.Text = "";
            }
        }

        private void textBox9ZP7_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox9ZP7.Text))
            {
                try
                {
                    int grade = int.Parse(textBox9ZP7.Text);
                   
                        GradeText(grade);
                        textBox9Ist1.Text = str;
                    

                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox9ZP7.Clear();

                }
            }
            else
            {
                textBox9Ist1.Text = "";
            }
        }
       
        private void textBox9ZP9_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox9ZP9.Text))
            {
                try
                {
                    int grade = int.Parse(textBox9ZP9.Text);
                    
                        GradeText(grade);
                        textBox9Ps1.Text = str;
                    

                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox9ZP9.Clear();

                }
            }
            else
            {
                textBox9Ps1.Text = "";
            }
        }


        private void textBox9ZP16_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox9ZP16.Text))
            {
                try
                {
                    int grade = int.Parse(textBox9ZP16.Text);
                   
                        GradeText(grade);
                        textBox9Mz1.Text = str;
                    

                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox9ZP16.Clear();

                }
            }
            else
            {
                textBox9Mz1.Text = "";
            }
        }

        private void textBox9ZP17_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox9ZP17.Text))
            {
                try
                {
                    int grade = int.Parse(textBox9ZP17.Text);
                   
                        GradeText(grade);
                        textBox9Izobr1.Text = str;
                    

                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox9ZP17.Clear();

                }
            }
            else
            {
                textBox9Izobr1.Text = "";
            }
        }


        private void textBox9ZIP1_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox9ZIP1.Text))
            {
                try
                {
                    int grade = int.Parse(textBox9ZIP1.Text);
                   
                        GradeText(grade);
                        textBox9BelZIP1.Text = str;
                    

                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox9ZIP1.Clear();

                }
            }
            else
            {
                textBox9BelZIP1.Text = "";
            }
        }
  
        private void textBox9ZIP2_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox9ZIP2.Text))
            {
                try
                {
                    int grade = int.Parse(textBox9ZIP2.Text);
                   
                        GradeText(grade);
                        textBox9ZIP1Lang1.Text = str;
                    
                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox9ZIP2.Clear();

                }
            }
            else
            {
                textBox9ZIP1Lang1.Text = "";
            }

        }

        private void textBox9ZIP3_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox9ZIP3.Text))
            {
                try
                {
                    int grade = int.Parse(textBox9ZIP3.Text);
                    
                        GradeText(grade);
                        textBox92LangZIP1.Text = str;
                    

                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox9ZIP3.Clear();

                }
            }
            else
            {
                textBox92LangZIP1.Text = "";
            }

        }

        private void textBox9ZIP4_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox9ZIP4.Text))
            {
                try
                {
                    int grade = int.Parse(textBox9ZIP4.Text);
                    
                        GradeText(grade);
                        textBox9ZIPMat1.Text = str;
                    

                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox9ZIP4.Clear();

                }
            }
            else
            {
                textBox9ZIPMat1.Text = "";
            }
        }


        private void textBox9ZIP5_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox9ZIP5.Text))
            {
                try
                {
                    int grade = int.Parse(textBox9ZIP5.Text);
                    
                        GradeText(grade);
                        textBox9ZIPInf1.Text = str;
                    

                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox9ZIP5.Clear();

                }
            }
            else
            {
                textBox9ZIPInf1.Text = "";
            }
        }

        private void textBox9ZIP6_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox9ZIP6.Text))
            {
                try
                {
                    int grade = int.Parse(textBox9ZIP6.Text);
                    
                        GradeText(grade);
                        textBox9ZIPIT1.Text = str;
                    

                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox9ZIP6.Clear();

                }
            }
            else
            {
                textBox9ZIPIT1.Text = "";
            }
        }
        private void textBox9ZIP7_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox9ZIP7.Text))
            {
                try
                {
                    int grade = int.Parse(textBox9ZIP7.Text);
                    
                        GradeText(grade);
                        textBox9ZIPIst1.Text = str;
                    

                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox9ZIP7.Clear();

                }
            }
            else
            {
                textBox9ZIPIst1.Text = "";
            }
        }

        private void textBox9ZIP8_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox9ZIP8.Text))
            {
                try
                {
                    int grade = int.Parse(textBox9ZIP8.Text);
                   
                        GradeText(grade);
                        textBox9ZIPG1.Text = str;
                    

                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox9ZIP8.Clear();

                }
            }
            else
            {
                textBox9ZIPG1.Text = "";
            }
        }
          private void textBox9ZIP13_TextChanged(object sender, EventArgs e)
        {
              if (!string.IsNullOrEmpty(textBox9ZIP13.Text))
            {
                try
                {
                    int grade = int.Parse(textBox9ZIP13.Text);
                    
                        GradeText(grade);
                        textBox9BioZIP1.Text = str;
                    

                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox9ZIP13.Clear();

                }
            }
              else
              {
                  textBox9BioZIP1.Text = "";
              }
        }

        private void textBox9ZIP14_TextChanged(object sender, EventArgs e)
        {
               if (!string.IsNullOrEmpty(textBox9ZIP14.Text))
            {
                try
                {
                    int grade = int.Parse(textBox9ZIP14.Text);
                   
                        GradeText(grade);
                        textBox9ZIPFz1.Text = str;
                    

                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox9ZIP14.Clear();

                }
            }
               else
               {
                   textBox9ZIPFz1.Text = "";
               }
        }

        private void textBox9ZIP15_TextChanged(object sender, EventArgs e)
        {
               if (!string.IsNullOrEmpty(textBox9ZIP15.Text))
            {
                try
                {
                    int grade = int.Parse(textBox9ZIP15.Text);
                    
                        GradeText(grade);
                        textBox9ZIPHim1.Text = str;
                    

                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox9ZIP15.Clear();

                }
            }
               else
               {
                   textBox9ZIPHim1.Text = "";
               }
        }


        private void textBox10ZP1_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox10ZP1.Text))
            {
                try
                {
                    int grade = int.Parse(textBox10ZP1.Text);
                    
                        GradeText(grade);
                        textBox10Bel1.Text = str;
                    

                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox10ZP1.Clear();

                }
            }
            else
            {
                textBox10Bel1.Text = "";
            }
        }

        private void textBox10ZIP1_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox10ZIP1.Text))
            {
                try
                {
                    int grade = int.Parse(textBox10ZIP1.Text);
                    
                        GradeText(grade);
                        textBox10BelZIP1.Text = str;
                    

                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox10ZIP1.Clear();

                }
            }
            else
            {
                textBox10BelZIP1.Text = "";
            }
        }

        private void textBox11ZP1_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox11ZP1.Text))
            {
                try
                {
                    int grade = int.Parse(textBox11ZP1.Text);
                    
                        GradeText(grade);
                        textBox11Bel1.Text = str;
                    

                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox11ZP1.Clear();

                }
            }
            else
            {
                textBox11Bel1.Text ="";
            }
        }

        private void textBox11ZIP1_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox11ZIP1.Text))
            {
                try
                {
                    int grade = int.Parse(textBox11ZIP1.Text);
                    
                        GradeText(grade);
                        textBox11BelZIP1.Text = str;
                    

                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox11ZIP1.Clear();

                }
            }
            else
            {
                textBox11BelZIP1.Text = "";
            }
        }

        private void textBox12ZP1_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox12ZP1.Text))
            {
                try
                {
                    int grade = int.Parse(textBox12ZP1.Text);
                    
                        GradeText(grade);
                        textBox12Bel1.Text = str;
                    

                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox12ZP1.Clear();

                }
            }
            else
            {
                textBox12Bel1.Text = "";
            }
        }

        private void textBox12ZIP1_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox12ZIP1.Text))
            {
                try
                {
                    int grade = int.Parse(textBox12ZIP1.Text);
                   
                        GradeText(grade);
                        textBox12BelZIP1.Text = str;
                    

                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox12ZIP1.Clear();

                }
            }
            else
            {
                textBox12BelZIP1.Text = "";
            }
        }

        private void textBox10ZP2_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox10ZP2.Text))
            {
                try
                {
                    GradeText(int.Parse(textBox10ZP2.Text));
                    textBox101Lang1.Text = str;
                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox10ZP2.Clear();

                }
            }
            else
            {
                textBox101Lang1.Text = "";
            }
           
        }

        private void textBox10ZIP2_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox10ZIP2.Text))
            {
                try
                {
                    GradeText(int.Parse(textBox10ZIP2.Text));
                    textBox10ZIP1Lang1.Text = str;
                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox10ZIP2.Clear();

                }
            }
            else
            {
                textBox10ZIP1Lang1.Text = "";
            }
        }

        private void textBox11ZP2_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox11ZP2.Text))
            {
                try
                {
                    GradeText(int.Parse(textBox11ZP2.Text));
                    textBox111Lang1.Text = str;
                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox11ZP2.Clear();

                }
            }
            else
            {
                textBox111Lang1.Text = "";
            }
        }

        private void textBox11ZIP2_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox11ZIP2.Text))
            {
                try
                {
                    GradeText(int.Parse(textBox11ZIP2.Text));
                    textBox11ZIP1Lang1.Text = str;
                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox11ZIP2.Clear();

                }
            }
            else
            {
                textBox11ZIP1Lang1.Text = "";
            }
        }

        private void textBox12ZP2_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox12ZP2.Text))
            {
                try
                {
                    GradeText(int.Parse(textBox12ZP2.Text));
                    textBox121Lang1.Text = str;
                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox12ZP2.Clear();

                }
            }
            else
            {
                textBox121Lang1.Text = "";
            }
        }

        private void textBox12ZIP2_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox12ZIP2.Text))
            {
                try
                {
                    GradeText(int.Parse(textBox12ZIP2.Text));
                    textBox121LangZIP1.Text = str;
                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox12ZIP2.Clear();

                }
            }
            else
            {
                textBox121LangZIP1.Text = "";
            }
        }

        private void textBox10ZP3_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox10ZP3.Text))
            {
                try
                {
                    GradeText(int.Parse(textBox10ZP3.Text));
                    textBox102Lang1.Text = str;
                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox10ZP3.Clear();

                }
            }
            else
            {
                textBox102Lang1.Text = "";
            }
        }

        private void textBox10ZIP3_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox10ZIP3.Text))
            {
                try
                {
                    GradeText(int.Parse(textBox10ZIP3.Text));
                    textBox10ZIP2Lang1.Text = str;
                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox10ZIP3.Clear();

                }
            }
            else
            {
                textBox10ZIP2Lang1.Text = "";
            }
        }

        private void textBox11ZP3_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox11ZP3.Text))
            {
                try
                {
                    GradeText(int.Parse(textBox11ZP3.Text));
                    textBox112Lang1.Text = str;
                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox11ZP2.Clear();

                }
            }
            else
            {
                textBox112Lang1.Text = "";
            }
        }

        private void textBox11ZIP3_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox11ZIP3.Text))
            {
                try
                {
                    GradeText(int.Parse(textBox11ZIP3.Text));
                    textBox11ZIP2Lang1.Text = str;
                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox11ZIP3.Clear();

                }
            }
            else
            {
                textBox11ZIP2Lang1.Text = "";
            }
        }

        private void textBox12ZP3_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox12ZP3.Text))
            {
                try
                {
                    GradeText(int.Parse(textBox12ZP3.Text));
                    textBox122Lang1.Text = str;
                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox12ZP3.Clear();

                }
            }
            else
            {
                textBox122Lang1.Text = "";
            }
        }

        private void textBox12ZIP3_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox12ZIP3.Text))
            {
                try
                {
                    GradeText(int.Parse(textBox12ZIP3.Text));
                    textBox12ZIP2Lang1.Text = str;
                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox12ZIP3.Clear();

                }
            }
            else
            {
                textBox12ZIP2Lang1.Text = "";
            }
        }

        private void textBox10ZP4_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox10ZP4.Text))
            {
                try
                {
                    GradeText(int.Parse(textBox10ZP4.Text));
                    textBox10Mat1.Text = str;
                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox10ZP4.Clear();

                }
            }
            else
            {
                textBox10Mat1.Text = "";
            }
        }

        private void textBox10ZIP4_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox10ZIP4.Text))
            {
                try
                {
                    GradeText(int.Parse(textBox10ZIP4.Text));
                    textBox10ZIPMat1.Text = str;
                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox10ZIP4.Clear();

                }
            }
            else
            {
                textBox10ZIPMat1.Text = "";
            }
        }

        private void textBox11ZP4_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox11ZP4.Text))
            {
                try
                {
                    GradeText(int.Parse(textBox11ZP4.Text));
                    textBox11Mat1.Text = str;
                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox11ZP4.Clear();

                }
            }
            else
            {
                textBox11Mat1.Text = "";
            }
        }

        private void textBox11ZIP4_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox11ZIP4.Text))
            {
                try
                {
                    GradeText(int.Parse(textBox11ZIP4.Text));
                    textBox11ZIPMat1.Text = str;
                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox11ZIP4.Clear();

                }
            }
            else
            {
                textBox11ZIPMat1.Text = "";
            }
        }

        private void textBox12ZP4_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox12ZP4.Text))
            {
                try
                {
                    GradeText(int.Parse(textBox12ZP4.Text));
                    textBox12Mat1.Text = str;
                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox12ZP4.Clear();

                }
            }
            else
            {
                textBox12Mat1.Text = "";
            }
        }

        private void textBox12ZIP4_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox12ZIP4.Text))
            {
                try
                {
                    GradeText(int.Parse(textBox12ZIP4.Text));
                    textBox12ZIPMat1.Text = str;
                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox12ZIP4.Clear();

                }
            }
            else
            {
                textBox12ZIPMat1.Text = "";
            }
        }

        private void textBox10ZP5_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox10ZP5.Text))
            {
                try
                {
                    GradeText(int.Parse(textBox10ZP5.Text));
                    textBox10Inf1.Text = str;
                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox10ZP5.Clear();

                }
            }
            else
            {
                textBox10Inf1.Text = "";
            }
        }

        private void textBox10ZIP5_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox10ZIP5.Text))
            {
                try
                {
                    GradeText(int.Parse(textBox10ZIP5.Text));
                    textBox10ZIPInf1.Text = str;
                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox10ZIP5.Clear();

                }
            }
            else
            {
                textBox10ZIPInf1.Text = "";
            }
        }

        private void textBox11ZP5_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox11ZP5.Text))
            {
                try
                {
                    GradeText(int.Parse(textBox11ZP5.Text));
                    textBox11Inf1.Text = str;
                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox11ZP5.Clear();

                }
            }
            else
            {
                textBox11Inf1.Text = "";
            }
        }

        private void textBox11ZIP5_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox11ZIP5.Text))
            {
                try
                {
                    GradeText(int.Parse(textBox11ZIP5.Text));
                    textBox11ZIPInf1.Text = str;
                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox11ZIP5.Clear();

                }
            }
            else
            {
                textBox11ZIPInf1.Text = "";
            }
        }

        private void textBox12ZP5_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox12ZP5.Text))
            {
                try
                {
                    GradeText(int.Parse(textBox12ZP5.Text));
                    textBox12Inf1.Text = str;
                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox12ZP5.Clear();

                }
            }
            else
            {
                textBox12Inf1.Text = "";
            }
        }

        private void textBox12ZIP5_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox12ZIP5.Text))
            {
                try
                {
                    GradeText(int.Parse(textBox12ZIP5.Text));
                    textBox12ZIPInf1.Text = str;
                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox12ZIP5.Clear();

                }
            }
            else
            {
                textBox12ZIPInf1.Text = "";
            }
        }

        private void textBox10ZP6_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox10ZP6.Text))
            {
                try
                {
                    GradeText(int.Parse(textBox10ZP6.Text));
                    textBox10IT1.Text = str;
                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox10ZP6.Clear();

                }
            }
            else
            {
                textBox10IT1.Text = "";
            }
        }

        private void textBox10ZIP6_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox10ZIP6.Text))
            {
                try
                {
                    GradeText(int.Parse(textBox10ZIP6.Text));
                    textBox10ZIPIT1.Text = str;
                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox10ZIP6.Clear();

                }
            }
            else
            {
                textBox10ZIPIT1.Text = "";
            }
        }

        private void textBox11ZP6_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox11ZP6.Text))
            {
                try
                {
                    GradeText(int.Parse(textBox11ZP6.Text));
                    textBox11IT1.Text = str;
                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox11ZP6.Clear();

                }
            }
            else
            {
                textBox11IT1.Text = "";
            }
        }

        private void textBox11ZIP6_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox11ZIP6.Text))
            {
                try
                {
                    GradeText(int.Parse(textBox11ZIP6.Text));
                    textBox11ZIPIT1.Text = str;
                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox11ZIP6.Clear();

                }
            }
            else
            {
                textBox11ZIPIT1.Text = "";
            }
        }

        private void textBox12ZP6_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox12ZP6.Text))
            {
                try
                {
                    GradeText(int.Parse(textBox12ZP6.Text));
                    textBox12IT1.Text = str;
                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox12ZP6.Clear();

                }
            }
            else
            {
                textBox12IT1.Text = "";
            }
        }

        private void textBox12ZIP6_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox12ZIP6.Text))
            {
                try
                {
                    GradeText(int.Parse(textBox12ZIP6.Text));
                    textBox12ZIPIT1.Text = str;
                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox12ZIP6.Clear();

                }
            }
            else
            {
                textBox12ZIPIT1.Text = "";
            }
        }

        private void textBox10ZP7_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox10ZP7.Text))
            {
                try
                {
                    GradeText(int.Parse(textBox10ZP7.Text));
                    textBox10Ist1.Text = str;
                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox10ZP7.Clear();

                }
            }
            else
            {
                textBox10Ist1.Text = "";
            }
        }

        private void textBox10ZIP7_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox10ZIP7.Text))
            {
                try
                {
                    GradeText(int.Parse(textBox10ZIP7.Text));
                    textBox10ZIPIst1.Text = str;
                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox10ZIP7.Clear();

                }
            }
            else
            {
                textBox10ZIPIst1.Text = "";
            }
        }

        private void textBox11ZP7_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox11ZP7.Text))
            {
                try
                {
                    GradeText(int.Parse(textBox11ZP7.Text));
                    textBox11Ist1.Text = str;
                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox11ZP7.Clear();

                }
            }
            else
            {
                textBox11Ist1.Text = "";
            }
        }

        private void textBox11ZIP7_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox11ZIP7.Text))
            {
                try
                {
                    GradeText(int.Parse(textBox11ZIP7.Text));
                    textBox11ZIPIst1.Text = str;
                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox11ZIP7.Clear();

                }
            }
            else
            {
                textBox11ZIPIst1.Text = "";
            }
        }

        private void textBox12ZP7_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox12ZP7.Text))
            {
                try
                {
                    GradeText(int.Parse(textBox12ZP7.Text));
                    textBox12Ist1.Text = str;
                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox12ZP7.Clear();

                }
            }
            else
            {
                textBox12Ist1.Text = "";
            }
        }

        private void textBox12ZIP7_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox12ZIP7.Text))
            {
                try
                {
                    GradeText(int.Parse(textBox12ZIP7.Text));
                    textBox12ZIPIst1.Text = str;
                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox12ZIP7.Clear();

                }
            }
            else
            {
                textBox12ZIPIst1.Text = "";
            }
        }

        private void textBox10ZP8_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox10ZP8.Text))
            {
                try
                {
                    GradeText(int.Parse(textBox10ZP8.Text));
                    textBox10G1.Text = str;
                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox10ZP8.Clear();

                }
            }
            else
            {
                textBox10G1.Text = "";
            }
        }

        private void textBox10ZIP8_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox10ZIP8.Text))
            {
                try
                {
                    GradeText(int.Parse(textBox10ZIP8.Text));
                    textBox10ZIPG1.Text = str;
                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox10ZIP8.Clear();

                }
            }
            else
            {
                textBox10ZIPG1.Text = "";
            }
        }

        private void textBox11ZP8_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox11ZP8.Text))
            {
                try
                {
                    GradeText(int.Parse(textBox11ZP8.Text));
                    textBox11G1.Text = str;
                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox11ZP8.Clear();

                }
            }
            else
            {
                textBox11G1.Text = "";
            }
        }

        private void textBox11ZIP8_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox11ZIP8.Text))
            {
                try
                {
                    GradeText(int.Parse(textBox11ZIP8.Text));
                    textBox11ZIPG1.Text = str;
                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox11ZIP8.Clear();

                }
            }
            else
            {
                textBox11ZIPG1.Text = "";
            }
        }

        private void textBox12ZP8_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox12ZP8.Text))
            {
                try
                {
                    GradeText(int.Parse(textBox12ZP8.Text));
                    textBox12G1.Text = str;
                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox12ZP8.Clear();

                }
            }
            else
            {
                textBox12G1.Text = "";
            }
        }

        private void textBox12ZIP8_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox12ZIP8.Text))
            {
                try
                {
                    GradeText(int.Parse(textBox12ZIP8.Text));
                    textBox12ZIPG1.Text = str;
                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox12ZIP8.Clear();

                }
            }
            else
            {
                textBox12ZIPG1.Text = "";
            }
        }

        private void textBox10ZP10_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox10ZP10.Text))
            {
                try
                {
                    GradeText(int.Parse(textBox10ZP10.Text));
                    textBox10Et1.Text = str;
                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox10ZP10.Clear();

                }
            }
            else
            {
                textBox10Et1.Text = "";
            }
        }

        private void textBox11ZP11_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox11ZP11.Text))
            {
                try
                {
                    GradeText(int.Parse(textBox11ZP11.Text));
                    textBox11Fil1.Text = str;
                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox11ZP11.Clear();

                }
            }
            else
            {
                textBox11Fil1.Text = "";
            }
        }

        private void textBox12ZP12_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox12ZP12.Text))
            {
                try
                {
                    GradeText(int.Parse(textBox12ZP12.Text));
                    textBox12Sv1.Text = str;
                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox12ZP12.Clear();

                }
            }
            else
            {
                textBox12Sv1.Text = "";
            }
        }

        private void textBox10ZP13_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox10ZP13.Text))
            {
                try
                {
                    GradeText(int.Parse(textBox10ZP13.Text));
                    textBox10Bio1.Text = str;
                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox10ZP13.Clear();

                }
            }
            else
            {
                textBox10Bio1.Text = "";
            }
        }
              
        private void textBox10ZIP13_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox10ZIP13.Text))
            {
                try
                {
                    GradeText(int.Parse(textBox10ZIP13.Text));
                    textBox10ZIPBio1.Text = str;
                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox10ZIP13.Clear();

                }
            }
            else
            {
                textBox10ZIPBio1.Text = "";
            }
        }

        private void textBox11ZP13_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox11ZP13.Text))
            {
                try
                {
                    GradeText(int.Parse(textBox11ZP13.Text));
                    textBox11Bio1.Text = str;
                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox11ZP13.Clear();

                }
            }
            else
            {
                textBox11Bio1.Text = "";
            }
        }

        private void textBox11ZIP13_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox11ZIP13.Text))
            {
                try
                {
                    GradeText(int.Parse(textBox11ZIP13.Text));
                    textBox11ZIPBio1.Text = str;
                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox11ZIP13.Clear();

                }
            }
            else
            {
                textBox11ZIPBio1.Text = "";
            }
        }

        private void textBox12ZP13_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox12ZP13.Text))
            {
                try
                {
                    GradeText(int.Parse(textBox12ZP13.Text));
                    textBox12Bio1.Text = str;
                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox12ZP13.Clear();

                }
            }
            else
            {
                textBox12Bio1.Text = "";
            }
        }

        private void textBox12ZIP13_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox12ZIP13.Text))
            {
                try
                {
                    GradeText(int.Parse(textBox12ZIP13.Text));
                    textBox12ZIPBio1.Text = str;
                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox12ZIP13.Clear();

                }
            }
            else
            {
                textBox12ZIPBio1.Text = "";
            }
        }

        private void textBox10ZP14_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox10ZP14.Text))
            {
                try
                {
                    GradeText(int.Parse(textBox10ZP14.Text));
                    textBox10Fz1.Text = str;
                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox10ZP14.Clear();

                }
            }
            else
            {
                textBox10Fz1.Text = "";
            }
        }

        private void textBox10ZIP14_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox10ZIP14.Text))
            {
                try
                {
                    GradeText(int.Parse(textBox10ZIP14.Text));
                    textBox10ZIPFz1.Text = str;
                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox10ZIP14.Clear();

                }
            }
            else
            {
                textBox10ZIPFz1.Text = "";
            }
        }


        private void textBox11ZP14_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox11ZP14.Text))
            {
                try
                {
                    GradeText(int.Parse(textBox11ZP14.Text));
                    textBox11Fz1.Text = str;
                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox11ZP14.Clear();

                }
            }
            else
            {
                textBox11Fz1.Text = "";
            }
        }

        private void textBox11ZIP14_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox11ZIP14.Text))
            {
                try
                {
                    GradeText(int.Parse(textBox11ZIP14.Text));
                    textBox11ZIPFz1.Text = str;
                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox11ZIP14.Clear();

                }
            }
            else
            {
                textBox11ZIPFz1.Text = "";
            }
        }

        private void textBox12ZP14_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox12ZP14.Text))
            {
                try
                {
                    GradeText(int.Parse(textBox12ZP14.Text));
                    textBox12Fz1.Text = str;
                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox12ZP14.Clear();

                }
            }
            else
            {
                textBox12Fz1.Text = "";
            }
        }

        private void textBox12ZIP14_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox12ZIP14.Text))
            {
                try
                {
                    GradeText(int.Parse(textBox12ZIP14.Text));
                    textBox12ZIPFz1.Text = str;
                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox12ZIP14.Clear();

                }
            }
            else
            {
                textBox12ZIPFz1.Text = "";
            }
        }
        private void textBox10ZP15_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox10ZP15.Text))
            {
                try
                {
                    GradeText(int.Parse(textBox10ZP15.Text));
                    textBox10Him1.Text = str;
                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox10ZP15.Clear();

                }
            }
            else
            {
                textBox10Him1.Text = "";
            }
        }

        private void textBox10ZIP15_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox10ZIP15.Text))
            {
                try
                {
                    GradeText(int.Parse(textBox10ZIP15.Text));
                    textBox10ZIPHim1.Text = str;
                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox10ZIP15.Clear();

                }

            }
            else
            {
                textBox10ZIPHim1.Text = "";
            }
        }

        private void textBox11ZP15_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox11ZP15.Text))
            {
                try
                {
                    GradeText(int.Parse(textBox11ZP15.Text));
                    textBox11Him1.Text = str;
                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox11ZP15.Clear();

                }
            }
            else
            {
                textBox11Him1.Text = "";
            }
        }

        private void textBox11ZIP15_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox11ZIP15.Text))
            {
                try
                {
                    GradeText(int.Parse(textBox11ZIP15.Text));
                    textBox11ZIPHim1.Text = str;
                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox11ZIP15.Clear();

                }
            }
            else
            {
                textBox11ZIPHim1.Text = "";
            }
        }

        private void textBox12ZP15_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox12ZP15.Text))
            {
                try
                {
                    GradeText(int.Parse(textBox12ZP15.Text));
                    textBox12Him1.Text = str;
                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox12ZP15.Clear();

                }
            }
            else
            {
                textBox12Him1.Text = "";
            }
        }

        private void textBox12ZIP15_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox12ZIP15.Text))
            {
                try
                {
                    GradeText(int.Parse(textBox12ZIP15.Text));
                    textBox12ZIPHim1.Text = str;
                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox12ZIP15.Clear();

                }
            }
            else
            {
                textBox12ZIPHim1.Text = "";
            }
        }

        private void textBox9ZP18_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox9ZP18.Text))
            {
                try
                {
                    GradeText(int.Parse(textBox9ZP18.Text));
                    textBox9FV1.Text = str;
                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox9ZP18.Clear();

                }
            }
            else
            {
                textBox9FV1.Text = "";
            }
           

        }

        private void textBox10ZP18_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox10ZP18.Text))
            {
                try
                {
                    GradeText(int.Parse(textBox10ZP18.Text));
                    textBox10FV1.Text = str;
                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox10ZP18.Clear();

                }
            }
            else
            {
                textBox10FV1.Text = "";
            }
           
        }

        private void textBox11ZP18_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox11ZP18.Text))
            {
                try
                {
                    GradeText(int.Parse(textBox11ZP18.Text));
                    textBox11FV1.Text = str;
                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox11ZP18.Clear();

                }
            }
            else
            {
                textBox11FV1.Text = "";
            }
          
        }

        private void textBox12ZP18_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox12ZP18.Text))
            {
                try
                {
                    GradeText(int.Parse(textBox12ZP18.Text));
                    textBox12FV1.Text = str;
                }
                catch (FormatException)
                {
                    MessageBox.Show("Грешка! Въвеждайте само цели числа за оценка.");
                    textBox12ZP18.Clear();

                }
            }
            else
            {
                textBox12FV1.Text = "";
            }
        }

        //-------------------------

        private void textBoxdipZP1_TextChanged(object sender, EventArgs e)
        {

            if (!string.IsNullOrEmpty(textBoxdipZP1.Text))
            {
                GradeText2(float.Parse(textBoxdipZP1.Text));
                textBoxdipBEL1.Text = str;
            }
        }

        private void textBoxdipZP2_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBoxdipZP2.Text))
            {
                GradeText2(float.Parse(textBoxdipZP2.Text));
                textBoxdip1Lang1.Text = str;
            }
        }

        private void textBoxdipZP3_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBoxdipZP3.Text))
            {
                GradeText2(float.Parse(textBoxdipZP3.Text));
                textBoxdip2Lang1.Text = str;
            }
        }

        private void textBoxdipZP4_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBoxdipZP4.Text))
            {
                GradeText2(float.Parse(textBoxdipZP4.Text));
                textBoxdipMat1.Text = str;
            }
        }
        private void textBoxdipZP5_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBoxdipZP5.Text))
            {
                GradeText2(float.Parse(textBoxdipZP5.Text));
                textBoxdipInf1.Text = str;
            }
        }

        private void textBoxdipZP6_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBoxdipZP6.Text))
            {
                GradeText2(float.Parse(textBoxdipZP6.Text));
                textBoxdipIT1.Text = str;
            }
        }
        private void textBoxdipZP7_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBoxdipZP7.Text))
            {
                GradeText2(float.Parse(textBoxdipZP7.Text));
                textBoxdipIst1.Text = str;
            }
        }
        private void textBoxdipZP8_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBoxdipZP8.Text))
            {
                GradeText2(float.Parse(textBoxdipZP8.Text));
                textBoxdipG1.Text = str;
            }
        }
        private void textBoxdipZP9_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBoxdipZP9.Text))
            {
                GradeText2(float.Parse(textBoxdipZP9.Text));
                textBoxdipPs1.Text = str;
            }
        }
        private void textBoxdipZP10_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBoxdipZP10.Text))
            {
                GradeText2(float.Parse(textBoxdipZP10.Text));
                textBoxdipEt1.Text = str;
            }
        }
        private void textBoxdipZP11_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBoxdipZP11.Text))
            {
                GradeText2(float.Parse(textBoxdipZP11.Text));
                textBoxdipFil1.Text = str;
            }
        }
        private void textBoxdipZP12_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBoxdipZP12.Text))
            {
                GradeText2(float.Parse(textBoxdipZP12.Text));
                textBoxdipSv1.Text = str;
            }
        }


        private void textBoxdipZP13_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBoxdipZP13.Text))
            {
                GradeText2(float.Parse(textBoxdipZP13.Text));
                textBoxdipBio1.Text = str;
            }
        }

        private void textBoxdipZP14_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBoxdipZP14.Text))
            {
                GradeText2(float.Parse(textBoxdipZP14.Text));
                textBoxdipFz1.Text = str;
            }
        }

        private void textBoxdipZP15_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBoxdipZP15.Text))
            {
                GradeText2(float.Parse(textBoxdipZP15.Text));
                textBoxdipHim1.Text = str;
            }
        }
        private void textBoxdipZP16_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBoxdipZP16.Text))
            {
                GradeText2(float.Parse(textBoxdipZP16.Text));
                textBoxdipMz1.Text = str;
            }
        }

        private void textBoxdipZP17_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBoxdipZP17.Text))
            {
                GradeText2(float.Parse(textBoxdipZP17.Text));
                textBoxdipIzobr1.Text = str;
            }
        }

        private void textBoxdipZP18_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBoxdipZP18.Text))
            {
                GradeText2(float.Parse(textBoxdipZP18.Text));
                textBoxdipFV1.Text = str;
            }
        }

        //-----------------
        private void textBoxdipZIP1_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBoxdipZIP1.Text))
            {
                GradeText2(float.Parse(textBoxdipZIP1.Text));
                textBoxdipBELZIP1.Text = str;
            }

        }

        private void textBoxdipZIP2_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBoxdipZIP2.Text))
            {
                GradeText2(float.Parse(textBoxdipZIP2.Text));
                textBoxdip1LangZIP1.Text = str;
            }
        }

        private void textBoxdipZIP3_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox10ZP1.Text))
            {
                GradeText2(float.Parse(textBox10ZP1.Text));
                textBoxdip2LangZIP1.Text = str;
            }
        }

        private void textBoxdipZIP4_TextChanged(object sender, EventArgs e)
        {

            if (!string.IsNullOrEmpty(textBoxdipZIP4.Text))
            {
                GradeText2(float.Parse(textBoxdipZIP4.Text));
                textBoxdipMatZIP1.Text = str;
            }
        }

        private void textBoxdipZIP5_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBoxdipZIP5.Text))
            {
                GradeText2(float.Parse(textBoxdipZIP5.Text));
                textBoxdipInfZIP1.Text = str;
            }
        }

        private void textBoxdipZIP6_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBoxdipZIP6.Text))
            {
                GradeText2(float.Parse(textBoxdipZIP6.Text));
                textBoxdipITZIP1.Text = str;
            }
        }

        private void textBoxdipZIP7_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBoxdipZIP7.Text))
            {
                GradeText2(float.Parse(textBoxdipZIP7.Text));
                textBoxdipIstZIP1.Text = str;
            }
        }

        private void textBoxdipZIP8_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBoxdipZIP8.Text))
            {
                GradeText2(float.Parse(textBoxdipZIP8.Text));
                textBoxdipGZIP1.Text = str;
            }
        }

        private void textBoxdipZIP9_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBoxdipZIP9.Text))
            {
                GradeText2(float.Parse(textBoxdipZIP9.Text));
                textBoxdipPsZIP1.Text = str;
            }
        }
        private void textBoxdipZIP10_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBoxdipZIP10.Text))
            {
                GradeText2(float.Parse(textBoxdipZIP10.Text));
                textBoxdipEtZIP1.Text = str;
            }
        }

        private void textBoxdipZIP11_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBoxdipZIP11.Text))
            {
                GradeText2(float.Parse(textBoxdipZIP11.Text));
                textBoxdipFilZIP1.Text = str;
            }
        }

        private void textBoxdipZIP12_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBoxdipZIP12.Text))
            {
                GradeText2(float.Parse(textBoxdipZIP12.Text));
                textBoxdipSvZIP1.Text = str;
            }
        }


        private void textBoxdipZIP13_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBoxdipZIP13.Text))
            {
                GradeText2(float.Parse(textBoxdipZIP13.Text));
                textBoxdipBioZIP1.Text = str;
            }
        }

        private void textBoxdipZIP14_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBoxdipZIP14.Text))
            {
                GradeText2(float.Parse(textBoxdipZIP14.Text));
                textBoxdipFzZIP1.Text = str;
            }
        }

        private void textBoxdipZIP15_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBoxdipZIP15.Text))
            {
                GradeText2(float.Parse(textBoxdipZIP15.Text));
                textBoxdipHimZIP1.Text = str;
            }
        }


        private void textBoxdipZIP16_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBoxdipZIP16.Text))
            {
                GradeText2(float.Parse(textBoxdipZIP16.Text));
                textBoxdipMzZIP1.Text = str;
            }
        }

        private void textBoxdipZIP17_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBoxdipZIP17.Text))
            {
                GradeText2(float.Parse(textBoxdipZIP17.Text));
                textBoxdipIzobrZIP1.Text = str;
            }
        }

        private void textBoxdipZIP18_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBoxdipZIP18.Text))
            {
                GradeText2(float.Parse(textBoxdipZIP18.Text));
                textBoxdipFVZIP1.Text = str;
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {
            label1.BackColor = System.Drawing.Color.Transparent;
        }

        private void buttonEditZPP_Click(object sender, EventArgs e)
        {
            //масив с предметите
            TextBox[] masivTBoxSubject = new TextBox[3];
            masivTBoxSubject[0] = textBox1ZPP;
            masivTBoxSubject[1] = textBox2ZPP;
            masivTBoxSubject[2] = textBox3ZPP;
            bool fl9=false,fl10=false,fl11=false,fl12=false;
            //извлича оценките за 9 клас
            ESchoolEntities context = new ESchoolEntities();
            var grades9klas = from gr9klas in context.Grades9Class
                              where gr9klas.StudentID == studentID
                              select gr9klas;
            int grade;
            //масив с оценките
            masivTBox[0] = textBox9ZPP1;
            masivTBox[1] = textBox9ZPP2;
            masivTBox[2] = textBox9ZPP3;
            
            for(int i=0;i<3;i++)
            {
                foreach (var item in grades9klas)
                {
                    bool flag = false;
                    
                    string strSubject = item.Subjects.SubjectName.Trim();
                    string str=masivTBoxSubject[i].Text;
                    if (strSubject ==str )
                    {
                        grade = int.Parse(masivTBox[i].Text);
                        if (grade <=6 && grade >=3)
                        {

                            item.Grades = grade;
                            flag = true;
                            fl9 = true;
                        }
                        
                    }
                    if (flag)  break;
                }
            }
            
            //извлича оценките за 10 клас
            var grades10klas = from gr10klas in context.Grades10Class
                               where gr10klas.StudentID == studentID
                               select gr10klas;
            //масив с оценките
            masivTBox[0] = textBox10ZPP1;
            masivTBox[1] = textBox10ZPP2;
            masivTBox[2] = textBox10ZPP3;
            for(int i=0;i<3;i++)
            {
                foreach (var item in grades10klas)
                {
                    bool flag = false;
                    if (item.Subjects.SubjectName.Trim() == masivTBoxSubject[i].Text)
                    {
                        grade = int.Parse(masivTBox[i].Text);
                        if (grade <= 6 && grade >= 3)
                        {
                            item.Grades = grade;
                            flag = true;
                            fl10 = true;
                        }
                    }
                    if (flag) break;
                }
            }
           
            //извлича оценките за 11 клас
            var grades11klas = from gr11klas in context.Grades11Class
                               where gr11klas.StudentID == studentID
                               select gr11klas;
             //масив с оценките
            masivTBox[0] = textBox11ZPP1;
            masivTBox[1] = textBox11ZPP2;
            masivTBox[2] = textBox11ZPP3;
            for (int i = 0; i < 3; i++)
            {
                foreach (var item in grades11klas)
                {
                    bool flag = false;
                    if (item.Subjects.SubjectName.Trim() == masivTBoxSubject[i].Text)
                    {
                        grade = int.Parse(masivTBox[i].Text);
                        if (grade <= 6 && grade >= 3)
                        {
                            item.Grades = grade;
                            flag = true;
                            fl11 = true;
                        }
                    }
                    if (flag) break;
                }
            }
           
            //извлича оценките за 12 клас
            var grades12klas = from gr12klas in context.Grades12Class
                               where gr12klas.StudentID == studentID
                               select gr12klas;
            //масив с оценките
            masivTBox[0] = textBox12ZPP1;
            masivTBox[1] = textBox12ZPP2;
            masivTBox[2] = textBox12ZPP3;
            for (int i = 0; i < 3; i++)
            {
                foreach (var item in grades12klas)
                {
                    bool flag = false;
                    if (item.Subjects.SubjectName.Trim() == masivTBoxSubject[i].Text)
                    {
                        grade = int.Parse(masivTBox[i].Text);
                        if (grade <= 6 && grade >= 3)
                        {
                            item.Grades = grade;
                            flag = true;
                            fl12 = true;
                        }
                    }
                    if (flag) break;
                }
            }


            if (fl9 && fl10 && fl11 && fl12)
            {
                //преизчисляване на окончателните оценки ЗПП
                //по първи ЗПП
                masivTBox[0] = textBox9ZPP1;
                masivTBox[1] = textBox10ZPP1;
                masivTBox[2] = textBox11ZPP1;
                masivTBox[3] = textBox12ZPP1;
                sipOkon.Clear();
                //изчислява окончателните оценки по  ЗПП и ги записва 
                //по първи ЗПП

                AddGradeToList(masivTBox, sipOkon);
                float zpp = 0;
                float sum = 0;
                int count = 0;

                if (sipOkon.Count > 0)
                {
                    zpp = sipOkon.Average();
                    sum += zpp;
                    count++;
                    textBoxOkZPP1.Text = zpp.ToString("F2");
                }
                //по втори ЗПП
                sipOkon.Clear();
                masivTBox[0] = textBox9ZPP2;
                masivTBox[1] = textBox10ZPP2;
                masivTBox[2] = textBox11ZPP2;
                masivTBox[3] = textBox12ZPP2;
                AddGradeToList(masivTBox, sipOkon);
                zpp = 0;
                if (sipOkon.Count > 0)
                {
                    zpp = sipOkon.Average();
                    sum += zpp;
                    count++;
                    textBoxOkZPP2.Text = zpp.ToString("F2");
                }
                //по трети ЗПП
                sipOkon.Clear();
                masivTBox[0] = textBox9ZPP3;
                masivTBox[1] = textBox10ZPP3;
                masivTBox[2] = textBox11ZPP3;
                masivTBox[3] = textBox12ZPP3;
                AddGradeToList(masivTBox, sipOkon);
                zpp = 0;
                if (sipOkon.Count > 0)
                {
                    zpp = sipOkon.Average();
                    sum += zpp;
                    count++;
                    textBoxOkZPP3.Text = zpp.ToString("F2");
                }

                if (textBoxSumOcZIP.Text != "")
                {
                    //промяна на тази сума?
                    sum += float.Parse(textBoxSumOcZIP.Text);
                    count += int.Parse(textBoxBrOcZIP.Text);
                }
                //среден успех от оценките ЗИП и ЗПП
                sum /= count;
                textBoxZPPZIP.Text = sum.ToString("F2");

                //промяна в базата на окончателните оценки ЗПП
                var gradesDiplom = from grDip in context.Diploms
                                   where grDip.StudentID == studentID
                                   select grDip;
                float gr;
                //масив с окончателните оценките
                masivTBox[0] = textBoxOkZPP1;
                masivTBox[1] = textBoxOkZPP2;
                masivTBox[2] = textBoxOkZPP3;
                for (int i = 0; i < 3; i++)
                {
                    foreach (var item in gradesDiplom)
                    {
                        bool flag = false;
                        if (item.Subjects.SubjectName.Trim() == masivTBoxSubject[i].Text)
                        {
                            gr = float.Parse(masivTBox[i].Text);
                            item.Grades = gr;
                            flag = true;
                        }
                        if (flag) break;
                    }
                }

                context.SaveChanges();//запис в базата
                MessageBox.Show("Промените на оценките са записани! Преизчисли успеха на дипломата!");
                buttonSaveSuccess.Text = "Преизчисли успеха за дипломата";
                buttonSaveSuccess.ForeColor = Color.Red;
            }
            else
            {
                MessageBox.Show("Записът е невъзможен. Некоректни оценки!");
            }

       }

        private void buttonEditDZI_Click(object sender, EventArgs e)
        {
            var gradesDiplom = from grDip in context.Diploms
                               where grDip.StudentID == studentID
                               select grDip;
            float gr;
            float srUspeh = 0;
            int count = 0;
            ComboBox[] masivCombo = new ComboBox[] { comboBox1DZI, comboBox2DZI, comboBox3DZI, comboBox4DZI };
            //масив с окончателните оценките
            masivTBox[0] = textBox1DZI;
            masivTBox[1] = textBox2DZI;
            masivTBox[2] = textBox3DZI;
            masivTBox[3] = textBox4DZI;
            
            try
            {
                for (int i = 0; i < 3; i++)
                {
                    foreach (var item in gradesDiplom)
                    {
                        bool flag = false;
                        if (masivCombo[i].SelectedItem != null)
                        {

                            if (item.Subjects.SubjectName.Trim() == masivCombo[i].SelectedItem.ToString())
                            {

                                gr = float.Parse(masivTBox[i].Text);
                                if (gr >= 3 && gr <= 6)
                                {
                                    item.Grades = gr;
                                    srUspeh += gr;
                                    count++;
                                    flag = true;

                                }
                                else
                                {
                                    MessageBox.Show("Грешка! Въведете отново оценката - число с десетична запетая!");
                                    masivTBox[i].Clear();

                                }
                            }
                        }
                                              
                        if (flag) break;
                    }
                }
                if (count>1)
                {
                    //средноаритметична оценка от ДЗИ
                    srUspeh = srUspeh / count;
                    textBoxDZISrUsp.Text = srUspeh.ToString("F2");
                    context.SaveChanges();//запис в базата
                    MessageBox.Show("Промените на оценките са записани! Преизчисли успеха на дипломата!");
                    buttonSaveSuccess.Text = "Преизчисли успеха за дипломата";
                    buttonSaveSuccess.ForeColor = Color.Red;
                }
                else
                {
                    MessageBox.Show("Записът е невъзможен. Некоректни оценки!");
                }
            }
            catch (FormatException )
            {
                MessageBox.Show("Грешка! Въведете отново оценката!");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message );
            }
        }

        private void comboBox1Lang_SelectedIndexChanged(object sender, EventArgs e)
        {
            textBox9ZP1.Focus();
        }

        private void comboBox2Lang_SelectedIndexChanged(object sender, EventArgs e)
        {
            textBox9ZP1.Focus();
        }

        private void comboBox2DZI_SelectedIndexChanged(object sender, EventArgs e)
        {
            textBox1DZI.Focus();
        }

        private void comboBox1SIP_SelectedIndexChanged(object sender, EventArgs e)
        {
            textBox9SIP1.Focus();
        }

       

    }
}
