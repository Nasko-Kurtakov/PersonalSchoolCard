﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

using System.Data.OleDb;

namespace E_school
{
    public partial class FormGetStudentsFromExcel : Form
    {
        public FormGetStudentsFromExcel()
        {
            InitializeComponent();
        }

        private void buttonOpen_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog ()==System.Windows.Forms.DialogResult.OK )
            {
                this.textBoxPath.Text = openFileDialog1.FileName;
            }

        }

        private void buttonLoad_Click(object sender, EventArgs e)
        {
            try
            {
                //excelfile
                string pathConn = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + textBoxPath.Text + ";Mode=ReadWrite;Extended Properties=\"Excel 8.0;HDR=YES;IMEX=1\"";
                OleDbConnection conn = new OleDbConnection(pathConn);
                conn.Open();
                OleDbDataAdapter myDataAdapter = new OleDbDataAdapter("Select * from [" + textBoxSheet.Text + "$]", conn);
                DataTable dt = new DataTable();
                myDataAdapter.Fill(dt);
                dataGridViewStu.DataSource = dt;
                buttonAdd.Enabled = true;
            }
            catch (Exception)
            {
                MessageBox.Show("Грешка! Въведете правилно име на листа от файла с имената!" );
            }
            
           
        }

        private void FormGetStudentsFromExcel_Load(object sender, EventArgs e)
        {
            buttonAdd.Enabled = false;
            ESchoolEntities context = new ESchoolEntities();
            //зареждане на таблицата с класовете
            var classes = context.Classes;
            dataGridViewClass.AutoGenerateColumns = false;
            dataGridViewClass.DataSource = classes;
        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            ESchoolEntities context = new ESchoolEntities();
            // обработка на селектираният ред от dataGridViewClass
            int classID;//локална променлива
            //от текущо селектирания ред - row.Cells[0].Value
            int i = dataGridViewClass.CurrentRow.Index;
            classID = (int)dataGridViewClass.Rows[i].Cells[0].Value;

           
            bool flag=false;
            foreach (DataGridViewRow row in this.dataGridViewStu.Rows)
            {
                
                //създаваме обект
                Students newStudent = new Students();
                if (row.Cells[0].Value != null)
                {
                    flag = false;
                    newStudent.NumberInClass = Convert.ToInt32(row.Cells[0].Value);
                    newStudent.FirstName = row.Cells[1].Value.ToString();
                    newStudent.SecondName = row.Cells[2].Value.ToString();
                    newStudent.LastName = row.Cells[3].Value.ToString();
                    newStudent.ClassID = classID;
                    //добавяне на ученика в базата
                    context.Students.AddObject(newStudent);
                    flag = true;
                }
            }

            if (flag)
            {
                //записване в базата
                context.SaveChanges();
                MessageBox.Show("Учениците са добавени!");
                buttonAdd.Enabled = false;
            }
          
           
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
