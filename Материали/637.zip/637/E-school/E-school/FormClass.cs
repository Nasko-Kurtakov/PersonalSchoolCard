﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace E_school
{
   
    public partial class FormClass : Form
    {
        int teacherID,classID;
        string schoolYear;
        //listSubjects е списък на предметите ЗИП Профилирана подгатовка от базата данни
        private List<string> listSubjects = new List<string>();
        //listZPP е списък на избраните от класния предмети ЗИП Профилирана подгатовка
        private List<string> listZPP = new List<string>();
        public FormClass(int teacherID, int classID, string schoolYear)
        {
            InitializeComponent();
            this.teacherID = teacherID;
            this.classID = classID;
            this.schoolYear = schoolYear;
           
            label1.BackColor = System.Drawing.Color.Transparent;
            label2.BackColor = System.Drawing.Color.Transparent;
            label4.BackColor = System.Drawing.Color.Transparent;
            label5.BackColor = System.Drawing.Color.Transparent;

        }
      

        private void FormClass_Load(object sender, EventArgs e)
        {
            dataGridViewClass.Visible = false;
            
            buttonSaveZPP.Enabled = false;
            
            listZPP.Clear();
            ESchoolEntities context = new ESchoolEntities();
            //заявка за извеждане на класа на учителя 
            var clas = from cl in context.Classes
                       join tch in context.Teachers on cl.TeacherID equals tch.TeacherID
                       join pr in context.Profiles on cl.ProfileID equals pr.ProfileID
                       where tch.TeacherID == teacherID && cl.SchoolYear == schoolYear 
                       select cl;
           
            string className = clas.SingleOrDefault().ClassName;
            schoolYear = clas.SingleOrDefault().SchoolYear;
            int profilID = clas.SingleOrDefault().ProfileID;
            textBoxClass.Text = className;
            textBoxYear.Text = schoolYear;
            //заявка за извеждане профила на класа
            Profiles profil = context.Profiles.FirstOrDefault(p => p.ProfileID == profilID);
            string profilName = profil.ProfileName;
            textBoxProfile.Text = profilName;
            //заявка за извеждане имената на учителя
            Teachers teacher = context.Teachers.FirstOrDefault(t=>t.TeacherID ==teacherID );
            textBoxTeacher.Text = teacher.FirstName + " " + teacher.LastName;

            //заявка за извличане на учениците и зареждане в таблицата
            var students =
               from stu in context.Students
               where stu.ClassID == classID
               select stu;

            // с този ред колоните в таблицата няма да се генерират автаматично
            dataGridViewClass.AutoGenerateColumns = false;
            dataGridViewClass.DataSource = students;

            //зарежда ЗПП в комбобоксовете

            SubjectsToList(context, "ЗПП", 3);
            foreach (var item in listSubjects)
            {
                comboBox1ZPP.Items.Add(item);
                comboBox2ZPP.Items.Add(item);
                comboBox3ZPP.Items.Add(item);
            }
            
        }

        //метод,който създава списък от  ЗИП-предмети
        //за да се заредят в съответните комбобоксове
        private void SubjectsToList(ESchoolEntities context, string str, int k)
        {
            var subjects = context.Subjects;
            foreach (var item in subjects)
            {
                string subjectName = item.SubjectName.Trim();
                int subjectNameLen = subjectName.Length;

                if (subjectName.Substring(subjectNameLen - k, k) == str)
                {
                    listSubjects.Add(item.SubjectName);
                }

            }
        }
       

        private void dataGridViewClass_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {

            if (e.RowIndex == -1)
            {
                return;
            }
            int studentID = (int)dataGridViewClass.Rows[e.RowIndex].Cells[0].Value;
           
            FormStudent2 fStu = new FormStudent2(studentID, schoolYear, listZPP);
            //FormStudent fStu = new FormStudent(studentID, schoolYear, listZPP);
            fStu.Show();
           
        }

       

        //добавя избраните ЗИП ПП в списъка listZPP
       
        private void buttonSaveZPP_Click(object sender, EventArgs e)
        {
            if (comboBox1ZPP.SelectedItem!=null )
            {
                listZPP.Add(comboBox1ZPP.SelectedItem.ToString());
                
            }
            if (comboBox2ZPP.SelectedItem!=null )
            {
                listZPP.Add(comboBox2ZPP.SelectedItem.ToString());
            }
            if (comboBox3ZPP.SelectedItem!=null )
            {
                listZPP.Add(comboBox3ZPP.SelectedItem.ToString());
            }
            if (listZPP.Count ==3)
            {
               // MessageBox.Show("Добавянето е успешно!");
                dataGridViewClass.Visible = true;
               
            }
            else
            {
                MessageBox.Show("Изберете три профилиращи предмета!","",MessageBoxButtons.OK ,MessageBoxIcon.Information);
                listZPP.Clear();

            }
           
            buttonSaveZPP.Enabled = false;

        }

        private void buttonInputData_Click(object sender, EventArgs e)
        {

            comboBox3ZPP.Enabled = true;
            comboBox2ZPP.Enabled = true ;
            comboBox1ZPP.Enabled = true ;
            textBox118.Enabled = true ;
            textBox121.Enabled = true ;
            textBox157.Enabled = true ;
            label6.Enabled = true ;
            buttonSaveZPP.Enabled = true ;

        }

        private void comboBox1ZPP_SelectedIndexChanged(object sender, EventArgs e)
        {
            buttonSaveZPP.Enabled = true;

        }

        private void dataGridViewClass_CellToolTipTextNeeded(object sender, DataGridViewCellToolTipTextNeededEventArgs e)
        {
            e.ToolTipText = "Кликни двукратно за избор на ученик!";
        }

        private void buttonBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        
    }
}
