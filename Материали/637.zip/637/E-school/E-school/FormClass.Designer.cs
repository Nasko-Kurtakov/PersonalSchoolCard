﻿namespace E_school
{
    partial class FormClass
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.textBoxClass = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.textBoxYear = new System.Windows.Forms.TextBox();
            this.textBoxTeacher = new System.Windows.Forms.TextBox();
            this.dataGridViewClass = new System.Windows.Forms.DataGridView();
            this.ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnNumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnSecondName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnLastName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label5 = new System.Windows.Forms.Label();
            this.textBoxProfile = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.comboBox3ZPP = new System.Windows.Forms.ComboBox();
            this.comboBox2ZPP = new System.Windows.Forms.ComboBox();
            this.comboBox1ZPP = new System.Windows.Forms.ComboBox();
            this.textBox157 = new System.Windows.Forms.TextBox();
            this.textBox121 = new System.Windows.Forms.TextBox();
            this.textBox118 = new System.Windows.Forms.TextBox();
            this.buttonSaveZPP = new System.Windows.Forms.Button();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.buttonBack = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewClass)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(41, 30);
            this.label1.Margin = new System.Windows.Forms.Padding(0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(61, 22);
            this.label1.TabIndex = 5;
            this.label1.Text = "Клас:";
            // 
            // textBoxClass
            // 
            this.textBoxClass.Location = new System.Drawing.Point(100, 29);
            this.textBoxClass.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxClass.Name = "textBoxClass";
            this.textBoxClass.ReadOnly = true;
            this.textBoxClass.Size = new System.Drawing.Size(71, 23);
            this.textBoxClass.TabIndex = 6;
            this.textBoxClass.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(41, 101);
            this.label2.Margin = new System.Windows.Forms.Padding(0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(222, 22);
            this.label2.TabIndex = 20;
            this.label2.Text = "с класен ръководител:\r\n";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(245, 28);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(0, 17);
            this.label3.TabIndex = 3;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.Location = new System.Drawing.Point(183, 31);
            this.label4.Margin = new System.Windows.Forms.Padding(0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(80, 22);
            this.label4.TabIndex = 7;
            this.label4.Text = "година:";
            // 
            // textBoxYear
            // 
            this.textBoxYear.Location = new System.Drawing.Point(263, 30);
            this.textBoxYear.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxYear.Name = "textBoxYear";
            this.textBoxYear.ReadOnly = true;
            this.textBoxYear.Size = new System.Drawing.Size(152, 23);
            this.textBoxYear.TabIndex = 80;
            this.textBoxYear.TabStop = false;
            // 
            // textBoxTeacher
            // 
            this.textBoxTeacher.Location = new System.Drawing.Point(263, 100);
            this.textBoxTeacher.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxTeacher.Name = "textBoxTeacher";
            this.textBoxTeacher.ReadOnly = true;
            this.textBoxTeacher.Size = new System.Drawing.Size(289, 23);
            this.textBoxTeacher.TabIndex = 40;
            this.textBoxTeacher.TabStop = false;
            // 
            // dataGridViewClass
            // 
            this.dataGridViewClass.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewClass.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ID,
            this.ColumnNumber,
            this.ColumnName,
            this.ColumnSecondName,
            this.ColumnLastName});
            this.dataGridViewClass.Location = new System.Drawing.Point(301, 184);
            this.dataGridViewClass.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridViewClass.Name = "dataGridViewClass";
            this.dataGridViewClass.Size = new System.Drawing.Size(501, 262);
            this.dataGridViewClass.TabIndex = 2;
            this.dataGridViewClass.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewClass_CellDoubleClick);
            this.dataGridViewClass.CellToolTipTextNeeded += new System.Windows.Forms.DataGridViewCellToolTipTextNeededEventHandler(this.dataGridViewClass_CellToolTipTextNeeded);
            // 
            // ID
            // 
            this.ID.DataPropertyName = "StudentID";
            this.ID.HeaderText = "ID";
            this.ID.Name = "ID";
            this.ID.Visible = false;
            // 
            // ColumnNumber
            // 
            this.ColumnNumber.DataPropertyName = "NumberInClass";
            this.ColumnNumber.HeaderText = "№";
            this.ColumnNumber.Name = "ColumnNumber";
            this.ColumnNumber.Width = 50;
            // 
            // ColumnName
            // 
            this.ColumnName.DataPropertyName = "FirstName";
            this.ColumnName.HeaderText = "Име";
            this.ColumnName.Name = "ColumnName";
            this.ColumnName.Width = 120;
            // 
            // ColumnSecondName
            // 
            this.ColumnSecondName.DataPropertyName = "SecondName";
            this.ColumnSecondName.HeaderText = "Презиме";
            this.ColumnSecondName.Name = "ColumnSecondName";
            this.ColumnSecondName.Width = 150;
            // 
            // ColumnLastName
            // 
            this.ColumnLastName.DataPropertyName = "LastName";
            this.ColumnLastName.HeaderText = "Фамилия";
            this.ColumnLastName.Name = "ColumnLastName";
            this.ColumnLastName.Width = 150;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.Location = new System.Drawing.Point(41, 65);
            this.label5.Margin = new System.Windows.Forms.Padding(0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(86, 22);
            this.label5.TabIndex = 80;
            this.label5.Text = "профил:";
            // 
            // textBoxProfile
            // 
            this.textBoxProfile.Location = new System.Drawing.Point(127, 64);
            this.textBoxProfile.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxProfile.Name = "textBoxProfile";
            this.textBoxProfile.ReadOnly = true;
            this.textBoxProfile.Size = new System.Drawing.Size(528, 23);
            this.textBoxProfile.TabIndex = 30;
            this.textBoxProfile.TabStop = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label6.Location = new System.Drawing.Point(45, 184);
            this.label6.Margin = new System.Windows.Forms.Padding(0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(244, 46);
            this.label6.TabIndex = 0;
            this.label6.Text = "              Избери \r\nпрофилиращи предмети:";
            // 
            // comboBox3ZPP
            // 
            this.comboBox3ZPP.FormattingEnabled = true;
            this.comboBox3ZPP.Location = new System.Drawing.Point(67, 278);
            this.comboBox3ZPP.Name = "comboBox3ZPP";
            this.comboBox3ZPP.Size = new System.Drawing.Size(222, 24);
            this.comboBox3ZPP.Sorted = true;
            this.comboBox3ZPP.TabIndex = 1128;
            this.comboBox3ZPP.SelectedIndexChanged += new System.EventHandler(this.comboBox1ZPP_SelectedIndexChanged);
            // 
            // comboBox2ZPP
            // 
            this.comboBox2ZPP.FormattingEnabled = true;
            this.comboBox2ZPP.Location = new System.Drawing.Point(67, 254);
            this.comboBox2ZPP.Name = "comboBox2ZPP";
            this.comboBox2ZPP.Size = new System.Drawing.Size(222, 24);
            this.comboBox2ZPP.Sorted = true;
            this.comboBox2ZPP.TabIndex = 1129;
            this.comboBox2ZPP.SelectedIndexChanged += new System.EventHandler(this.comboBox1ZPP_SelectedIndexChanged);
            // 
            // comboBox1ZPP
            // 
            this.comboBox1ZPP.FormattingEnabled = true;
            this.comboBox1ZPP.Location = new System.Drawing.Point(67, 230);
            this.comboBox1ZPP.Name = "comboBox1ZPP";
            this.comboBox1ZPP.Size = new System.Drawing.Size(222, 24);
            this.comboBox1ZPP.Sorted = true;
            this.comboBox1ZPP.TabIndex = 1130;
            this.comboBox1ZPP.SelectedIndexChanged += new System.EventHandler(this.comboBox1ZPP_SelectedIndexChanged);
            // 
            // textBox157
            // 
            this.textBox157.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox157.Location = new System.Drawing.Point(45, 278);
            this.textBox157.Margin = new System.Windows.Forms.Padding(0);
            this.textBox157.Multiline = true;
            this.textBox157.Name = "textBox157";
            this.textBox157.ReadOnly = true;
            this.textBox157.Size = new System.Drawing.Size(22, 24);
            this.textBox157.TabIndex = 1127;
            this.textBox157.TabStop = false;
            this.textBox157.Text = "3.";
            this.textBox157.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox121
            // 
            this.textBox121.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox121.Location = new System.Drawing.Point(45, 230);
            this.textBox121.Margin = new System.Windows.Forms.Padding(0);
            this.textBox121.Multiline = true;
            this.textBox121.Name = "textBox121";
            this.textBox121.ReadOnly = true;
            this.textBox121.Size = new System.Drawing.Size(22, 24);
            this.textBox121.TabIndex = 1125;
            this.textBox121.TabStop = false;
            this.textBox121.Text = "1.";
            this.textBox121.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox118
            // 
            this.textBox118.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox118.Location = new System.Drawing.Point(45, 254);
            this.textBox118.Margin = new System.Windows.Forms.Padding(0);
            this.textBox118.Multiline = true;
            this.textBox118.Name = "textBox118";
            this.textBox118.ReadOnly = true;
            this.textBox118.Size = new System.Drawing.Size(22, 24);
            this.textBox118.TabIndex = 1126;
            this.textBox118.TabStop = false;
            this.textBox118.Text = "2.";
            this.textBox118.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // buttonSaveZPP
            // 
            this.buttonSaveZPP.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonSaveZPP.Image = global::E_school.Properties.Resources.Ok_icon1;
            this.buttonSaveZPP.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonSaveZPP.Location = new System.Drawing.Point(48, 343);
            this.buttonSaveZPP.Name = "buttonSaveZPP";
            this.buttonSaveZPP.Size = new System.Drawing.Size(246, 46);
            this.buttonSaveZPP.TabIndex = 1;
            this.buttonSaveZPP.Text = "Добави профилиращи предмети";
            this.buttonSaveZPP.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttonSaveZPP.UseVisualStyleBackColor = true;
            this.buttonSaveZPP.Click += new System.EventHandler(this.buttonSaveZPP_Click);
            // 
            // buttonBack
            // 
            this.buttonBack.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonBack.Image = global::E_school.Properties.Resources.Button_Close_icon;
            this.buttonBack.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonBack.Location = new System.Drawing.Point(48, 400);
            this.buttonBack.Name = "buttonBack";
            this.buttonBack.Size = new System.Drawing.Size(98, 46);
            this.buttonBack.TabIndex = 3;
            this.buttonBack.Text = "Затвори";
            this.buttonBack.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttonBack.UseVisualStyleBackColor = true;
            this.buttonBack.Click += new System.EventHandler(this.buttonBack_Click);
            // 
            // FormClass
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackgroundImage = global::E_school.Properties.Resources.school__1_;
            this.ClientSize = new System.Drawing.Size(815, 484);
            this.Controls.Add(this.buttonBack);
            this.Controls.Add(this.buttonSaveZPP);
            this.Controls.Add(this.comboBox3ZPP);
            this.Controls.Add(this.comboBox2ZPP);
            this.Controls.Add(this.comboBox1ZPP);
            this.Controls.Add(this.textBox157);
            this.Controls.Add(this.textBox121);
            this.Controls.Add(this.textBox118);
            this.Controls.Add(this.textBoxProfile);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.dataGridViewClass);
            this.Controls.Add(this.textBoxTeacher);
            this.Controls.Add(this.textBoxYear);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBoxClass);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "FormClass";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Въвеждане на клас";
            this.Load += new System.EventHandler(this.FormClass_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewClass)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBoxClass;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBoxYear;
        private System.Windows.Forms.TextBox textBoxTeacher;
        private System.Windows.Forms.DataGridView dataGridViewClass;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBoxProfile;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox comboBox3ZPP;
        private System.Windows.Forms.ComboBox comboBox2ZPP;
        private System.Windows.Forms.ComboBox comboBox1ZPP;
        private System.Windows.Forms.TextBox textBox157;
        private System.Windows.Forms.TextBox textBox121;
        private System.Windows.Forms.TextBox textBox118;
        private System.Windows.Forms.Button buttonSaveZPP;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnNumber;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnName;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnSecondName;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnLastName;
        private System.Windows.Forms.Button buttonBack;
    }
}