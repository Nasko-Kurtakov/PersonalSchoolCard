﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace E_school
{
    public partial class FormProfile : Form
    {
        public FormProfile()
        {
            InitializeComponent();
        }
        public class MossieButton : Button
        {
            private static Font _normalFont = new Font("Arial", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));

            private static Color _back = System.Drawing.Color.Gray;
            private static Color _border = System.Drawing.Color.Black;
            private static Color _activeBorder = System.Drawing.Color.Red;
            private static Color _fore = System.Drawing.Color.White;

            private static Padding _margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            private static Padding _padding = new System.Windows.Forms.Padding(3, 3, 3, 3);

            private static Size _minSize = new System.Drawing.Size(100, 30);

            private bool _active;

            public MossieButton()
                : base()
            {
                base.Font = _normalFont;
                base.BackColor = _border;
                base.ForeColor = _fore;
                base.FlatAppearance.BorderColor = _back;
                base.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
                base.Margin = _margin;
                base.Padding = _padding;
                base.MinimumSize = _minSize;
            }

            protected override void OnControlAdded(ControlEventArgs e)
            {
                base.OnControlAdded(e);
                UseVisualStyleBackColor = false;
            }

            protected override void OnMouseEnter(System.EventArgs e)
            {
                base.OnMouseEnter(e);
                if (!_active)
                    base.FlatAppearance.BorderColor = _activeBorder;
            }

            protected override void OnMouseLeave(System.EventArgs e)
            {
                base.OnMouseLeave(e);
                if (!_active)
                    base.FlatAppearance.BorderColor = _border;
            }

            public void SetStateActive()
            {
                _active = true;
                base.FlatAppearance.BorderColor = _activeBorder;
            }

            public void SetStateNormal()
            {
                _active = false;
                base.FlatAppearance.BorderColor = _border;
            }
        }



     
        private void buttonAdd_Click(object sender, EventArgs e)
        {
             ESchoolEntities context = new ESchoolEntities();
            if (!string.IsNullOrEmpty(textBoxProfile.Text))
            {
                //създаваме обект
                Profiles newProfile=new Profiles();
                newProfile.ProfileName=textBoxProfile.Text;
                //добавяне на класа в базата и записване на промените
                context.Profiles.AddObject(newProfile);
                context.SaveChanges();
                MessageBox.Show("Профилът е добавена!");
            }
            else
            {
                MessageBox.Show("Грешка! Не сте въвели данни.");
            }

        }

        private void buttonBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
